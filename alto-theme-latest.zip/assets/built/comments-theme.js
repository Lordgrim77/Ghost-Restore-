/**
 * Ghost Comments Glassmorphism & Monochrome Theme Engine
 * - Intercepts iframe[title="comments-frame"]
 * - Eradicates white-on-white button invisible bugs (Sign up now, Add comment, Comment button)
 * - Restyles "Start the conversation" placeholder line for crystal clear visibility in Light & Dark modes
 * - Guarantees full contrast for [data-testid="submit-form-button"] in active & disabled states
 * - Re-entrancy guarded to prevent infinite MutationObserver loops
 */
(function() {
    'use strict';

    const STYLE_ID = 'gm-comments-injected-style';
    let isApplying = false;

    function isDarkMode() {
        const root = document.documentElement;
        return root.classList.contains('dark-mode') ||
               root.getAttribute('data-theme') === 'dark' ||
               (!root.classList.contains('light-mode') &&
                window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }

    function generateCommentsCss(dark) {
        if (dark) {
            return `
                /* ==========================================================
                   DARK MODE OBSIDIAN MONOCHROME COMMENTS
                   ========================================================== */
                html, body {
                    background: transparent !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                    color: #ffffff !important;
                }

                section.ghost-display,
                [data-testid="content-box"] {
                    background: transparent !important;
                    color: #ffffff !important;
                    padding: 0 !important;
                    margin: 0 !important;
                    width: 100% !important;
                    box-sizing: border-box !important;
                }

                /* 1. Logged-Out CTA Box - Clean seamless integration inside comments card */
                [data-testid="cta-box"] {
                    background: transparent !important;
                    border: none !important;
                    border-radius: 0 !important;
                    padding: 16px 0 8px !important;
                    box-shadow: none !important;
                    text-align: center !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }

                [data-testid="cta-box"] h1 {
                    color: #ffffff !important;
                    -webkit-text-fill-color: #ffffff !important;
                    font-size: 22px !important;
                    font-weight: 800 !important;
                    letter-spacing: -0.02em !important;
                    margin-bottom: 8px !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                [data-testid="cta-box"] p {
                    color: rgba(255, 255, 255, 0.65) !important;
                    font-size: 14px !important;
                    line-height: 1.6 !important;
                    max-width: 480px !important;
                    margin: 0 auto 20px !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    padding: 0 !important;
                }

                [data-testid="cta-box"] p:last-child {
                    margin-top: 12px !important;
                    margin-bottom: 0 !important;
                    font-size: 13px !important;
                }

                [data-testid="cta-box"] p span {
                    color: #ffffff !important;
                    font-weight: 600 !important;
                }

                /* CTA Primary Button (Sign up now) */
                [data-testid="signup-button"],
                [data-testid="cta-box"] button[style*="background-color"],
                [data-testid="cta-box"] button.bg-black {
                    background: #ffffff !important;
                    color: #000000 !important;
                    border: 1px solid #ffffff !important;
                    border-radius: 999px !important;
                    padding: 12px 28px !important;
                    font-size: 14px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                    box-shadow: 0 4px 16px rgba(255, 255, 255, 0.15) !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                [data-testid="signup-button"]:hover,
                [data-testid="cta-box"] button:hover {
                    background: #e2e8f0 !important;
                    color: #000000 !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 20px rgba(255, 255, 255, 0.25) !important;
                }

                /* Sign In Link */
                [data-testid="signin-button"],
                [data-testid="cta-box"] p button,
                button[style*="color: var(--gh-accent-color)"] {
                    color: #ffffff !important;
                    font-weight: 600 !important;
                    text-decoration: underline !important;
                    text-underline-offset: 3px !important;
                    transition: opacity 0.2s ease !important;
                    background: transparent !important;
                }

                [data-testid="signin-button"]:hover {
                    opacity: 0.8 !important;
                }

                /* 2. Logged-In Comment Form & "Start the conversation" Line */
                [data-testid="main-form"] {
                    padding: 14px 2px 24px !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    overflow: visible !important;
                }

                [data-testid="main-form"] > div,
                [data-testid="main-form"] [class*="-mx-"],
                [data-testid="main-form"] [class*="mt-[-"] {
                    margin-top: 0 !important;
                    margin-left: 0 !important;
                    margin-right: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }

                [data-testid="main-form"] form,
                [data-testid="main-form"] [data-testid="form"] {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    margin: 0 !important;
                }

                [data-testid="form-editor"] {
                    background: rgba(255, 255, 255, 0.03) !important;
                    border: 1px solid rgba(255, 255, 255, 0.1) !important;
                    border-radius: 16px !important;
                    color: #ffffff !important;
                    font-size: 14px !important;
                    padding: 14px 16px 56px !important;
                    transition: all 0.2s ease !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    margin: 0 !important;
                }

                [data-testid="form-editor"]:focus-within {
                    border-color: rgba(255, 255, 255, 0.35) !important;
                    outline: none !important;
                    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.1) !important;
                    background: rgba(255, 255, 255, 0.05) !important;
                }

                [data-testid="main-form"] .absolute.left-0,
                [data-testid="main-form"] figure[data-testid="avatar"] {
                    left: 0 !important;
                }

                [data-testid="member-name"],
                [data-testid="main-form"] [data-testid="member-name"],
                [data-testid="form-header"] [data-testid="member-name"],
                [data-testid="main-form"] h4,
                [data-testid="main-form"] span[class*="font-semibold"],
                [data-testid="main-form"] span[class*="font-bold"] {
                    color: #ffffff !important;
                    font-weight: 700 !important;
                }

                [data-testid="expertise-button"],
                [data-testid="form-header"] button,
                [data-testid="main-form"] span[class*="text-neutral"] {
                    color: rgba(255, 255, 255, 0.6) !important;
                }

                [data-testid="expertise-button"]:hover,
                [data-testid="form-header"] button:hover {
                    color: #ffffff !important;
                }

                /* "Start the conversation" Placeholder Line */
                .tiptap.ProseMirror p.is-empty.is-editor-empty::before,
                .tiptap.ProseMirror p[data-placeholder]::before,
                .ProseMirror p.is-editor-empty:first-child::before,
                .ProseMirror [data-placeholder]::before,
                [data-placeholder]::before {
                    color: rgba(255, 255, 255, 0.55) !important;
                    -webkit-text-fill-color: rgba(255, 255, 255, 0.55) !important;
                    content: attr(data-placeholder) !important;
                    font-style: normal !important;
                    font-weight: 500 !important;
                    opacity: 1 !important;
                    float: left !important;
                    pointer-events: none !important;
                    height: 0 !important;
                    visibility: visible !important;
                    display: inline-block !important;
                }

                .tiptap,
                .ProseMirror,
                [data-testid="editor"] {
                    color: #ffffff !important;
                    outline: none !important;
                }

                /* Comment Submit Button ("Add comment" / "Comment") */
                button[data-testid="submit-form-button"],
                button[data-testid="submit-button"],
                button[type="submit"] {
                    background: #ffffff !important;
                    color: #000000 !important;
                    border: 1px solid #ffffff !important;
                    border-radius: 999px !important;
                    padding: 8px 22px !important;
                    font-size: 13px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                    box-shadow: 0 4px 14px rgba(255, 255, 255, 0.15) !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                button[data-testid="submit-form-button"]:hover:not(:disabled) {
                    background: #f1f5f9 !important;
                    color: #000000 !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 18px rgba(255, 255, 255, 0.25) !important;
                }

                button[data-testid="submit-form-button"]:disabled {
                    background: rgba(255, 255, 255, 0.08) !important;
                    color: rgba(255, 255, 255, 0.4) !important;
                    border: 1px solid rgba(255, 255, 255, 0.14) !important;
                    cursor: not-allowed !important;
                    box-shadow: none !important;
                    opacity: 1 !important;
                    visibility: visible !important;
                }

                button[data-testid="submit-form-button"] span {
                    color: inherit !important;
                }

                /* Submission lock to prevent duplicate comment submissions on double-tap */
                button[data-testid="submit-form-button"]:has([data-testid="button-spinner"]),
                button[data-testid="submit-form-button"]:has(svg#loader-1),
                button[data-testid="submit-form-button"][data-submitting="true"],
                button[data-testid="submit-form-button"].is-submitting {
                    pointer-events: none !important;
                    cursor: not-allowed !important;
                    opacity: 0.75 !important;
                }

                /* Animated Spinner Circle inside Submit Button (Dark Mode: White Button -> Pitch Black Spinner) */
                button[data-testid="submit-form-button"] [data-testid="button-spinner"],
                button[data-testid="submit-form-button"] svg#loader-1,
                button[data-testid="submit-form-button"] svg[class*="size-"],
                button[data-testid="submit-form-button"] svg,
                [data-testid="button-spinner"],
                svg#loader-1 {
                    fill: #000000 !important;
                    color: #000000 !important;
                }

                button[data-testid="submit-form-button"] [data-testid="button-spinner"] path,
                button[data-testid="submit-form-button"] svg#loader-1 path,
                button[data-testid="submit-form-button"] svg path,
                [data-testid="button-spinner"] path,
                svg#loader-1 path {
                    fill: #000000 !important;
                }

                /* Reply and Edit forms support */
                [data-testid="reply-form"],
                [data-testid="edit-form"] {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    padding: 8px 0 16px !important;
                }

                [data-testid="reply-form"] > div,
                [data-testid="edit-form"] > div {
                    margin: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }

                /* Cancel Button */
                [data-testid="main-form"] button:not([data-testid="submit-form-button"]):not([data-testid="submit-button"]) {
                    color: rgba(255, 255, 255, 0.6) !important;
                    font-weight: 500 !important;
                    font-size: 13px !important;
                }

                [data-testid="main-form"] button:not([data-testid="submit-form-button"]):hover {
                    color: #ffffff !important;
                }

                /* 3. Existing Comments Thread */
                [data-testid="comment-element"] {
                    border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
                    padding: 16px 0 !important;
                }

                [data-testid="comment-element"] h4,
                [data-testid="comment-element"] span[class*="font-semibold"],
                [data-testid="comment-element"] span[class*="font-bold"] {
                    color: #ffffff !important;
                    font-weight: 700 !important;
                }

                [data-testid="comment-element"] span[class*="rounded"] {
                    background: rgba(255, 255, 255, 0.08) !important;
                    border: 1px solid rgba(255, 255, 255, 0.12) !important;
                    color: #ffffff !important;
                    border-radius: 999px !important;
                    font-size: 11px !important;
                    font-weight: 600 !important;
                    padding: 1px 8px !important;
                }

                [data-testid="comment-element"] time,
                [data-testid="comment-element"] span[class*="text-neutral"] {
                    color: rgba(255, 255, 255, 0.45) !important;
                    font-size: 12px !important;
                }

                .gh-comment-content,
                [data-testid="comment-element"] p {
                    color: rgba(255, 255, 255, 0.88) !important;
                    font-size: 14px !important;
                    line-height: 1.65 !important;
                }

                [data-testid="comment-element"] button {
                    color: rgba(255, 255, 255, 0.6) !important;
                    transition: all 0.2s ease !important;
                    font-weight: 500 !important;
                    font-size: 13px !important;
                }

                [data-testid="comment-element"] button:hover {
                    color: #ffffff !important;
                    transform: translateY(-1px) !important;
                }

                [class*="border-l"] {
                    border-left-color: rgba(255, 255, 255, 0.12) !important;
                    border-left-width: 2px !important;
                }

                select,
                button[data-testid="sort-button"] {
                    background: rgba(255, 255, 255, 0.05) !important;
                    border: 1px solid rgba(255, 255, 255, 0.12) !important;
                    border-radius: 999px !important;
                    color: #ffffff !important;
                    font-size: 12px !important;
                    font-weight: 600 !important;
                    padding: 6px 14px !important;
                }

                [data-testid="loading"] svg {
                    fill: #ffffff !important;
                }

                /* ==========================================================
                   COMMENT DELETE POPUP & MODALS (DARK MODE OBSIDIAN)
                   ========================================================== */
                div[class*="backdrop-blur"]:has([data-testid="delete-popup"]),
                div.fixed.left-0.top-0:has([data-testid="delete-popup"]),
                div[class*="backdrop-blur"]:has([data-testid*="popup"]),
                div.fixed.left-0.top-0:has([data-testid*="popup"]),
                div[class*="backdrop-blur"]:has(div[class*="shadow-modal"]),
                div.fixed.left-0.top-0:has(div[class*="shadow-modal"]) {
                    background: rgba(0, 0, 0, 0.82) !important;
                    backdrop-filter: blur(12px) !important;
                    -webkit-backdrop-filter: blur(12px) !important;
                }

                [data-testid="delete-popup"],
                div[data-testid*="popup"][class*="shadow-modal"],
                div[class*="shadow-modal"]:not([data-testid="main-form"]) {
                    background: #111318 !important;
                    border: 1px solid rgba(255, 255, 255, 0.14) !important;
                    border-radius: 24px !important;
                    box-shadow: 0 28px 72px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.08) !important;
                    color: #ffffff !important;
                    padding: 32px !important;
                }

                [data-testid="delete-popup"] h1,
                [data-testid="delete-popup"] h1 span,
                div[data-testid*="popup"] h1,
                div[class*="shadow-modal"] h1 {
                    color: #ffffff !important;
                    font-size: 22px !important;
                    font-weight: 800 !important;
                    letter-spacing: -0.02em !important;
                }

                [data-testid="delete-popup"] p,
                div[data-testid*="popup"] p,
                div[class*="shadow-modal"] p {
                    color: rgba(255, 255, 255, 0.72) !important;
                    font-size: 14px !important;
                    line-height: 1.6 !important;
                }

                /* Delete Confirm Button (Pure White Pill) */
                button[data-testid="delete-popup-confirm"],
                div[data-testid*="popup"] button.bg-red-600,
                div[data-testid*="popup"] button[class*="bg-red"],
                div[class*="shadow-modal"] button.bg-red-600 {
                    background: #ffffff !important;
                    color: #000000 !important;
                    border: 1px solid #ffffff !important;
                    border-radius: 999px !important;
                    font-size: 14px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    padding: 10px 24px !important;
                    box-shadow: 0 4px 16px rgba(255, 255, 255, 0.2) !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                }

                button[data-testid="delete-popup-confirm"]:hover,
                div[data-testid*="popup"] button.bg-red-600:hover,
                div[class*="shadow-modal"] button.bg-red-600:hover {
                    background: #f1f5f9 !important;
                    color: #000000 !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 20px rgba(255, 255, 255, 0.3) !important;
                }

                button[data-testid="delete-popup-confirm"] svg,
                button[data-testid="delete-popup-confirm"] path {
                    fill: #000000 !important;
                    stroke: #000000 !important;
                }

                /* Delete Popup Cancel Button */
                [data-testid="delete-popup"] button:not([data-testid="delete-popup-confirm"]):not([class*="absolute"]),
                div[data-testid*="popup"] button.text-neutral-500,
                div[data-testid*="popup"] button[class*="dark:text-neutral"],
                div[class*="shadow-modal"] button.text-neutral-500 {
                    background: rgba(255, 255, 255, 0.05) !important;
                    color: rgba(255, 255, 255, 0.75) !important;
                    border: 1px solid rgba(255, 255, 255, 0.14) !important;
                    border-radius: 999px !important;
                    font-size: 14px !important;
                    font-weight: 600 !important;
                    padding: 10px 22px !important;
                    cursor: pointer !important;
                    transition: all 0.2s ease !important;
                }

                [data-testid="delete-popup"] button:not([data-testid="delete-popup-confirm"]):not([class*="absolute"]):hover,
                div[data-testid*="popup"] button.text-neutral-500:hover,
                div[class*="shadow-modal"] button.text-neutral-500:hover {
                    background: rgba(255, 255, 255, 0.1) !important;
                    color: #ffffff !important;
                    border-color: rgba(255, 255, 255, 0.3) !important;
                }

                /* Modal Close Icon Button (X) */
                [data-testid="delete-popup"] button[class*="absolute"],
                div[data-testid*="popup"] button[class*="absolute"],
                div[class*="shadow-modal"] button[class*="absolute"] {
                    color: rgba(255, 255, 255, 0.6) !important;
                    transition: color 0.2s ease !important;
                }

                [data-testid="delete-popup"] button[class*="absolute"]:hover,
                div[data-testid*="popup"] button[class*="absolute"]:hover,
                div[class*="shadow-modal"] button[class*="absolute"]:hover {
                    color: #ffffff !important;
                }

                [data-testid="delete-popup"] button[class*="absolute"] svg,
                div[data-testid*="popup"] button[class*="absolute"] svg,
                div[class*="shadow-modal"] button[class*="absolute"] svg {
                    stroke: currentColor !important;
                    fill: currentColor !important;
                }
            `;
        } else {
            return `
                /* ==========================================================
                   LIGHT MODE CRISP MONOCHROME COMMENTS
                   ========================================================== */
                html, body {
                    background: transparent !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                    color: #090b10 !important;
                }

                section.ghost-display,
                [data-testid="content-box"] {
                    background: transparent !important;
                    color: #090b10 !important;
                    padding: 0 !important;
                    margin: 0 !important;
                    width: 100% !important;
                    box-sizing: border-box !important;
                }

                /* 1. Logged-Out CTA Box - Clean seamless integration inside comments card */
                [data-testid="cta-box"] {
                    background: transparent !important;
                    border: none !important;
                    border-radius: 0 !important;
                    padding: 16px 0 8px !important;
                    box-shadow: none !important;
                    text-align: center !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }

                [data-testid="cta-box"] h1 {
                    color: #000000 !important;
                    -webkit-text-fill-color: #000000 !important;
                    font-size: 22px !important;
                    font-weight: 800 !important;
                    letter-spacing: -0.02em !important;
                    margin-bottom: 8px !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                [data-testid="cta-box"] p {
                    color: rgba(0, 0, 0, 0.7) !important;
                    font-size: 14px !important;
                    line-height: 1.6 !important;
                    max-width: 480px !important;
                    margin: 0 auto 20px !important;
                    display: block !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                    padding: 0 !important;
                }

                [data-testid="cta-box"] p:last-child {
                    margin-top: 12px !important;
                    margin-bottom: 0 !important;
                    font-size: 13px !important;
                }

                [data-testid="cta-box"] p span {
                    color: #000000 !important;
                    font-weight: 700 !important;
                }

                /* CTA Primary Button (Sign up now) */
                [data-testid="signup-button"],
                [data-testid="cta-box"] button[style*="background-color"],
                [data-testid="cta-box"] button.bg-black {
                    background: #000000 !important;
                    color: #ffffff !important;
                    border: 1px solid #000000 !important;
                    border-radius: 999px !important;
                    padding: 12px 28px !important;
                    font-size: 14px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.18) !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                [data-testid="signup-button"]:hover,
                [data-testid="cta-box"] button:hover {
                    background: #27272a !important;
                    color: #ffffff !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25) !important;
                }

                /* Sign In Link */
                [data-testid="signin-button"],
                [data-testid="cta-box"] p button,
                button[style*="color: var(--gh-accent-color)"] {
                    color: #000000 !important;
                    font-weight: 700 !important;
                    text-decoration: underline !important;
                    text-underline-offset: 3px !important;
                    transition: opacity 0.2s ease !important;
                    background: transparent !important;
                }

                [data-testid="signin-button"]:hover {
                    opacity: 0.7 !important;
                }

                /* 2. Logged-In Comment Form & "Start the conversation" Line */
                [data-testid="main-form"] {
                    padding: 14px 2px 24px !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    overflow: visible !important;
                }

                [data-testid="main-form"] > div,
                [data-testid="main-form"] [class*="-mx-"],
                [data-testid="main-form"] [class*="mt-[-"] {
                    margin-top: 0 !important;
                    margin-left: 0 !important;
                    margin-right: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }

                [data-testid="main-form"] form,
                [data-testid="main-form"] [data-testid="form"] {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    margin: 0 !important;
                }

                [data-testid="form-editor"] {
                    background: rgba(0, 0, 0, 0.02) !important;
                    border: 1px solid rgba(0, 0, 0, 0.18) !important;
                    border-radius: 16px !important;
                    color: #090b10 !important;
                    font-size: 14px !important;
                    padding: 14px 16px 56px !important;
                    transition: all 0.2s ease !important;
                    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.04) !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    margin: 0 !important;
                }

                [data-testid="form-editor"]:focus-within {
                    border-color: #000000 !important;
                    outline: none !important;
                    box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.1) !important;
                    background: #ffffff !important;
                }

                [data-testid="main-form"] .absolute.left-0,
                [data-testid="main-form"] figure[data-testid="avatar"] {
                    left: 0 !important;
                }

                [data-testid="member-name"],
                [data-testid="main-form"] [data-testid="member-name"],
                [data-testid="form-header"] [data-testid="member-name"],
                [data-testid="main-form"] h4,
                [data-testid="main-form"] span[class*="font-semibold"],
                [data-testid="main-form"] span[class*="font-bold"] {
                    color: #000000 !important;
                    font-weight: 700 !important;
                }

                [data-testid="expertise-button"],
                [data-testid="form-header"] button,
                [data-testid="main-form"] span[class*="text-neutral"] {
                    color: rgba(0, 0, 0, 0.6) !important;
                }

                [data-testid="expertise-button"]:hover,
                [data-testid="form-header"] button:hover {
                    color: #000000 !important;
                }

                /* "Start the conversation" Placeholder Line (High Contrast Crisp Slate) */
                .tiptap.ProseMirror p.is-empty.is-editor-empty::before,
                .tiptap.ProseMirror p[data-placeholder]::before,
                .ProseMirror p.is-editor-empty:first-child::before,
                .ProseMirror [data-placeholder]::before,
                [data-placeholder]::before {
                    color: rgba(0, 0, 0, 0.65) !important;
                    -webkit-text-fill-color: rgba(0, 0, 0, 0.65) !important;
                    content: attr(data-placeholder) !important;
                    font-style: normal !important;
                    font-weight: 500 !important;
                    opacity: 1 !important;
                    float: left !important;
                    pointer-events: none !important;
                    height: 0 !important;
                    visibility: visible !important;
                    display: inline-block !important;
                }

                .tiptap,
                .ProseMirror,
                [data-testid="editor"] {
                    color: #090b10 !important;
                    outline: none !important;
                }

                /* Comment Submit Button ("Add comment" / "Comment") */
                button[data-testid="submit-form-button"],
                button[data-testid="submit-button"],
                button[type="submit"] {
                    background: #000000 !important;
                    color: #ffffff !important;
                    border: 1px solid #000000 !important;
                    border-radius: 999px !important;
                    padding: 8px 22px !important;
                    font-size: 13px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.18) !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    visibility: visible !important;
                    opacity: 1 !important;
                }

                button[data-testid="submit-form-button"]:hover:not(:disabled) {
                    background: #27272a !important;
                    color: #ffffff !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25) !important;
                }

                button[data-testid="submit-form-button"]:disabled {
                    background: rgba(0, 0, 0, 0.08) !important;
                    color: rgba(0, 0, 0, 0.45) !important;
                    border: 1px solid rgba(0, 0, 0, 0.16) !important;
                    border-radius: 999px !important;
                    cursor: not-allowed !important;
                    box-shadow: none !important;
                    opacity: 1 !important;
                    visibility: visible !important;
                }

                button[data-testid="submit-form-button"] span {
                    color: inherit !important;
                }

                /* Submission lock to prevent duplicate comment submissions on double-tap */
                button[data-testid="submit-form-button"]:has([data-testid="button-spinner"]),
                button[data-testid="submit-form-button"]:has(svg#loader-1),
                button[data-testid="submit-form-button"][data-submitting="true"],
                button[data-testid="submit-form-button"].is-submitting {
                    pointer-events: none !important;
                    cursor: not-allowed !important;
                    opacity: 0.75 !important;
                }

                /* Animated Spinner Circle inside Submit Button (Light Mode: Black Button -> Pure White Spinner) */
                button[data-testid="submit-form-button"] [data-testid="button-spinner"],
                button[data-testid="submit-form-button"] svg#loader-1,
                button[data-testid="submit-form-button"] svg[class*="size-"],
                button[data-testid="submit-form-button"] svg,
                [data-testid="button-spinner"],
                svg#loader-1 {
                    fill: #ffffff !important;
                    color: #ffffff !important;
                }

                button[data-testid="submit-form-button"] [data-testid="button-spinner"] path,
                button[data-testid="submit-form-button"] svg#loader-1 path,
                button[data-testid="submit-form-button"] svg path,
                [data-testid="button-spinner"] path,
                svg#loader-1 path {
                    fill: #ffffff !important;
                }

                /* Reply and Edit forms support */
                [data-testid="reply-form"],
                [data-testid="edit-form"] {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    padding: 8px 0 16px !important;
                }

                [data-testid="reply-form"] > div,
                [data-testid="edit-form"] > div {
                    margin: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }

                /* Cancel Button */
                [data-testid="main-form"] button:not([data-testid="submit-form-button"]):not([data-testid="submit-button"]) {
                    color: rgba(0, 0, 0, 0.6) !important;
                    font-weight: 500 !important;
                    font-size: 13px !important;
                }

                [data-testid="main-form"] button:not([data-testid="submit-form-button"]):hover {
                    color: #000000 !important;
                }

                /* 3. Existing Comments Thread */
                [data-testid="comment-element"] {
                    border-bottom: 1px solid rgba(0, 0, 0, 0.08) !important;
                    padding: 16px 0 !important;
                }

                [data-testid="comment-element"] h4,
                [data-testid="comment-element"] span[class*="font-semibold"],
                [data-testid="comment-element"] span[class*="font-bold"] {
                    color: #000000 !important;
                    font-weight: 700 !important;
                }

                [data-testid="comment-element"] span[class*="rounded"] {
                    background: rgba(0, 0, 0, 0.06) !important;
                    border: 1px solid rgba(0, 0, 0, 0.12) !important;
                    color: #000000 !important;
                    border-radius: 999px !important;
                    font-size: 11px !important;
                    font-weight: 600 !important;
                    padding: 1px 8px !important;
                }

                [data-testid="comment-element"] time,
                [data-testid="comment-element"] span[class*="text-neutral"] {
                    color: rgba(0, 0, 0, 0.5) !important;
                    font-size: 12px !important;
                }

                .gh-comment-content,
                [data-testid="comment-element"] p {
                    color: rgba(0, 0, 0, 0.85) !important;
                    font-size: 14px !important;
                    line-height: 1.65 !important;
                }

                [data-testid="comment-element"] button {
                    color: rgba(0, 0, 0, 0.6) !important;
                    transition: all 0.2s ease !important;
                    font-weight: 500 !important;
                    font-size: 13px !important;
                }

                [data-testid="comment-element"] button:hover {
                    color: #000000 !important;
                    transform: translateY(-1px) !important;
                }

                [class*="border-l"] {
                    border-left-color: rgba(0, 0, 0, 0.12) !important;
                    border-left-width: 2px !important;
                }

                select,
                button[data-testid="sort-button"] {
                    background: rgba(0, 0, 0, 0.04) !important;
                    border: 1px solid rgba(0, 0, 0, 0.12) !important;
                    border-radius: 999px !important;
                    color: #000000 !important;
                    font-size: 12px !important;
                    font-weight: 600 !important;
                    padding: 6px 14px !important;
                }

                [data-testid="loading"] svg {
                    fill: #000000 !important;
                }

                /* ==========================================================
                   COMMENT DELETE POPUP & MODALS (LIGHT MODE CRISP MONOCHROME)
                   ========================================================== */
                div[class*="backdrop-blur"]:has([data-testid="delete-popup"]),
                div.fixed.left-0.top-0:has([data-testid="delete-popup"]),
                div[class*="backdrop-blur"]:has([data-testid*="popup"]),
                div.fixed.left-0.top-0:has([data-testid*="popup"]),
                div[class*="backdrop-blur"]:has(div[class*="shadow-modal"]),
                div.fixed.left-0.top-0:has(div[class*="shadow-modal"]) {
                    background: rgba(0, 0, 0, 0.45) !important;
                    backdrop-filter: blur(12px) !important;
                    -webkit-backdrop-filter: blur(12px) !important;
                }

                [data-testid="delete-popup"],
                div[data-testid*="popup"][class*="shadow-modal"],
                div[class*="shadow-modal"]:not([data-testid="main-form"]) {
                    background: #ffffff !important;
                    border: 1px solid rgba(0, 0, 0, 0.12) !important;
                    border-radius: 24px !important;
                    box-shadow: 0 28px 72px rgba(0, 0, 0, 0.18), 0 0 0 1px rgba(0, 0, 0, 0.04) !important;
                    color: #090b10 !important;
                    padding: 32px !important;
                }

                [data-testid="delete-popup"] h1,
                [data-testid="delete-popup"] h1 span,
                div[data-testid*="popup"] h1,
                div[class*="shadow-modal"] h1 {
                    color: #000000 !important;
                    font-size: 22px !important;
                    font-weight: 800 !important;
                    letter-spacing: -0.02em !important;
                }

                [data-testid="delete-popup"] p,
                div[data-testid*="popup"] p,
                div[class*="shadow-modal"] p {
                    color: rgba(0, 0, 0, 0.7) !important;
                    font-size: 14px !important;
                    line-height: 1.6 !important;
                }

                /* Delete Confirm Button (Pure Black Pill) */
                button[data-testid="delete-popup-confirm"],
                div[data-testid*="popup"] button.bg-red-600,
                div[data-testid*="popup"] button[class*="bg-red"],
                div[class*="shadow-modal"] button.bg-red-600 {
                    background: #000000 !important;
                    color: #ffffff !important;
                    border: 1px solid #000000 !important;
                    border-radius: 999px !important;
                    font-size: 14px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    padding: 10px 24px !important;
                    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2) !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                }

                button[data-testid="delete-popup-confirm"]:hover,
                div[data-testid*="popup"] button.bg-red-600:hover,
                div[class*="shadow-modal"] button.bg-red-600:hover {
                    background: #27272a !important;
                    color: #ffffff !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25) !important;
                }

                button[data-testid="delete-popup-confirm"] svg,
                button[data-testid="delete-popup-confirm"] path {
                    fill: #ffffff !important;
                    stroke: #ffffff !important;
                }

                /* Delete Popup Cancel Button */
                [data-testid="delete-popup"] button:not([data-testid="delete-popup-confirm"]):not([class*="absolute"]),
                div[data-testid*="popup"] button.text-neutral-500,
                div[data-testid*="popup"] button[class*="dark:text-neutral"],
                div[class*="shadow-modal"] button.text-neutral-500 {
                    background: rgba(0, 0, 0, 0.04) !important;
                    color: rgba(0, 0, 0, 0.75) !important;
                    border: 1px solid rgba(0, 0, 0, 0.12) !important;
                    border-radius: 999px !important;
                    font-size: 14px !important;
                    font-weight: 600 !important;
                    padding: 10px 22px !important;
                    cursor: pointer !important;
                    transition: all 0.2s ease !important;
                }

                [data-testid="delete-popup"] button:not([data-testid="delete-popup-confirm"]):not([class*="absolute"]):hover,
                div[data-testid*="popup"] button.text-neutral-500:hover,
                div[class*="shadow-modal"] button.text-neutral-500:hover {
                    background: rgba(0, 0, 0, 0.08) !important;
                    color: #000000 !important;
                    border-color: rgba(0, 0, 0, 0.3) !important;
                }

                /* Modal Close Icon Button (X) */
                [data-testid="delete-popup"] button[class*="absolute"],
                div[data-testid*="popup"] button[class*="absolute"],
                div[class*="shadow-modal"] button[class*="absolute"] {
                    color: rgba(0, 0, 0, 0.5) !important;
                    transition: color 0.2s ease !important;
                }

                [data-testid="delete-popup"] button[class*="absolute"]:hover,
                div[data-testid*="popup"] button[class*="absolute"]:hover,
                div[class*="shadow-modal"] button[class*="absolute"]:hover {
                    color: #000000 !important;
                }

                [data-testid="delete-popup"] button[class*="absolute"] svg,
                div[data-testid*="popup"] button[class*="absolute"] svg,
                div[class*="shadow-modal"] button[class*="absolute"] svg {
                    stroke: currentColor !important;
                    fill: currentColor !important;
                }
            `;
        }
    }

    function applyCommentsStyle(frame) {
        if (!frame || isApplying) return;
        try {
            isApplying = true;
            const doc = frame.contentDocument || frame.contentWindow.document;
            if (!doc) return;

            const targetHead = doc.head || doc.body || doc.documentElement;
            if (!targetHead) return;

            const dark = isDarkMode();
            const themeName = dark ? 'dark' : 'light';
            const cssContent = generateCommentsCss(dark);

            let style = doc.getElementById(STYLE_ID);
            if (style) {
                if (style.getAttribute('data-applied-theme') !== themeName || style.textContent !== cssContent) {
                    style.setAttribute('data-applied-theme', themeName);
                    style.textContent = cssContent;
                }
                if (targetHead.lastElementChild !== style) {
                    targetHead.appendChild(style);
                }
                if (window.gmSyncCommentsAvatar) { window.gmSyncCommentsAvatar(); }
            } else {
                style = doc.createElement('style');
                style.id = STYLE_ID;
                style.setAttribute('data-applied-theme', themeName);
                style.textContent = cssContent;
                targetHead.appendChild(style);
            }

            if (!doc._gmObserved) {
                doc._gmObserved = true;
                let timer = null;
                const frameObs = new MutationObserver(function() {
                    if (timer) return;
                    timer = setTimeout(function() {
                        timer = null;
                        applyCommentsStyle(frame);
                    }, 60);
                });
                frameObs.observe(doc.documentElement, {
                    childList: true,
                    subtree: true
                });
            }

            if (!doc._gmClickGuard) {
                doc._gmClickGuard = true;
                doc.addEventListener('click', function(e) {
                    const btn = e.target && e.target.closest && e.target.closest('button[data-testid="submit-form-button"], button[data-testid="delete-popup-confirm"], form button[type="submit"]');
                    if (!btn) return;

                    // If already marked as submitting, cancel event completely to prevent duplicate sending
                    if (btn.getAttribute('data-submitting') === 'true' || btn.classList.contains('gm-submitting')) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        return false;
                    }

                    // Immediately lock button
                    btn.setAttribute('data-submitting', 'true');
                    btn.classList.add('gm-submitting');

                    // Automatically clear lock after 2.5 seconds or once flight finishes
                    let elapsed = 0;
                    const poll = setInterval(function() {
                        elapsed += 100;
                        const hasSpinner = btn.querySelector('[data-testid="button-spinner"]') || btn.querySelector('svg#loader-1');
                        if ((!hasSpinner && elapsed >= 600) || elapsed >= 2500 || !doc.contains(btn)) {
                            clearInterval(poll);
                            btn.removeAttribute('data-submitting');
                            btn.classList.remove('gm-submitting');
                        }
                    }, 100);
                }, true); // Capture phase ensures we intercept before React SyntheticEvent
            }
        } catch (e) {
            // Cross-origin fallback
        } finally {
            isApplying = false;
        }
    }

    function checkAllCommentFrames() {
        const frames = document.querySelectorAll('iframe[title="comments-frame"]');
        for (let i = 0; i < frames.length; i++) {
            applyCommentsStyle(frames[i]);
        }
    }

    // 1. Parent DOM mutation observer (catches iframe insertion)
    const observer = new MutationObserver(function(mutations) {
        for (let i = 0; i < mutations.length; i++) {
            const added = mutations[i].addedNodes;
            for (let j = 0; j < added.length; j++) {
                const node = added[j];
                if (node.nodeType === 1) {
                    if (node.tagName === 'IFRAME' || (node.querySelector && node.querySelector('iframe[title="comments-frame"]'))) {
                        checkAllCommentFrames();
                        return;
                    }
                }
            }
        }
    });

    if (document.documentElement) {
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }

    // 2. Theme switch observer
    const themeObserver = new MutationObserver(function() {
        checkAllCommentFrames();
    });
    if (document.documentElement) {
        themeObserver.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['class', 'data-theme']
        });
    }

    // 3. Periodic safety sweep
    setInterval(checkAllCommentFrames, 500);

    // Initial check
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', checkAllCommentFrames);
    } else {
        checkAllCommentFrames();
    }
})();

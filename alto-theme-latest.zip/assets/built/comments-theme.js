/**
 * Ghost Comments Glassmorphism & Monochrome Theme Engine
 * - Intercepts iframe[title="comments-frame"]
 * - Eradicates white-on-white button invisible bugs
 * - Restyles Ghost Comments UI into Obsidian Glassmorphism (100% Monochrome)
 * - Synchronizes with Dark / Light Mode switches instantly
 */
(function() {
    'use strict';

    const STYLE_ID = 'gm-comments-injected-style';

    function isDarkMode() {
        return document.documentElement.classList.contains('dark-mode') ||
               document.documentElement.getAttribute('data-theme') === 'dark' ||
               (!document.documentElement.classList.contains('light-mode') &&
                window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }

    function generateCommentsCss(dark) {
        if (dark) {
            return `
                /* Dark Mode Obsidian Glassmorphism Comments */
                body {
                    background: transparent !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                    color: #ffffff !important;
                }

                /* Container */
                section.ghost-display {
                    background: transparent !important;
                    color: #ffffff !important;
                    padding-top: 0 !important;
                    padding-bottom: 8px !important;
                }

                /* CTA Box (Logged-out state) */
                [data-testid="cta-box"] {
                    background: rgba(255, 255, 255, 0.03) !important;
                    border: 1px solid rgba(255, 255, 255, 0.08) !important;
                    border-radius: 18px !important;
                    padding: 32px 24px !important;
                    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06) !important;
                    text-align: center !important;
                }

                [data-testid="cta-box"] h1 {
                    color: #ffffff !important;
                    font-size: 22px !important;
                    font-weight: 800 !important;
                    letter-spacing: -0.02em !important;
                    margin-bottom: 8px !important;
                }

                [data-testid="cta-box"] p {
                    color: rgba(255, 255, 255, 0.65) !important;
                    font-size: 14px !important;
                    line-height: 1.6 !important;
                    max-width: 480px !important;
                    margin: 0 auto 24px !important;
                }

                [data-testid="cta-box"] p span {
                    color: #ffffff !important;
                    font-weight: 600 !important;
                }

                /* Primary Action Button (Sign up / Add comment) - Fix White-on-White Bug */
                [data-testid="cta-box"] button[style*="background-color"],
                [data-testid="cta-box"] button.bg-black,
                button[data-testid="submit-button"],
                button[type="submit"] {
                    background: #ffffff !important;
                    color: #000000 !important;
                    border: none !important;
                    border-radius: 999px !important;
                    padding: 12px 28px !important;
                    font-size: 14px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                    box-shadow: 0 4px 16px rgba(255, 255, 255, 0.15) !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                }

                [data-testid="cta-box"] button[style*="background-color"]:hover,
                button[data-testid="submit-button"]:hover,
                button[type="submit"]:hover {
                    background: #e2e8f0 !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 20px rgba(255, 255, 255, 0.25) !important;
                }

                /* Secondary Links & Sign In Link */
                [data-testid="cta-box"] p button,
                button[style*="color: var(--gh-accent-color)"] {
                    color: #ffffff !important;
                    font-weight: 600 !important;
                    text-decoration: underline !important;
                    text-underline-offset: 3px !important;
                    transition: opacity 0.2s ease !important;
                }

                [data-testid="cta-box"] p button:hover {
                    opacity: 0.8 !important;
                }

                /* Form Textarea / Editor */
                form textarea,
                .kg-prose textarea,
                [data-testid="editor-textarea"] {
                    background: rgba(255, 255, 255, 0.05) !important;
                    border: 1px solid rgba(255, 255, 255, 0.14) !important;
                    border-radius: 14px !important;
                    color: #ffffff !important;
                    font-size: 14px !important;
                    padding: 14px 16px !important;
                    transition: all 0.2s ease !important;
                    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2) !important;
                }

                form textarea:focus,
                [data-testid="editor-textarea"]:focus {
                    border-color: #ffffff !important;
                    outline: none !important;
                    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.15) !important;
                    background: rgba(255, 255, 255, 0.08) !important;
                }

                /* Comment Element Card */
                [data-testid="comment-element"] {
                    border-bottom: 1px solid rgba(255, 255, 255, 0.07) !important;
                    padding: 20px 0 !important;
                    transition: background 0.2s ease !important;
                }

                [data-testid="comment-element"]:last-child {
                    border-bottom: none !important;
                }

                /* Author Name */
                [data-testid="comment-element"] h4 {
                    color: #ffffff !important;
                    font-weight: 700 !important;
                    font-size: 14px !important;
                }

                /* Member / Staff Badges */
                [data-testid="comment-element"] span[class*="rounded"] {
                    background: rgba(255, 255, 255, 0.1) !important;
                    border: 1px solid rgba(255, 255, 255, 0.15) !important;
                    color: #ffffff !important;
                    border-radius: 999px !important;
                    font-size: 11px !important;
                    font-weight: 600 !important;
                    padding: 1px 8px !important;
                }

                /* Timestamps */
                [data-testid="comment-element"] time,
                [data-testid="comment-element"] span.text-neutral-400,
                [data-testid="comment-element"] span[class*="text-neutral"] {
                    color: rgba(255, 255, 255, 0.45) !important;
                    font-size: 12px !important;
                }

                /* Comment Body Text */
                .gh-comment-content,
                [data-testid="comment-element"] p {
                    color: rgba(255, 255, 255, 0.88) !important;
                    font-size: 14px !important;
                    line-height: 1.65 !important;
                }

                /* Like & Reply Action Buttons */
                [data-testid="comment-element"] button {
                    color: rgba(255, 255, 255, 0.6) !important;
                    transition: all 0.2s ease !important;
                    font-weight: 500 !important;
                    font-size: 13px !important;
                }

                [data-testid="comment-element"] button:hover {
                    color: #ffffff !important;
                    transform: translateY(-1px) !important;
                }

                /* Reply Thread Indent Line */
                [class*="border-l"] {
                    border-left-color: rgba(255, 255, 255, 0.12) !important;
                    border-left-width: 2px !important;
                }

                /* Sort Dropdown */
                select,
                button[data-testid="sort-button"] {
                    background: rgba(255, 255, 255, 0.05) !important;
                    border: 1px solid rgba(255, 255, 255, 0.12) !important;
                    border-radius: 999px !important;
                    color: #ffffff !important;
                    font-size: 12px !important;
                    font-weight: 600 !important;
                    padding: 6px 14px !important;
                }

                /* Loading Indicator */
                [data-testid="loading"] svg {
                    fill: #ffffff !important;
                }
            `;
        } else {
            return `
                /* Light Mode Crisp Monochrome Comments */
                body {
                    background: transparent !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                    color: #090b10 !important;
                }

                section.ghost-display {
                    background: transparent !important;
                    color: #090b10 !important;
                    padding-top: 0 !important;
                    padding-bottom: 8px !important;
                }

                /* CTA Box (Logged-out state) */
                [data-testid="cta-box"] {
                    background: rgba(0, 0, 0, 0.02) !important;
                    border: 1px solid rgba(0, 0, 0, 0.08) !important;
                    border-radius: 18px !important;
                    padding: 32px 24px !important;
                    text-align: center !important;
                }

                [data-testid="cta-box"] h1 {
                    color: #000000 !important;
                    font-size: 22px !important;
                    font-weight: 800 !important;
                    letter-spacing: -0.02em !important;
                    margin-bottom: 8px !important;
                }

                [data-testid="cta-box"] p {
                    color: rgba(0, 0, 0, 0.65) !important;
                    font-size: 14px !important;
                    line-height: 1.6 !important;
                    max-width: 480px !important;
                    margin: 0 auto 24px !important;
                }

                [data-testid="cta-box"] p span {
                    color: #000000 !important;
                    font-weight: 600 !important;
                }

                /* Primary Action Button */
                [data-testid="cta-box"] button[style*="background-color"],
                [data-testid="cta-box"] button.bg-black,
                button[data-testid="submit-button"],
                button[type="submit"] {
                    background: #000000 !important;
                    color: #ffffff !important;
                    border: none !important;
                    border-radius: 999px !important;
                    padding: 12px 28px !important;
                    font-size: 14px !important;
                    font-weight: 700 !important;
                    letter-spacing: -0.01em !important;
                    cursor: pointer !important;
                    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
                    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15) !important;
                    display: inline-flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                }

                [data-testid="cta-box"] button[style*="background-color"]:hover,
                button[data-testid="submit-button"]:hover,
                button[type="submit"]:hover {
                    background: #18181b !important;
                    transform: translateY(-1px) !important;
                    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.2) !important;
                }

                /* Secondary Links & Sign In Link */
                [data-testid="cta-box"] p button,
                button[style*="color: var(--gh-accent-color)"] {
                    color: #000000 !important;
                    font-weight: 600 !important;
                    text-decoration: underline !important;
                    text-underline-offset: 3px !important;
                    transition: opacity 0.2s ease !important;
                }

                [data-testid="cta-box"] p button:hover {
                    opacity: 0.7 !important;
                }

                /* Form Textarea / Editor */
                form textarea,
                .kg-prose textarea,
                [data-testid="editor-textarea"] {
                    background: rgba(0, 0, 0, 0.03) !important;
                    border: 1px solid rgba(0, 0, 0, 0.14) !important;
                    border-radius: 14px !important;
                    color: #090b10 !important;
                    font-size: 14px !important;
                    padding: 14px 16px !important;
                    transition: all 0.2s ease !important;
                }

                form textarea:focus,
                [data-testid="editor-textarea"]:focus {
                    border-color: #000000 !important;
                    outline: none !important;
                    box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.1) !important;
                    background: #ffffff !important;
                }

                /* Comment Element Card */
                [data-testid="comment-element"] {
                    border-bottom: 1px solid rgba(0, 0, 0, 0.08) !important;
                    padding: 20px 0 !important;
                }

                [data-testid="comment-element"]:last-child {
                    border-bottom: none !important;
                }

                [data-testid="comment-element"] h4 {
                    color: #090b10 !important;
                    font-weight: 700 !important;
                    font-size: 14px !important;
                }

                [data-testid="comment-element"] span[class*="rounded"] {
                    background: rgba(0, 0, 0, 0.06) !important;
                    border: 1px solid rgba(0, 0, 0, 0.12) !important;
                    color: #000000 !important;
                    border-radius: 999px !important;
                    font-size: 11px !important;
                    font-weight: 600 !important;
                    padding: 1px 8px !important;
                }

                [data-testid="comment-element"] time,
                [data-testid="comment-element"] span.text-neutral-400,
                [data-testid="comment-element"] span[class*="text-neutral"] {
                    color: rgba(0, 0, 0, 0.5) !important;
                    font-size: 12px !important;
                }

                .gh-comment-content,
                [data-testid="comment-element"] p {
                    color: rgba(0, 0, 0, 0.85) !important;
                    font-size: 14px !important;
                    line-height: 1.65 !important;
                }

                [data-testid="comment-element"] button {
                    color: rgba(0, 0, 0, 0.6) !important;
                    transition: all 0.2s ease !important;
                    font-weight: 500 !important;
                    font-size: 13px !important;
                }

                [data-testid="comment-element"] button:hover {
                    color: #000000 !important;
                    transform: translateY(-1px) !important;
                }

                [class*="border-l"] {
                    border-left-color: rgba(0, 0, 0, 0.12) !important;
                    border-left-width: 2px !important;
                }

                select,
                button[data-testid="sort-button"] {
                    background: rgba(0, 0, 0, 0.04) !important;
                    border: 1px solid rgba(0, 0, 0, 0.12) !important;
                    border-radius: 999px !important;
                    color: #000000 !important;
                    font-size: 12px !important;
                    font-weight: 600 !important;
                    padding: 6px 14px !important;
                }

                [data-testid="loading"] svg {
                    fill: #000000 !important;
                }
            `;
        }
    }

    function applyCommentsStyle(frame) {
        if (!frame) return;
        try {
            const doc = frame.contentDocument || frame.contentWindow.document;
            if (!doc || !doc.head) return;

            const dark = isDarkMode();
            let style = doc.getElementById(STYLE_ID);
            if (!style) {
                style = doc.createElement('style');
                style.id = STYLE_ID;
                doc.head.appendChild(style);
            }
            style.textContent = generateCommentsCss(dark);
        } catch (e) {
            // Sandboxed fallback
        }
    }

    function initCommentsInterceptor() {
        const checkFrame = () => {
            const frames = document.querySelectorAll('iframe[title="comments-frame"]');
            frames.forEach(frame => {
                applyCommentsStyle(frame);
                // Also watch for re-renders or content loads inside the frame
                try {
                    const doc = frame.contentDocument || frame.contentWindow.document;
                    if (doc && !doc._gmObserved) {
                        doc._gmObserved = true;
                        const observer = new MutationObserver(() => applyCommentsStyle(frame));
                        observer.observe(doc.body || doc.documentElement, { childList: true, subtree: true });
                    }
                } catch (e) {}
            });
        };

        // Run immediately and via MutationObserver on parent
        checkFrame();
        const root = document.getElementById('ghost-comments-root') || document.body;
        const parentObserver = new MutationObserver(checkFrame);
        parentObserver.observe(root, { childList: true, subtree: true });

        // Listen for site theme changes
        const themeObserver = new MutationObserver(() => {
            checkFrame();
        });
        themeObserver.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['class', 'data-theme']
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initCommentsInterceptor);
    } else {
        initCommentsInterceptor();
    }
})();


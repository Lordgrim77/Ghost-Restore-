/* Author RSS Modal Handler (Externalized from author.hbs for Strict CSP) */
(function () {
    var trigger = document.getElementById('gm-rss-trigger');
    var backdrop = document.getElementById('gm-rss-modal-backdrop');
    var closeBtn = document.getElementById('gm-rss-modal-close');
    var copyBtn = document.getElementById('gm-rss-copy-btn');
    var input = document.getElementById('gm-rss-input');
    if (!trigger || !backdrop) return;

    function copyFeed() {
        var url = trigger.getAttribute('data-feed-url') || (input ? input.value : '');
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).catch(function () {});
        } else if (input) {
            input.select();
            document.execCommand('copy');
        }
    }

    function openModal() {
        backdrop.classList.add('is-open');
        backdrop.setAttribute('aria-hidden', 'false');
        if (input) input.select();
    }

    function closeModal() {
        backdrop.classList.remove('is-open');
        backdrop.setAttribute('aria-hidden', 'true');
    }

    trigger.addEventListener('click', function (e) {
        e.preventDefault();
        copyFeed();

        trigger.classList.add('is-copied');
        var label = trigger.querySelector('.gm-rss-pill-label');
        if (label) label.textContent = 'Copied!';

        setTimeout(function () {
            trigger.classList.remove('is-copied');
            if (label) label.textContent = 'RSS';
        }, 2500);

        openModal();
    });

    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            copyFeed();
            var origText = copyBtn.textContent;
            copyBtn.textContent = 'Copied! ✓';
            setTimeout(function () { copyBtn.textContent = origText; }, 2000);
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }

    backdrop.addEventListener('click', function (e) {
        if (e.target === backdrop) closeModal();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && backdrop.classList.contains('is-open')) {
            closeModal();
        }
    });
})();

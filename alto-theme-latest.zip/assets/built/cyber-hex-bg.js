/**
 * Advanced Cyber Telemetry & Ambient Nebula Background Engine
 * PedoHunters Custom Alto Theme Design System
 * 
 * Features:
 *  1. Floating Ambient Nebula Orbs (smooth drifting cyan & indigo light clouds)
 *  2. High-Luminance Cryptographic Telemetry Streams (glowing lead glyphs, hex cascades, packet bursts)
 *  3. Periodic Telemetry Laser Scanline Sweep (smooth diagnostic radar wave)
 *  4. Interactive Cursor Energy Spotlight & Ripple Reactivity
 *  5. Dynamic Light / Dark mode transition with smooth interpolation
 *  6. 60 FPS hardware-accelerated canvas with zero scroll jitter
 */
(function() {
  'use strict';
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  function initCyberEngine() {
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'gm-cyber-hex-canvas';
      document.body.prepend(canvas);
    }

    var ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    var w = (canvas.width = document.documentElement.clientWidth || window.innerWidth);
    var h = (canvas.height = document.documentElement.clientHeight || window.innerHeight);

    var hexChars = "0123456789ABCDEF";
    var leadGlyphs = ["0x", "::", "//", ">>", "[OK]", "[SYNC]", "[ENC]", ""];
    var colWidth = 32;
    var columns = [];

    // Ambient floating nebula orbs
    var orbs = [
      { x: w * 0.25, y: h * 0.3, radius: Math.min(w, h) * 0.48, vx: 0.25, vy: 0.18, colorDark: "0, 229, 255", colorLight: "14, 165, 233", alphaDark: 0.10, alphaLight: 0.08 },
      { x: w * 0.75, y: h * 0.65, radius: Math.min(w, h) * 0.52, vx: -0.22, vy: -0.15, colorDark: "99, 102, 241", colorLight: "99, 102, 241", alphaDark: 0.09, alphaLight: 0.07 },
      { x: w * 0.5, y: h * 0.85, radius: Math.min(w, h) * 0.40, vx: 0.18, vy: -0.2, colorDark: "168, 85, 247", colorLight: "168, 85, 247", alphaDark: 0.06, alphaLight: 0.05 }
    ];

    // Scanline sweep state
    var scanline = {
      y: -100,
      speed: 1.8,
      lastCycle: 0,
      active: true
    };

    function createColumn(x) {
      var isFast = Math.random() < 0.18;
      var streamLength = Math.floor(Math.random() * 16) + 12;
      var chars = [];
      for (var j = 0; j < streamLength; j++) {
        chars.push(hexChars[Math.floor(Math.random() * hexChars.length)]);
      }
      return {
        x: x,
        y: Math.random() * h,
        speed: isFast ? (Math.random() * 1.8 + 2.4) : (Math.random() * 0.9 + 1.2),
        chars: chars,
        leadGlyph: leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)],
        baseAlpha: Math.random() * 0.15 + 0.12,
        isFast: isFast
      };
    }

    function initColumns() {
      columns = [];
      var total = Math.ceil(w / colWidth) + 1;
      for (var i = 0; i < total; i++) {
        columns.push(createColumn(i * colWidth));
      }
    }

    function resize() {
      var newW = document.documentElement.clientWidth || window.innerWidth;
      var newH = document.documentElement.clientHeight || window.innerHeight;

      if (newW === w && Math.abs(newH - h) < 120) {
        h = canvas.height = newH;
        return;
      }

      var widthChanged = (newW !== w);
      w = canvas.width = newW;
      h = canvas.height = newH;

      if (widthChanged) {
        var targetCols = Math.ceil(w / colWidth) + 1;
        while (columns.length < targetCols) {
          var idx = columns.length;
          columns.push(createColumn(idx * colWidth));
        }
        if (columns.length > targetCols) {
          columns.length = targetCols;
        }
      }
    }

    var mouse = { x: -1000, y: -1000, targetX: -1000, targetY: -1000 };
    window.addEventListener('mousemove', function(e) {
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
      if (mouse.x < -500) {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
      }
    }, { passive: true });

    window.addEventListener('mouseout', function() {
      mouse.targetX = -1000;
      mouse.targetY = -1000;
    });

    window.addEventListener('resize', resize, { passive: true });

    var isPaused = false;
    document.addEventListener('visibilitychange', function() {
      isPaused = document.hidden;
    });

    // Theme interpolation
    var isLight = false;
    var current = {
      leadR: 0, leadG: 229, leadB: 255,
      trailR: 56, trailG: 189, trailB: 248,
      leadAlpha: 0.88,
      trailAlphaMult: 1.15
    };

    var fontStack = "11px ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace";
    var frameCount = 0;

    function render() {
      if (isPaused) {
        requestAnimationFrame(render);
        return;
      }

      frameCount++;
      ctx.clearRect(0, 0, w, h);

      // Smooth mouse follow
      if (mouse.targetX > -500) {
        mouse.x += (mouse.targetX - mouse.x) * 0.12;
        mouse.y += (mouse.targetY - mouse.y) * 0.12;
      } else {
        mouse.x = -1000;
        mouse.y = -1000;
      }

      // Detect theme dynamically
      isLight = document.documentElement.classList.contains('light-mode') || 
                document.documentElement.getAttribute('data-theme') === 'light';

      // Colors
      // Dark mode: Neon cyan lead with soft azure trail
      // Light mode: Deep tech cyan lead with slate-blue trail
      var targetLeadR = isLight ? 2 : 0;
      var targetLeadG = isLight ? 132 : 240;
      var targetLeadB = isLight ? 199 : 255;

      var targetTrailR = isLight ? 14 : 56;
      var targetTrailG = isLight ? 116 : 189;
      var targetTrailB = isLight ? 144 : 248;

      var targetLeadAlpha = isLight ? 0.75 : 0.90;
      var targetTrailAlphaMult = isLight ? 0.90 : 1.25;

      current.leadR += (targetLeadR - current.leadR) * 0.1;
      current.leadG += (targetLeadG - current.leadG) * 0.1;
      current.leadB += (targetLeadB - current.leadB) * 0.1;

      current.trailR += (targetTrailR - current.trailR) * 0.1;
      current.trailG += (targetTrailG - current.trailG) * 0.1;
      current.trailB += (targetTrailB - current.trailB) * 0.1;

      current.leadAlpha += (targetLeadAlpha - current.leadAlpha) * 0.1;
      current.trailAlphaMult += (targetTrailAlphaMult - current.trailAlphaMult) * 0.1;

      var lR = Math.round(current.leadR);
      var lG = Math.round(current.leadG);
      var lB = Math.round(current.leadB);

      var tR = Math.round(current.trailR);
      var tG = Math.round(current.trailG);
      var tB = Math.round(current.trailB);

      // ==============================================================
      // EFFECT 1: Ambient Drifting Nebula Orbs (Deep cinematic lighting)
      // ==============================================================
      for (var o = 0; o < orbs.length; o++) {
        var orb = orbs[o];
        orb.x += orb.vx;
        orb.y += orb.vy;

        // Bounce gently inside canvas bounds
        if (orb.x < -orb.radius * 0.5 || orb.x > w + orb.radius * 0.5) orb.vx *= -1;
        if (orb.y < -orb.radius * 0.5 || orb.y > h + orb.radius * 0.5) orb.vy *= -1;

        var orbColor = isLight ? orb.colorLight : orb.colorDark;
        var orbAlpha = isLight ? orb.alphaLight : orb.alphaDark;

        var grad = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.radius);
        grad.addColorStop(0, "rgba(" + orbColor + "," + orbAlpha + ")");
        grad.addColorStop(0.5, "rgba(" + orbColor + "," + (orbAlpha * 0.45) + ")");
        grad.addColorStop(1, "rgba(" + orbColor + ",0)");

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Interactive cursor spotlight nebula
      if (mouse.x > -500 && mouse.y > -500) {
        var cursorSpot = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, 240);
        var spotColor = isLight ? "2, 132, 199" : "0, 229, 255";
        var spotAlpha = isLight ? 0.09 : 0.14;
        cursorSpot.addColorStop(0, "rgba(" + spotColor + "," + spotAlpha + ")");
        cursorSpot.addColorStop(0.6, "rgba(" + spotColor + "," + (spotAlpha * 0.3) + ")");
        cursorSpot.addColorStop(1, "rgba(" + spotColor + ",0)");
        ctx.fillStyle = cursorSpot;
        ctx.beginPath();
        ctx.arc(mouse.x, mouse.y, 240, 0, Math.PI * 2);
        ctx.fill();
      }

      // ==============================================================
      // EFFECT 2: Periodic Telemetry Laser Scanline Sweep
      // ==============================================================
      scanline.y += scanline.speed;
      if (scanline.y > h + 150) {
        // Reset every ~10-12 seconds
        if (!scanline.lastCycle) scanline.lastCycle = frameCount;
        if (frameCount - scanline.lastCycle > 360) {
          scanline.y = -60;
          scanline.lastCycle = frameCount;
          scanline.speed = Math.random() * 0.6 + 1.8;
        }
      } else if (scanline.y > -50) {
        var scanGrad = ctx.createLinearGradient(0, scanline.y - 45, 0, scanline.y + 4);
        var scanR = isLight ? 2 : 0;
        var scanG = isLight ? 132 : 229;
        var scanB = isLight ? 199 : 255;
        var scanAlpha = isLight ? 0.09 : 0.16;

        scanGrad.addColorStop(0, "rgba(" + scanR + "," + scanG + "," + scanB + ", 0)");
        scanGrad.addColorStop(0.85, "rgba(" + scanR + "," + scanG + "," + scanB + ", " + (scanAlpha * 0.5) + ")");
        scanGrad.addColorStop(1, "rgba(" + scanR + "," + scanG + "," + scanB + ", " + scanAlpha + ")");

        ctx.fillStyle = scanGrad;
        ctx.fillRect(0, scanline.y - 45, w, 49);

        // Bright laser hairline
        ctx.fillStyle = "rgba(" + scanR + "," + scanG + "," + scanB + ", " + (scanAlpha * 1.9) + ")";
        ctx.fillRect(0, scanline.y + 3, w, 1.5);
      }

      // ==============================================================
      // EFFECT 3: Cryptographic Telemetry Digital Stream
      // ==============================================================
      ctx.font = fontStack;

      for (var k = 0; k < columns.length; k++) {
        var col = columns[k];
        col.y += col.speed;
        if (col.y > h + 300) {
          col.y = -80;
          col.isFast = Math.random() < 0.18;
          col.speed = col.isFast ? (Math.random() * 1.8 + 2.4) : (Math.random() * 0.9 + 1.2);
          col.leadGlyph = leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)];
        }

        // Ambient cryptographic mutation (active byte decryptions)
        if (Math.random() < 0.06) {
          var randIdx = Math.floor(Math.random() * col.chars.length);
          col.chars[randIdx] = hexChars[Math.floor(Math.random() * hexChars.length)];
        }

        // Proximity glow to cursor
        var dx = Math.abs(mouse.x - col.x);
        var hoverBoost = 0;
        if (mouse.x > -500 && dx < 180) {
          hoverBoost = (1 - dx / 180) * (isLight ? 0.24 : 0.38);
        }

        // Scanline intersection boost
        var scanlineDist = Math.abs(scanline.y - col.y);
        var scanBoost = (scanlineDist < 90) ? (1 - scanlineDist / 90) * 0.22 : 0;

        for (var i = 0; i < col.chars.length; i++) {
          var charY = col.y - (i * 16);
          if (charY < -20 || charY > h + 20) continue;

          var charText = (i === 0 && col.leadGlyph) ? col.leadGlyph : col.chars[i];

          if (i === 0) {
            // Glowing lead glyph
            var leadA = Math.min(1.0, current.leadAlpha + hoverBoost + scanBoost);
            ctx.fillStyle = "rgba(" + lR + "," + lG + "," + lB + "," + leadA.toFixed(3) + ")";
            
            // Subtle glow for lead
            if (!isLight) {
              ctx.shadowColor = "rgba(0, 229, 255, 0.75)";
              ctx.shadowBlur = 10;
            } else {
              ctx.shadowColor = "rgba(2, 132, 199, 0.45)";
              ctx.shadowBlur = 6;
            }
            ctx.fillText(charText, col.x, charY);
            ctx.shadowBlur = 0;
          } else {
            // Smoothly decaying trailing stream with healthy, noticeable visibility
            var streamPos = (1 - (i / col.chars.length));
            var charFade = streamPos * (col.baseAlpha * current.trailAlphaMult + hoverBoost + scanBoost);
            charFade = Math.min(0.80, Math.max(0.06, charFade));

            ctx.fillStyle = "rgba(" + tR + "," + tG + "," + tB + "," + charFade.toFixed(3) + ")";
            ctx.fillText(charText, col.x, charY);
          }
        }
      }

      requestAnimationFrame(render);
    }

    initColumns();
    requestAnimationFrame(render);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCyberEngine);
  } else {
    initCyberEngine();
  }
})();

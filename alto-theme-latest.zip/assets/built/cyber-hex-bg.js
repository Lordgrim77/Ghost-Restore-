/**
 * Professional Cryptographic Telemetry Background
 * Ambient, balanced hexadecimal stream blending seamlessly into light and dark modes.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  function run() {
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'gm-cyber-hex-canvas';
      document.body.prepend(canvas);
    }

    var ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    var w = 0;
    var h = 0;

    function resize() {
      // Use documentElement client dimensions to match exact viewport without scrollbar overflow
      w = canvas.width = document.documentElement.clientWidth || window.innerWidth;
      h = canvas.height = document.documentElement.clientHeight || window.innerHeight;
      initColumns();
    }

    var mouse = { x: -1000, y: -1000 };
    window.addEventListener('mousemove', function(e) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }, { passive: true });

    window.addEventListener('mouseout', function() {
      mouse.x = -1000;
      mouse.y = -1000;
    });

    window.addEventListener('resize', resize, { passive: true });

    // Cryptographic uppercase hex & technical glyphs
    var hexChars = "0123456789ABCDEF";
    var leadGlyphs = ["0x", "::", "//", ">>", ""];
    var columns = [];

    function initColumns() {
      columns = [];
      var colWidth = 36;
      // Guarantee edge-to-edge coverage across landscape screens
      var total = Math.ceil(w / colWidth) + 1;

      for (var i = 0; i < total; i++) {
        var streamLength = Math.floor(Math.random() * 14) + 14;
        var chars = [];
        for (var j = 0; j < streamLength; j++) {
          chars.push(hexChars[Math.floor(Math.random() * hexChars.length)]);
        }

        columns.push({
          x: i * colWidth,
          y: Math.random() * h,
          speed: Math.random() * 0.85 + 0.55,
          chars: chars,
          leadGlyph: leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)],
          baseAlpha: Math.random() * 0.07 + 0.035
        });
      }
    }

    var isPaused = false;
    document.addEventListener('visibilitychange', function() {
      isPaused = document.hidden;
    });

    // Theme color interpolation
    var isLight = false;
    var current = {
      baseR: 160, baseG: 175, baseB: 200,
      headR: 255, headG: 255, headB: 255,
      headAlpha: 0.32,
      baseAlphaMult: 1.0
    };

    var fontStack = "11px ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace";

    function render() {
      if (isPaused) {
        requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, w, h);

      // Detect theme dynamically
      isLight = document.documentElement.classList.contains('light-mode') || 
                document.documentElement.getAttribute('data-theme') === 'light';

      var targetBaseR = isLight ? 71 : 160;
      var targetBaseG = isLight ? 85 : 175;
      var targetBaseB = isLight ? 105 : 200;

      var targetHeadR = isLight ? 17 : 255;
      var targetHeadG = isLight ? 24 : 255;
      var targetHeadB = isLight ? 39 : 255;

      var targetHeadAlpha = isLight ? 0.22 : 0.32;
      var targetBaseAlphaMult = isLight ? 0.75 : 1.0;

      current.baseR += (targetBaseR - current.baseR) * 0.12;
      current.baseG += (targetBaseG - current.baseG) * 0.12;
      current.baseB += (targetBaseB - current.baseB) * 0.12;

      current.headR += (targetHeadR - current.headR) * 0.12;
      current.headG += (targetHeadG - current.headG) * 0.12;
      current.headB += (targetHeadB - current.headB) * 0.12;

      current.headAlpha += (targetHeadAlpha - current.headAlpha) * 0.12;
      current.baseAlphaMult += (targetBaseAlphaMult - current.baseAlphaMult) * 0.12;

      var bR = Math.round(current.baseR);
      var bG = Math.round(current.baseG);
      var bB = Math.round(current.baseB);

      var hR = Math.round(current.headR);
      var hG = Math.round(current.headG);
      var hB = Math.round(current.headB);

      ctx.font = fontStack;

      for (var k = 0; k < columns.length; k++) {
        var col = columns[k];
        col.y += col.speed;
        if (col.y > h + 280) {
          col.y = -80;
          col.speed = Math.random() * 0.85 + 0.55;
        }

        // Ambient cryptographic mutation
        if (Math.random() < 0.04) {
          var randIdx = Math.floor(Math.random() * col.chars.length);
          col.chars[randIdx] = hexChars[Math.floor(Math.random() * hexChars.length)];
        }

        // Soft interactive proximity glow
        var dx = Math.abs(mouse.x - col.x);
        var hoverBoost = (dx < 140) ? (1 - dx / 140) * (isLight ? 0.08 : 0.15) : 0;

        for (var i = 0; i < col.chars.length; i++) {
          var charY = col.y - (i * 15);
          if (charY < -20 || charY > h + 20) continue;

          var charText = (i === 0 && col.leadGlyph) ? col.leadGlyph : col.chars[i];

          if (i === 0) {
            var leadA = (current.headAlpha + hoverBoost);
            ctx.fillStyle = "rgba(" + hR + "," + hG + "," + hB + "," + leadA.toFixed(3) + ")";
          } else {
            var fade = (1 - (i / col.chars.length)) * (col.baseAlpha * current.baseAlphaMult + hoverBoost);
            ctx.fillStyle = "rgba(" + bR + "," + bG + "," + bB + "," + fade.toFixed(3) + ")";
          }

          ctx.fillText(charText, col.x, charY);
        }
      }

      requestAnimationFrame(render);
    }

    resize();
    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();

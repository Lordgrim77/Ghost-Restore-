/**
 * Advanced High-Contrast Cryptographic Telemetry Background Engine
 * Custom Alto Theme Design System
 * 
 * Features:
 *  1. Monochrome High-Contrast Digital Rain: Pure White for Dark Mode, Pitch Black for Light Mode
 *  2. Ambient Luminescent Atmospheric Orbs (smooth drifting monochrome lighting)
 *  3. Interactive Cursor Energy Spotlight with localized character illumination
 *  4. Clean, seamless execution with zero horizontal line artifacts
 *  5. 60 FPS hardware-accelerated canvas with zero scroll jitter
 *  6. Instant start: Executes immediately on frame 0 without waiting for DOMContentLoaded or window.load
 */
(function() {
  'use strict';
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var isEngineStarted = false;


  function initCyberEngine() {
    if (isEngineStarted) return;
    
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'gm-cyber-hex-canvas';
      if (document.body) {
        document.body.prepend(canvas);
      } else {
        document.documentElement.appendChild(canvas);
      }
    }

    var ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;
    isEngineStarted = true;

    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    var w = document.documentElement.clientWidth || window.innerWidth;
    var h = document.documentElement.clientHeight || window.innerHeight;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    var hexChars = "0123456789ABCDEF";
    var leadGlyphs = ["0x", "::", "//", ">>", "[OK]", "[SYNC]", "[ENC]", ""];
    var colWidth = 32;
    var columns = [];

    function createRadialSprite(size, rgb, alpha, midStop, midMult) {
      var off = document.createElement('canvas');
      off.width = size;
      off.height = size;
      var octx = off.getContext('2d');
      if (!octx) return null;
      var r = size / 2;
      var g = octx.createRadialGradient(r, r, 0, r, r, r);
      g.addColorStop(0, "rgba(" + rgb + "," + alpha + ")");
      g.addColorStop(midStop, "rgba(" + rgb + "," + (alpha * midMult) + ")");
      g.addColorStop(1, "rgba(" + rgb + ",0)");
      octx.fillStyle = g;
      octx.fillRect(0, 0, size, size);
      return off;
    }

    // Ambient floating atmospheric orbs with pre-baked gradient sprites (zero per-frame gradient allocations)
    var orbs = [
      { x: w * 0.25, y: h * 0.3, radius: Math.min(w, h) * 0.48, vx: 0.22, vy: 0.16, spriteDark: createRadialSprite(128, "255, 255, 255", 0.05, 0.5, 0.4), spriteLight: createRadialSprite(128, "0, 0, 0", 0.03, 0.5, 0.4) },
      { x: w * 0.75, y: h * 0.65, radius: Math.min(w, h) * 0.52, vx: -0.20, vy: -0.14, spriteDark: createRadialSprite(128, "241, 245, 249", 0.04, 0.5, 0.4), spriteLight: createRadialSprite(128, "51, 65, 85", 0.025, 0.5, 0.4) },
      { x: w * 0.5, y: h * 0.85, radius: Math.min(w, h) * 0.40, vx: 0.16, vy: -0.18, spriteDark: createRadialSprite(128, "226, 232, 240", 0.035, 0.5, 0.4), spriteLight: createRadialSprite(128, "100, 116, 139", 0.02, 0.5, 0.4) }
    ];
    var cursorSpriteDark = createRadialSprite(128, "255, 255, 255", 0.08, 0.6, 0.25);
    var cursorSpriteLight = createRadialSprite(128, "0, 0, 0", 0.05, 0.6, 0.25);

    function createColumn(x) {
      var isFast = Math.random() < 0.18;
      var streamLength = Math.floor(Math.random() * 16) + 12;
      var chars = [];
      for (var j = 0; j < streamLength; j++) {
        chars.push(hexChars[Math.floor(Math.random() * hexChars.length)]);
      }
      return {
        x: x,
        y: Math.random() * h,
        speed: isFast ? (Math.random() * 1.8 + 2.2) : (Math.random() * 0.9 + 1.1),
        chars: chars,
        leadGlyph: leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)],
        baseAlpha: Math.random() * 0.16 + 0.14,
        isFast: isFast
      };
    }

    function initColumns() {
      columns = [];
      var total = Math.ceil(w / colWidth) + 1;
      for (var i = 0; i < total; i++) {
        columns.push(createColumn(i * colWidth));
      }
    }

    function resize() {
      var newW = document.documentElement.clientWidth || window.innerWidth;
      var newH = document.documentElement.clientHeight || window.innerHeight;
      var newDpr = Math.min(window.devicePixelRatio || 1, 1.5);

      // Preserve existing canvas backing store across mobile URL-bar height shifts to prevent blank flashes
      if (newW === w && newDpr === dpr && Math.abs(newH - h) < 140) {
        return;
      }

      var widthChanged = (newW !== w);
      w = newW;
      h = newH;
      dpr = newDpr;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      if (widthChanged) {
        var targetCols = Math.ceil(w / colWidth) + 1;
        while (columns.length < targetCols) {
          var idx = columns.length;
          columns.push(createColumn(idx * colWidth));
        }
        if (columns.length > targetCols) {
          columns.length = targetCols;
        }
      }

      drawFrame(true);
    }

    var supportsHover = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);
    var mouse = { x: -1000, y: -1000, targetX: -1000, targetY: -1000 };
    if (supportsHover) {
      window.addEventListener('mousemove', function(e) {
        mouse.targetX = e.clientX;
        mouse.targetY = e.clientY;
        if (mouse.x < -500) {
          mouse.x = e.clientX;
          mouse.y = e.clientY;
        }
      }, { passive: true });

      window.addEventListener('mouseout', function() {
        mouse.targetX = -1000;
        mouse.targetY = -1000;
      });
    }

    window.addEventListener('resize', resize, { passive: true });
    window.addEventListener('load', resize, { passive: true });
    document.addEventListener('DOMContentLoaded', resize, { passive: true });

    var motionQuery = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
    var prefersReducedMotion = !!(motionQuery && motionQuery.matches);
    var isPaused = !!document.hidden;
    var isScrolling = false;
    var scrollResumeTimer = null;
    var rafId = null;

    function scheduleNextFrame() {
      if (rafId !== null || isPaused || isScrolling || prefersReducedMotion) return;
      rafId = requestAnimationFrame(render);
    }

    document.addEventListener('visibilitychange', function() {
      isPaused = !!document.hidden;
      if (isPaused && rafId !== null) {
        cancelAnimationFrame(rafId);
        rafId = null;
      } else if (!isPaused) {
        scheduleNextFrame();
      }
    });

    function onScrollEnd() {
      if (scrollResumeTimer) {
        clearTimeout(scrollResumeTimer);
        scrollResumeTimer = null;
      }
      if (!isScrolling) return;
      isScrolling = false;
      scheduleNextFrame();
    }

    window.addEventListener('scroll', function() {
      if (!isScrolling) {
        isScrolling = true;
        if (rafId !== null) {
          cancelAnimationFrame(rafId);
          rafId = null;
        }
      }
      if (scrollResumeTimer) clearTimeout(scrollResumeTimer);
      scrollResumeTimer = setTimeout(onScrollEnd, 140);
    }, { passive: true });

    window.addEventListener('scrollend', onScrollEnd, { passive: true });

    if (motionQuery && motionQuery.addEventListener) {
      motionQuery.addEventListener('change', function(e) {
        prefersReducedMotion = !!e.matches;
        if (prefersReducedMotion && rafId !== null) {
          cancelAnimationFrame(rafId);
          rafId = null;
          drawFrame(true);
        } else if (!prefersReducedMotion) {
          scheduleNextFrame();
        }
      });
    }

    // Theme interpolation
    // Dark mode: pure white (255, 255, 255)
    // Light mode: pure black (0, 0, 0)
    var isLight = false;
    var current = {
      leadR: 255, leadG: 255, leadB: 255,
      trailR: 245, trailG: 245, trailB: 250,
      leadAlpha: 0.95,
      trailAlphaMult: 1.2
    };

    var fontStack = "11px ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace";

    function drawFrame(isStatic) {
      ctx.clearRect(0, 0, w, h);

      // Smooth mouse follow
      if (!isStatic && supportsHover && mouse.targetX > -500) {
        mouse.x += (mouse.targetX - mouse.x) * 0.12;
        mouse.y += (mouse.targetY - mouse.y) * 0.12;
      } else {
        mouse.x = -1000;
        mouse.y = -1000;
      }

      // Detect theme dynamically
      isLight = document.documentElement.classList.contains('light-mode') || 
                document.documentElement.getAttribute('data-theme') === 'light' ||
                (document.body && document.body.classList.contains('light-mode'));

      // Target colors:
      // Dark mode: Pure White (255, 255, 255) for maximum crisp contrast on obsidian
      // Light mode: Pure Black (0, 0, 0) for maximum sharp contrast on clean background
      var targetLeadR = isLight ? 0 : 255;
      var targetLeadG = isLight ? 0 : 255;
      var targetLeadB = isLight ? 0 : 255;

      var targetTrailR = isLight ? 15 : 240;
      var targetTrailG = isLight ? 23 : 245;
      var targetTrailB = isLight ? 42 : 255;

      var targetLeadAlpha = isLight ? 0.88 : 0.95;
      var targetTrailAlphaMult = isLight ? 1.05 : 1.25;

      var lerp = isStatic ? 1 : 0.12;
      current.leadR += (targetLeadR - current.leadR) * lerp;
      current.leadG += (targetLeadG - current.leadG) * lerp;
      current.leadB += (targetLeadB - current.leadB) * lerp;

      current.trailR += (targetTrailR - current.trailR) * lerp;
      current.trailG += (targetTrailG - current.trailG) * lerp;
      current.trailB += (targetTrailB - current.trailB) * lerp;

      current.leadAlpha += (targetLeadAlpha - current.leadAlpha) * lerp;
      current.trailAlphaMult += (targetTrailAlphaMult - current.trailAlphaMult) * lerp;

      var lR = Math.round(current.leadR);
      var lG = Math.round(current.leadG);
      var lB = Math.round(current.leadB);

      var tR = Math.round(current.trailR);
      var tG = Math.round(current.trailG);
      var tB = Math.round(current.trailB);

      // ==============================================================
      // EFFECT 1: Ambient Drifting Atmospheric Light Orbs
      // ==============================================================
      for (var o = 0; o < orbs.length; o++) {
        var orb = orbs[o];
        if (!isStatic) {
          orb.x += orb.vx;
          orb.y += orb.vy;

          // Bounce gently inside canvas bounds
          if (orb.x < -orb.radius * 0.5 || orb.x > w + orb.radius * 0.5) orb.vx *= -1;
          if (orb.y < -orb.radius * 0.5 || orb.y > h + orb.radius * 0.5) orb.vy *= -1;
        }

        var sprite = isLight ? orb.spriteLight : orb.spriteDark;
        if (sprite) {
          ctx.drawImage(sprite, orb.x - orb.radius, orb.y - orb.radius, orb.radius * 2, orb.radius * 2);
        }
      }

      // Interactive cursor spotlight
      if (supportsHover && mouse.x > -500 && mouse.y > -500) {
        var cSprite = isLight ? cursorSpriteLight : cursorSpriteDark;
        if (cSprite) {
          ctx.drawImage(cSprite, mouse.x - 220, mouse.y - 220, 440, 440);
        }
      }

      // ==============================================================
      // EFFECT 2: Monochrome Cryptographic Telemetry Stream (Digital Rain)
      // ==============================================================
      ctx.font = fontStack;

      for (var k = 0; k < columns.length; k++) {
        var col = columns[k];
        if (!isStatic) {
          col.y += col.speed;
          if (col.y > h + 300) {
            col.y = -80;
            col.isFast = Math.random() < 0.18;
            col.speed = col.isFast ? (Math.random() * 1.8 + 2.2) : (Math.random() * 0.9 + 1.1);
            col.leadGlyph = leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)];
          }

          // Cryptographic byte decryptions
          if (Math.random() < 0.06) {
            var randIdx = Math.floor(Math.random() * col.chars.length);
            col.chars[randIdx] = hexChars[Math.floor(Math.random() * hexChars.length)];
          }
        }

        // Proximity glow to cursor
        var hoverBoost = 0;
        if (supportsHover && mouse.x > -500) {
          var dx = Math.abs(mouse.x - col.x);
          if (dx < 180) {
            hoverBoost = (1 - dx / 180) * (isLight ? 0.25 : 0.35);
          }
        }

        for (var i = 0; i < col.chars.length; i++) {
          var charY = col.y - (i * 16);
          if (charY < -20 || charY > h + 20) continue;

          var charText = (i === 0 && col.leadGlyph) ? col.leadGlyph : col.chars[i];

          if (i === 0) {
            // High-luminance lead glyph (crisp without per-glyph GPU blur stalls)
            var leadA = Math.min(1.0, current.leadAlpha + hoverBoost);
            ctx.fillStyle = "rgba(" + lR + "," + lG + "," + lB + "," + leadA.toFixed(3) + ")";
            ctx.fillText(charText, col.x, charY);
          } else {
            // Trailing stream with clear, legible contrast
            var streamPos = (1 - (i / col.chars.length));
            var charFade = streamPos * (col.baseAlpha * current.trailAlphaMult + hoverBoost);
            charFade = Math.min(0.75, Math.max(0.06, charFade));

            ctx.fillStyle = "rgba(" + tR + "," + tG + "," + tB + "," + charFade.toFixed(3) + ")";
            ctx.fillText(charText, col.x, charY);
          }
        }
      }
    }

    function render() {
      rafId = null;
      if (isPaused || isScrolling || prefersReducedMotion) return;
      drawFrame(false);
      scheduleNextFrame();
    }

    if (typeof MutationObserver !== 'undefined') {
      new MutationObserver(function() {
        if (prefersReducedMotion || isPaused || isScrolling) {
          drawFrame(true);
        }
      }).observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'data-theme'] });
    }

    initColumns();
    drawFrame(true);
    scheduleNextFrame();
  }

  // Start IMMEDIATELY on script execution without waiting for DOMContentLoaded or window.load
  function startImmediately() {
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (canvas || (document.body && document.body.firstChild)) {
      initCyberEngine();
    } else if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initCyberEngine);
    } else {
      initCyberEngine();
    }
  }

  startImmediately();
})();

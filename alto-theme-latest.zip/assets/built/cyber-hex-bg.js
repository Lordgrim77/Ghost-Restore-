/**
 * Cyber Hex Stream Background Engine
 * Monochromatic hardware-accelerated cryptographic telemetry stream.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  // Respect reduced motion preferences
  var mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (mediaQuery.matches) return;

  function initCyberHex() {
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'gm-cyber-hex-canvas';
      canvas.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:0;pointer-events:none;opacity:0.85;';
      document.body.prepend(canvas);
    }

    var ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    var w = (canvas.width = window.innerWidth);
    var h = (canvas.height = window.innerHeight);

    var mouse = { x: -1000, y: -1000 };
    window.addEventListener('mousemove', function(e) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }, { passive: true });

    window.addEventListener('mouseout', function() {
      mouse.x = -1000;
      mouse.y = -1000;
    });

    window.addEventListener('resize', function() {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      initColumns();
    }, { passive: true });

    var charset = "0123456789ABCDEFabcdef><_#+-/*=~$%";
    var columns = [];

    function initColumns() {
      columns = [];
      var colWidth = 24;
      var total = Math.ceil(w / colWidth);

      for (var i = 0; i < total; i++) {
        columns.push({
          x: i * colWidth,
          y: Math.random() * h,
          speed: Math.random() * 1.6 + 0.8,
          chars: Array.from({ length: 28 }, function() {
            return charset[Math.floor(Math.random() * charset.length)];
          }),
          baseAlpha: Math.random() * 0.08 + 0.02
        });
      }
    }

    var isPaused = false;
    document.addEventListener('visibilitychange', function() {
      isPaused = document.hidden;
    });

    function render() {
      if (isPaused) {
        requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, w, h);

      var isLight = document.documentElement.classList.contains('light-mode') || 
                    document.documentElement.getAttribute('data-theme') === 'light';
      var r = isLight ? 0 : 255;
      var g = isLight ? 0 : 255;
      var b = isLight ? 0 : 255;

      ctx.font = "11px 'JetBrains Mono', monospace";

      for (var k = 0; k < columns.length; k++) {
        var col = columns[k];
        col.y += col.speed;
        if (col.y > h + 320) {
          col.y = -100;
          col.speed = Math.random() * 1.6 + 0.8;
        }

        // Mutation / decryption flutter
        if (Math.random() < 0.06) {
          var idx = Math.floor(Math.random() * col.chars.length);
          col.chars[idx] = charset[Math.floor(Math.random() * charset.length)];
        }

        // Proximity illumination to cursor
        var dx = Math.abs(mouse.x - col.x);
        var hoverBoost = dx < 140 ? (1 - dx / 140) * 0.28 : 0;

        for (var i = 0; i < col.chars.length; i++) {
          var charY = col.y - (i * 15);
          if (charY < -20 || charY > h + 20) continue;

          var alpha = (i === 0) 
            ? (0.35 + hoverBoost) 
            : (1 - (i / col.chars.length)) * (col.baseAlpha + hoverBoost);

          ctx.fillStyle = "rgba(" + r + "," + g + "," + b + "," + alpha + ")";
          ctx.fillText(col.chars[i], col.x, charY);
        }
      }

      requestAnimationFrame(render);
    }

    initColumns();
    requestAnimationFrame(render);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCyberHex);
  } else {
    initCyberHex();
  }
})();

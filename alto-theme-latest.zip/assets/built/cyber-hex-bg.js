/**
 * Professional Cryptographic Telemetry Background
 * Ambient, balanced hexadecimal stream blending seamlessly into light and dark modes.
 * Hardened against scroll-induced resize resets and viewport fluctuations.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  function run() {
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'gm-cyber-hex-canvas';
      document.body.prepend(canvas);
    }

    var ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    var w = (canvas.width = document.documentElement.clientWidth || window.innerWidth);
    var h = (canvas.height = document.documentElement.clientHeight || window.innerHeight);

    var hexChars = "0123456789ABCDEF";
    var leadGlyphs = ["0x", "::", "//", ">>", ""];
    var colWidth = 36;
    var columns = [];

    function createColumn(x) {
      var streamLength = Math.floor(Math.random() * 14) + 14;
      var chars = [];
      for (var j = 0; j < streamLength; j++) {
        chars.push(hexChars[Math.floor(Math.random() * hexChars.length)]);
      }
      return {
        x: x,
        y: Math.random() * h,
        speed: Math.random() * 0.85 + 0.55,
        chars: chars,
        leadGlyph: leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)],
        baseAlpha: Math.random() * 0.07 + 0.035
      };
    }

    function initColumns() {
      columns = [];
      var total = Math.ceil(w / colWidth) + 1;
      for (var i = 0; i < total; i++) {
        columns.push(createColumn(i * colWidth));
      }
    }

    function resize() {
      var newW = document.documentElement.clientWidth || window.innerWidth;
      var newH = document.documentElement.clientHeight || window.innerHeight;

      // Ignore trivial height-only changes caused by mobile address bar collapse on scroll
      if (newW === w && Math.abs(newH - h) < 120) {
        h = canvas.height = newH;
        return;
      }

      var widthChanged = (newW !== w);
      w = canvas.width = newW;
      h = canvas.height = newH;

      // If width changed (e.g. rotation/resize), preserve existing columns and only add/trim
      if (widthChanged) {
        var targetCols = Math.ceil(w / colWidth) + 1;
        while (columns.length < targetCols) {
          var idx = columns.length;
          columns.push(createColumn(idx * colWidth));
        }
        if (columns.length > targetCols) {
          columns.length = targetCols;
        }
      }
    }

    var mouse = { x: -1000, y: -1000 };
    window.addEventListener('mousemove', function(e) {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }, { passive: true });

    window.addEventListener('mouseout', function() {
      mouse.x = -1000;
      mouse.y = -1000;
    });

    window.addEventListener('resize', resize, { passive: true });

    var isPaused = false;
    document.addEventListener('visibilitychange', function() {
      isPaused = document.hidden;
    });

    // Theme color interpolation
    var isLight = false;
    var current = {
      baseR: 160, baseG: 175, baseB: 200,
      headR: 255, headG: 255, headB: 255,
      headAlpha: 0.32,
      baseAlphaMult: 1.0
    };

    var fontStack = "11px ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace";

    function render() {
      if (isPaused) {
        requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, w, h);

      // Detect theme dynamically
      isLight = document.documentElement.classList.contains('light-mode') || 
                document.documentElement.getAttribute('data-theme') === 'light';

      var targetBaseR = isLight ? 71 : 160;
      var targetBaseG = isLight ? 85 : 175;
      var targetBaseB = isLight ? 105 : 200;

      var targetHeadR = isLight ? 17 : 255;
      var targetHeadG = isLight ? 24 : 255;
      var targetHeadB = isLight ? 39 : 255;

      var targetHeadAlpha = isLight ? 0.22 : 0.32;
      var targetBaseAlphaMult = isLight ? 0.75 : 1.0;

      current.baseR += (targetBaseR - current.baseR) * 0.12;
      current.baseG += (targetBaseG - current.baseG) * 0.12;
      current.baseB += (targetBaseB - current.baseB) * 0.12;

      current.headR += (targetHeadR - current.headR) * 0.12;
      current.headG += (targetHeadG - current.headG) * 0.12;
      current.headB += (targetHeadB - current.headB) * 0.12;

      current.headAlpha += (targetHeadAlpha - current.headAlpha) * 0.12;
      current.baseAlphaMult += (targetBaseAlphaMult - current.baseAlphaMult) * 0.12;

      var bR = Math.round(current.baseR);
      var bG = Math.round(current.baseG);
      var bB = Math.round(current.baseB);

      var hR = Math.round(current.headR);
      var hG = Math.round(current.headG);
      var hB = Math.round(current.headB);

      ctx.font = fontStack;

      for (var k = 0; k < columns.length; k++) {
        var col = columns[k];
        col.y += col.speed;
        if (col.y > h + 280) {
          col.y = -80;
          col.speed = Math.random() * 0.85 + 0.55;
        }

        // Ambient cryptographic mutation
        if (Math.random() < 0.04) {
          var randIdx = Math.floor(Math.random() * col.chars.length);
          col.chars[randIdx] = hexChars[Math.floor(Math.random() * hexChars.length)];
        }

        // Soft interactive proximity glow
        var dx = Math.abs(mouse.x - col.x);
        var hoverBoost = (dx < 140) ? (1 - dx / 140) * (isLight ? 0.08 : 0.15) : 0;

        for (var i = 0; i < col.chars.length; i++) {
          var charY = col.y - (i * 15);
          if (charY < -20 || charY > h + 20) continue;

          var charText = (i === 0 && col.leadGlyph) ? col.leadGlyph : col.chars[i];

          if (i === 0) {
            var leadA = (current.headAlpha + hoverBoost);
            ctx.fillStyle = "rgba(" + hR + "," + hG + "," + hB + "," + leadA.toFixed(3) + ")";
          } else {
            var fade = (1 - (i / col.chars.length)) * (col.baseAlpha * current.baseAlphaMult + hoverBoost);
            ctx.fillStyle = "rgba(" + bR + "," + bG + "," + bB + "," + fade.toFixed(3) + ")";
          }

          ctx.fillText(charText, col.x, charY);
        }
      }

      requestAnimationFrame(render);
    }

    initColumns();
    requestAnimationFrame(render);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();

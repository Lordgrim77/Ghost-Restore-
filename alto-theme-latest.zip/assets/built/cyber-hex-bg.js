/**
 * Advanced High-Contrast Cryptographic Telemetry Background Engine
 * Custom Alto Theme Design System
 * 
 * Features:
 *  1. Monochrome High-Contrast Digital Rain: Pure White for Dark Mode, Pitch Black for Light Mode
 *  2. Ambient Luminescent Atmospheric Orbs (smooth drifting monochrome lighting)
 *  3. Interactive Cursor Energy Spotlight with localized character illumination
 *  4. Clean, seamless execution with zero horizontal line artifacts
 *  5. 60 FPS hardware-accelerated canvas with zero scroll jitter
 *  6. Instant start: Executes immediately on frame 0 without waiting for DOMContentLoaded or window.load
 */
(function() {
  'use strict';
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var isEngineStarted = false;


  function initCyberEngine() {
    if (isEngineStarted) return;
    
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'gm-cyber-hex-canvas';
      if (document.body) {
        document.body.prepend(canvas);
      } else {
        document.documentElement.appendChild(canvas);
      }
    }

    var ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;
    isEngineStarted = true;

    var w = (canvas.width = document.documentElement.clientWidth || window.innerWidth);
    var h = (canvas.height = document.documentElement.clientHeight || window.innerHeight);

    var hexChars = "0123456789ABCDEF";
    var leadGlyphs = ["0x", "::", "//", ">>", "[OK]", "[SYNC]", "[ENC]", ""];
    var colWidth = 32;
    var columns = [];

    // Ambient floating atmospheric orbs (Monochrome: White in dark mode, Black/slate in light mode)
    var orbs = [
      { x: w * 0.25, y: h * 0.3, radius: Math.min(w, h) * 0.48, vx: 0.22, vy: 0.16, colorDark: "255, 255, 255", colorLight: "0, 0, 0", alphaDark: 0.05, alphaLight: 0.03 },
      { x: w * 0.75, y: h * 0.65, radius: Math.min(w, h) * 0.52, vx: -0.20, vy: -0.14, colorDark: "241, 245, 249", colorLight: "51, 65, 85", alphaDark: 0.04, alphaLight: 0.025 },
      { x: w * 0.5, y: h * 0.85, radius: Math.min(w, h) * 0.40, vx: 0.16, vy: -0.18, colorDark: "226, 232, 240", colorLight: "100, 116, 139", alphaDark: 0.035, alphaLight: 0.02 }
    ];

    function createColumn(x) {
      var isFast = Math.random() < 0.18;
      var streamLength = Math.floor(Math.random() * 16) + 12;
      var chars = [];
      for (var j = 0; j < streamLength; j++) {
        chars.push(hexChars[Math.floor(Math.random() * hexChars.length)]);
      }
      return {
        x: x,
        y: Math.random() * h,
        speed: isFast ? (Math.random() * 1.8 + 2.2) : (Math.random() * 0.9 + 1.1),
        chars: chars,
        leadGlyph: leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)],
        baseAlpha: Math.random() * 0.16 + 0.14,
        isFast: isFast
      };
    }

    function initColumns() {
      columns = [];
      var total = Math.ceil(w / colWidth) + 1;
      for (var i = 0; i < total; i++) {
        columns.push(createColumn(i * colWidth));
      }
    }

    function resize() {
      var newW = document.documentElement.clientWidth || window.innerWidth;
      var newH = document.documentElement.clientHeight || window.innerHeight;

      if (newW === w && Math.abs(newH - h) < 120) {
        h = canvas.height = newH;
        return;
      }

      var widthChanged = (newW !== w);
      w = canvas.width = newW;
      h = canvas.height = newH;

      if (widthChanged) {
        var targetCols = Math.ceil(w / colWidth) + 1;
        while (columns.length < targetCols) {
          var idx = columns.length;
          columns.push(createColumn(idx * colWidth));
        }
        if (columns.length > targetCols) {
          columns.length = targetCols;
        }
      }
    }

    var mouse = { x: -1000, y: -1000, targetX: -1000, targetY: -1000 };
    window.addEventListener('mousemove', function(e) {
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
      if (mouse.x < -500) {
        mouse.x = e.clientX;
        mouse.y = e.clientY;
      }
    }, { passive: true });

    window.addEventListener('mouseout', function() {
      mouse.targetX = -1000;
      mouse.targetY = -1000;
    });

    window.addEventListener('resize', resize, { passive: true });
    window.addEventListener('load', resize, { passive: true });
    document.addEventListener('DOMContentLoaded', resize, { passive: true });

    var isPaused = false;
    document.addEventListener('visibilitychange', function() {
      isPaused = document.hidden;
    });

    // Theme interpolation
    // Dark mode: pure white (255, 255, 255)
    // Light mode: pure black (0, 0, 0)
    var isLight = false;
    var current = {
      leadR: 255, leadG: 255, leadB: 255,
      trailR: 245, trailG: 245, trailB: 250,
      leadAlpha: 0.95,
      trailAlphaMult: 1.2
    };

    var fontStack = "11px ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, 'Liberation Mono', monospace";

    function render() {
      if (isPaused) {
        requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, w, h);

      // Smooth mouse follow
      if (mouse.targetX > -500) {
        mouse.x += (mouse.targetX - mouse.x) * 0.12;
        mouse.y += (mouse.targetY - mouse.y) * 0.12;
      } else {
        mouse.x = -1000;
        mouse.y = -1000;
      }

      // Detect theme dynamically
      isLight = document.documentElement.classList.contains('light-mode') || 
                document.documentElement.getAttribute('data-theme') === 'light' ||
                (document.body && document.body.classList.contains('light-mode'));

      // Target colors:
      // Dark mode: Pure White (255, 255, 255) for maximum crisp contrast on obsidian
      // Light mode: Pure Black (0, 0, 0) for maximum sharp contrast on clean background
      var targetLeadR = isLight ? 0 : 255;
      var targetLeadG = isLight ? 0 : 255;
      var targetLeadB = isLight ? 0 : 255;

      var targetTrailR = isLight ? 15 : 240;
      var targetTrailG = isLight ? 23 : 245;
      var targetTrailB = isLight ? 42 : 255;

      var targetLeadAlpha = isLight ? 0.88 : 0.95;
      var targetTrailAlphaMult = isLight ? 1.05 : 1.25;

      current.leadR += (targetLeadR - current.leadR) * 0.12;
      current.leadG += (targetLeadG - current.leadG) * 0.12;
      current.leadB += (targetLeadB - current.leadB) * 0.12;

      current.trailR += (targetTrailR - current.trailR) * 0.12;
      current.trailG += (targetTrailG - current.trailG) * 0.12;
      current.trailB += (targetTrailB - current.trailB) * 0.12;

      current.leadAlpha += (targetLeadAlpha - current.leadAlpha) * 0.12;
      current.trailAlphaMult += (targetTrailAlphaMult - current.trailAlphaMult) * 0.12;

      var lR = Math.round(current.leadR);
      var lG = Math.round(current.leadG);
      var lB = Math.round(current.leadB);

      var tR = Math.round(current.trailR);
      var tG = Math.round(current.trailG);
      var tB = Math.round(current.trailB);

      // ==============================================================
      // EFFECT 1: Ambient Drifting Atmospheric Light Orbs
      // ==============================================================
      for (var o = 0; o < orbs.length; o++) {
        var orb = orbs[o];
        orb.x += orb.vx;
        orb.y += orb.vy;

        // Bounce gently inside canvas bounds
        if (orb.x < -orb.radius * 0.5 || orb.x > w + orb.radius * 0.5) orb.vx *= -1;
        if (orb.y < -orb.radius * 0.5 || orb.y > h + orb.radius * 0.5) orb.vy *= -1;

        var orbColor = isLight ? orb.colorLight : orb.colorDark;
        var orbAlpha = isLight ? orb.alphaLight : orb.alphaDark;

        var grad = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.radius);
        grad.addColorStop(0, "rgba(" + orbColor + "," + orbAlpha + ")");
        grad.addColorStop(0.5, "rgba(" + orbColor + "," + (orbAlpha * 0.4) + ")");
        grad.addColorStop(1, "rgba(" + orbColor + ",0)");

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Interactive cursor spotlight
      if (mouse.x > -500 && mouse.y > -500) {
        var cursorSpot = ctx.createRadialGradient(mouse.x, mouse.y, 0, mouse.x, mouse.y, 220);
        var spotColor = isLight ? "0, 0, 0" : "255, 255, 255";
        var spotAlpha = isLight ? 0.05 : 0.08;
        cursorSpot.addColorStop(0, "rgba(" + spotColor + "," + spotAlpha + ")");
        cursorSpot.addColorStop(0.6, "rgba(" + spotColor + "," + (spotAlpha * 0.25) + ")");
        cursorSpot.addColorStop(1, "rgba(" + spotColor + ",0)");
        ctx.fillStyle = cursorSpot;
        ctx.beginPath();
        ctx.arc(mouse.x, mouse.y, 220, 0, Math.PI * 2);
        ctx.fill();
      }

      // ==============================================================
      // EFFECT 2: Monochrome Cryptographic Telemetry Stream (Digital Rain)
      // ==============================================================
      ctx.font = fontStack;

      for (var k = 0; k < columns.length; k++) {
        var col = columns[k];
        col.y += col.speed;
        if (col.y > h + 300) {
          col.y = -80;
          col.isFast = Math.random() < 0.18;
          col.speed = col.isFast ? (Math.random() * 1.8 + 2.2) : (Math.random() * 0.9 + 1.1);
          col.leadGlyph = leadGlyphs[Math.floor(Math.random() * leadGlyphs.length)];
        }

        // Cryptographic byte decryptions
        if (Math.random() < 0.06) {
          var randIdx = Math.floor(Math.random() * col.chars.length);
          col.chars[randIdx] = hexChars[Math.floor(Math.random() * hexChars.length)];
        }

        // Proximity glow to cursor
        var dx = Math.abs(mouse.x - col.x);
        var hoverBoost = 0;
        if (mouse.x > -500 && dx < 180) {
          hoverBoost = (1 - dx / 180) * (isLight ? 0.25 : 0.35);
        }

        for (var i = 0; i < col.chars.length; i++) {
          var charY = col.y - (i * 16);
          if (charY < -20 || charY > h + 20) continue;

          var charText = (i === 0 && col.leadGlyph) ? col.leadGlyph : col.chars[i];

          if (i === 0) {
            // High-luminance lead glyph
            var leadA = Math.min(1.0, current.leadAlpha + hoverBoost);
            ctx.fillStyle = "rgba(" + lR + "," + lG + "," + lB + "," + leadA.toFixed(3) + ")";
            
            // Clean crisp shadow
            if (!isLight) {
              ctx.shadowColor = "rgba(255, 255, 255, 0.85)";
              ctx.shadowBlur = 8;
            } else {
              ctx.shadowColor = "rgba(0, 0, 0, 0.35)";
              ctx.shadowBlur = 4;
            }
            ctx.fillText(charText, col.x, charY);
            ctx.shadowBlur = 0;
          } else {
            // Trailing stream with clear, legible contrast
            var streamPos = (1 - (i / col.chars.length));
            var charFade = streamPos * (col.baseAlpha * current.trailAlphaMult + hoverBoost);
            charFade = Math.min(0.75, Math.max(0.06, charFade));

            ctx.fillStyle = "rgba(" + tR + "," + tG + "," + tB + "," + charFade.toFixed(3) + ")";
            ctx.fillText(charText, col.x, charY);
          }
        }
      }

      requestAnimationFrame(render);
    }

    initColumns();
    requestAnimationFrame(render);
  }

  // Start IMMEDIATELY on script execution without waiting for DOMContentLoaded or window.load
  function startImmediately() {
    var canvas = document.getElementById('gm-cyber-hex-canvas');
    if (canvas || (document.body && document.body.firstChild)) {
      initCyberEngine();
    } else if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initCyberEngine);
    } else {
      initCyberEngine();
    }
  }

  startImmediately();
})();

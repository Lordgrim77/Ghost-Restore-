/**
 * Cyber Splash Preloader Controller
 * Plays the 3D rotating glass emblem with cryptographic terminal logs.
 * Runs once per session via sessionStorage.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var hasShown = false;
  try {
    hasShown = sessionStorage.getItem('gm_cyber_splash_shown') === '1';
  } catch (e) {}

  // If already shown in session or prefers reduced motion, hide immediately
  if (hasShown || prefersReducedMotion) {
    var earlySplash = document.getElementById('gm-cyber-splash');
    if (earlySplash) {
      earlySplash.classList.add('gm-splash-hidden');
      earlySplash.remove();
    }
    return;
  }

  function initSplash() {
    var splash = document.getElementById('gm-cyber-splash');
    if (!splash) return;

    var terminal = splash.querySelector('.gm-splash-terminal');
    var bar = splash.querySelector('.gm-splash-progress-bar');
    var video = splash.querySelector('video');

    if (video) {
      video.play().catch(function() {});
    }

    var lines = [
      "[01] INITIALIZING HARDWARE ENCLAVE ... [OK]",
      "[02] ATTESTING CRYPTOGRAPHIC CHECKSUMS ... [PASS]",
      "[03] DECRYPTING THREAT RADAR FEED ... [ACTIVE]",
      "[04] ACCESS LEVEL: SOVEREIGN DEFENSE CLEARANCE GRANTED."
    ];

    var progress = 0;
    var lineIdx = 0;
    if (terminal) terminal.innerHTML = lines[0];

    var isDismissed = false;

    function dismiss() {
      if (isDismissed) return;
      isDismissed = true;
      try {
        sessionStorage.setItem('gm_cyber_splash_shown', '1');
      } catch (e) {}

      if (bar) bar.style.width = '100%';
      splash.classList.add('gm-splash-hidden');
      setTimeout(function() {
        if (splash && splash.parentNode) {
          splash.remove();
        }
      }, 600);
    }

    // Dismiss on click or ESC
    splash.addEventListener('click', dismiss);
    window.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') dismiss();
    });

    // Progress timer
    var timer = setInterval(function() {
      if (isDismissed) {
        clearInterval(timer);
        return;
      }

      progress += 2.5;
      if (bar) bar.style.width = Math.min(progress, 100) + '%';

      if (progress > 25 && lineIdx === 0) {
        lineIdx = 1;
        if (terminal) terminal.innerHTML += '<br>' + lines[1];
      } else if (progress > 55 && lineIdx === 1) {
        lineIdx = 2;
        if (terminal) terminal.innerHTML += '<br>' + lines[2];
      } else if (progress > 85 && lineIdx === 2) {
        lineIdx = 3;
        if (terminal) terminal.innerHTML += '<br>' + lines[3];
      }

      if (progress >= 100) {
        clearInterval(timer);
        setTimeout(dismiss, 350);
      }
    }, 55);

    // Safety fallback
    window.addEventListener('load', function() {
      setTimeout(function() {
        if (progress > 80) dismiss();
      }, 1000);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSplash);
  } else {
    initSplash();
  }
})();

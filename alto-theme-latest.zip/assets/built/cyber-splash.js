/**
 * Professional Site Preloader Controller
 * Displays clean site logo, "Loading <Project title>", and minimalist progress bar.
 * Runs once per session via sessionStorage.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var hasShown = false;
  try {
    hasShown = sessionStorage.getItem('gm_cyber_splash_shown') === '1';
  } catch (e) {}

  // If already shown in session, hide immediately
  if (hasShown) {
    var earlySplash = document.getElementById('gm-cyber-splash');
    if (earlySplash) {
      earlySplash.classList.add('gm-splash-hidden');
      earlySplash.remove();
    }
    return;
  }

  function initSplash() {
    var splash = document.getElementById('gm-cyber-splash');
    if (!splash) return;

    var bar = splash.querySelector('.gm-splash-progress-bar');
    var isDismissed = false;
    var progress = 0;

    function dismiss() {
      if (isDismissed) return;
      isDismissed = true;
      try {
        sessionStorage.setItem('gm_cyber_splash_shown', '1');
      } catch (e) {}

      if (bar) bar.style.width = '100%';
      splash.classList.add('gm-splash-hidden');
      setTimeout(function() {
        if (splash && splash.parentNode) {
          splash.remove();
        }
      }, 480);
    }

    // Dismiss immediately on user click or ESC key
    splash.addEventListener('click', dismiss);
    window.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') dismiss();
    });

    // Smooth progress animation (completes in ~1.0 second)
    var stepInterval = 25;
    var timer = setInterval(function() {
      if (isDismissed) {
        clearInterval(timer);
        return;
      }

      progress += 2.5;
      if (bar) bar.style.width = Math.min(progress, 100) + '%';

      if (progress >= 100) {
        clearInterval(timer);
        setTimeout(dismiss, 140);
      }
    }, stepInterval);

    // Maximum failsafe dismiss after 1.8 seconds
    setTimeout(dismiss, 1800);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSplash);
  } else {
    initSplash();
  }
})();

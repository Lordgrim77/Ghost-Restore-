/**
 * Professional Site Preloader Controller
 * Displays clean site logo, "Loading <Project title>", and minimalist progress bar.
 * Runs on initial visit, on page reload/refresh, and on EVERY article/post page.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var hasShown = false;
  var isReload = false;
  var isPost = false;

  try {
    var navEntries = window.performance && performance.getEntriesByType && performance.getEntriesByType('navigation');
    if (navEntries && navEntries.length > 0 && navEntries[0].type === 'reload') {
      isReload = true;
    } else if (window.performance && window.performance.navigation && window.performance.navigation.type === 1) {
      isReload = true;
    }

    // Detect if current page is an article/post
    isPost = (typeof window.gmIsPostPage !== 'undefined' && window.gmIsPostPage) ||
             (document.body && (document.body.classList.contains('post-template') || document.body.classList.contains('is-post')));

    if (isPost || isReload) {
      hasShown = false;
    } else {
      hasShown = sessionStorage.getItem('gm_cyber_splash_shown') === '1';
    }
  } catch (e) {}

  // If already shown on internal navigation AND NOT an article page, dismiss immediately
  if (hasShown && !isReload && !isPost) {
    var earlySplash = document.getElementById('gm-cyber-splash');
    if (earlySplash) {
      earlySplash.classList.add('gm-splash-hidden');
      earlySplash.remove();
    }
    return;
  }

  function initSplash() {
    var splash = document.getElementById('gm-cyber-splash');
    if (!splash) return;

    var bar = splash.querySelector('.gm-splash-progress-bar');
    var isDismissed = false;
    var progress = 0;

    function dismiss() {
      if (isDismissed) return;
      isDismissed = true;
      try {
        if (!isPost) {
          sessionStorage.setItem('gm_cyber_splash_shown', '1');
        }
      } catch (e) {}

      if (bar) bar.style.width = '100%';
      splash.classList.add('gm-splash-hidden');
      setTimeout(function() {
        if (splash && splash.parentNode) {
          splash.remove();
        }
      }, 380);
    }

    // Dismiss immediately on user click or ESC key
    splash.addEventListener('click', dismiss);
    window.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') dismiss();
    });

    // Smooth progress animation (completes in ~0.8s)
    var stepInterval = 20;
    var timer = setInterval(function() {
      if (isDismissed) {
        clearInterval(timer);
        return;
      }

      progress += 2.6;
      if (bar) bar.style.width = Math.min(progress, 100) + '%';

      if (progress >= 100) {
        clearInterval(timer);
        setTimeout(dismiss, 100);
      }
    }, stepInterval);

    // Maximum failsafe dismiss after 1.5 seconds
    setTimeout(dismiss, 1500);
  }

  // Initialize immediately if splash element is in DOM
  function tryInitSplash() {
    var splash = document.getElementById('gm-cyber-splash');
    if (splash) {
      initSplash();
    } else if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initSplash);
    } else {
      initSplash();
    }
  }

  tryInitSplash();

  // Instant preloader indicator when clicking article links
  document.addEventListener('click', function(e) {
    var a = e.target.closest('a');
    if (!a || !a.href || a.target === '_blank' || e.ctrlKey || e.metaKey || e.shiftKey) return;
    if (a.origin === window.location.origin) {
      var p = a.pathname || '';
      var isSpecial = p === '/' || p.startsWith('/tag/') || p.startsWith('/author/') || 
                      p.startsWith('/team/') || p.startsWith('/support/') || p.startsWith('/page/') ||
                      p.startsWith('/ghost/') || p.startsWith('/api/');
      if (!isSpecial && p.length > 3) {
        var bar = document.getElementById('gm-page-transition-bar');
        if (bar) {
          bar.style.opacity = '1';
          bar.style.transform = 'scaleX(0.7)';
        }
      }
    }
  }, { passive: true });
})();

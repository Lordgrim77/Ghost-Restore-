/**
 * Professional Site Preloader Controller
 * Displays clean site logo, "Loading <Project title>", and minimalist progress bar.
 * Runs on initial visit and on every page refresh/reload.
 */
(function() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  var hasShown = false;
  var isReload = false;
  try {
    var navEntries = window.performance && performance.getEntriesByType && performance.getEntriesByType('navigation');
    if (navEntries && navEntries.length > 0 && navEntries[0].type === 'reload') {
      isReload = true;
    } else if (window.performance && window.performance.navigation && window.performance.navigation.type === 1) {
      isReload = true;
    }

    if (isReload) {
      sessionStorage.removeItem('gm_cyber_splash_shown');
      hasShown = false;
    } else {
      hasShown = sessionStorage.getItem('gm_cyber_splash_shown') === '1';
    }
  } catch (e) {}

  // If already shown on internal navigation, dismiss immediately
  if (hasShown && !isReload) {
    var earlySplash = document.getElementById('gm-cyber-splash');
    if (earlySplash) {
      earlySplash.classList.add('gm-splash-hidden');
      earlySplash.remove();
    }
    return;
  }

  function initSplash() {
    var splash = document.getElementById('gm-cyber-splash');
    if (!splash) return;

    var bar = splash.querySelector('.gm-splash-progress-bar');
    var isDismissed = false;
    var progress = 0;

    function dismiss() {
      if (isDismissed) return;
      isDismissed = true;
      try {
        sessionStorage.setItem('gm_cyber_splash_shown', '1');
      } catch (e) {}

      if (bar) bar.style.width = '100%';
      splash.classList.add('gm-splash-hidden');
      setTimeout(function() {
        if (splash && splash.parentNode) {
          splash.remove();
        }
      }, 420);
    }

    // Dismiss immediately on user click or ESC key
    splash.addEventListener('click', dismiss);
    window.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') dismiss();
    });

    // Smooth progress animation (completes in ~0.95 second)
    var stepInterval = 25;
    var timer = setInterval(function() {
      if (isDismissed) {
        clearInterval(timer);
        return;
      }

      progress += 2.6;
      if (bar) bar.style.width = Math.min(progress, 100) + '%';

      if (progress >= 100) {
        clearInterval(timer);
        setTimeout(dismiss, 120);
      }
    }, stepInterval);

    // Maximum failsafe dismiss after 1.8 seconds
    setTimeout(dismiss, 1800);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSplash);
  } else {
    initSplash();
  }
})();

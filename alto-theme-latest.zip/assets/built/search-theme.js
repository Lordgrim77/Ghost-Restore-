/**
 * Ghost Sodo Search Glassmorphic Theme Engine
 * Synchronously discovers and styles the @tryghost/sodo-search modal iframe
 * Ensures 100% theme parity with Obsidian/Cyber Dark Mode and Clean Light Mode
 */
(function() {
    'use strict';

    const STYLE_ID = 'gm-sodo-search-injected-style';

    function getIsDark() {
        const root = document.documentElement;
        return root.classList.contains('dark-mode') ||
               root.getAttribute('data-theme') === 'dark' ||
               (!root.classList.contains('light-mode') &&
                window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }

    function generateSodoCss(isDark) {
        if (isDark) {
            return `
                /* ==========================================================
                   OBSIDIAN CYBER DARK MODE SODO SEARCH
                   ========================================================== */
                html, body {
                    background: transparent !important;
                    color-scheme: dark !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                }

                /* Backdrop Blur */
                div.bg-gradient-to-br,
                div[class*="backdrop-blur"] {
                    background: rgba(4, 6, 10, 0.85) !important;
                    backdrop-filter: blur(16px) !important;
                    -webkit-backdrop-filter: blur(16px) !important;
                }

                /* Modal Dialog Container */
                div[role="dialog"],
                .animate-popup {
                    background: rgba(14, 18, 27, 0.95) !important;
                    border: 1px solid rgba(255, 255, 255, 0.12) !important;
                    border-radius: 16px !important;
                    box-shadow: 0 24px 60px rgba(0, 0, 0, 0.8), 0 0 25px rgba(0, 229, 255, 0.08) !important;
                    backdrop-filter: blur(20px) !important;
                    -webkit-backdrop-filter: blur(20px) !important;
                    overflow: hidden !important;
                }

                /* Search Header Bar */
                div[role="dialog"] > div:first-child,
                div[role="dialog"] .bg-white.rounded-t-lg,
                div[role="dialog"] .bg-white.rounded-lg {
                    background: rgba(19, 25, 38, 0.98) !important;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
                    border-radius: 16px 16px 0 0 !important;
                    box-shadow: none !important;
                }

                /* Search Input Field */
                #sodo-search-input {
                    background: transparent !important;
                    color: #ffffff !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                    font-size: 1.15rem !important;
                    letter-spacing: -0.01em !important;
                }
                #sodo-search-input::placeholder {
                    color: rgba(255, 255, 255, 0.4) !important;
                }

                /* Search Icons */
                div[role="dialog"] svg {
                    color: rgba(255, 255, 255, 0.75) !important;
                    stroke: currentColor !important;
                }
                div[role="dialog"] svg path {
                    fill: currentColor !important;
                }

                /* Clear button */
                button[aria-label="Clear search"] svg:hover {
                    color: #ffffff !important;
                }

                /* Cancel button */
                div[role="dialog"] button.text-neutral-500 {
                    color: rgba(255, 255, 255, 0.6) !important;
                }
                div[role="dialog"] button.text-neutral-500:hover {
                    color: #ffffff !important;
                }

                /* Group Headers (Posts, Authors, Tags) */
                div[id*="-label"],
                div.uppercase.text-xs {
                    color: rgba(255, 255, 255, 0.45) !important;
                    font-family: 'Inter', sans-serif !important;
                    font-weight: 700 !important;
                    font-size: 11px !important;
                    letter-spacing: 0.08em !important;
                }
                div.border-neutral-200 {
                    border-color: rgba(255, 255, 255, 0.07) !important;
                }

                /* Result Item Cards */
                a[role="option"] {
                    background: transparent !important;
                    transition: background-color 0.15s ease, transform 0.15s ease !important;
                    border-radius: 10px !important;
                    margin: 2px 0 !important;
                    padding: 10px 16px !important;
                }
                a[role="option"]:hover,
                a[role="option"][aria-selected="true"] {
                    background: rgba(255, 255, 255, 0.08) !important;
                }

                /* Result Title */
                a[role="option"] div[class*="text-[1.65rem]"],
                a[role="option"] .text-neutral-800 {
                    color: #f8fafc !important;
                    font-family: 'Inter', sans-serif !important;
                    font-size: 1.05rem !important;
                    font-weight: 600 !important;
                    line-height: 1.35 !important;
                }

                /* Result Excerpt / Snippet */
                a[role="option"] p,
                a[role="option"] .text-neutral-400 {
                    color: rgba(255, 255, 255, 0.55) !important;
                    font-family: 'Inter', sans-serif !important;
                    font-size: 0.85rem !important;
                    margin-top: 4px !important;
                    line-height: 1.45 !important;
                }

                /* Matching bold highlight */
                a[role="option"] span.font-bold {
                    color: #00e5ff !important;
                    font-weight: 700 !important;
                    text-decoration: underline !important;
                    text-underline-offset: 2px !important;
                }

                /* Empty state / no results */
                div.py-12.text-center,
                div[role="dialog"] .text-neutral-400 {
                    color: rgba(255, 255, 255, 0.5) !important;
                }

                /* Custom scrollbar */
                div.overflow-y-auto::-webkit-scrollbar {
                    width: 6px;
                }
                div.overflow-y-auto::-webkit-scrollbar-track {
                    background: rgba(0, 0, 0, 0.2);
                }
                div.overflow-y-auto::-webkit-scrollbar-thumb {
                    background: rgba(255, 255, 255, 0.15);
                    border-radius: 999px;
                }
                div.overflow-y-auto::-webkit-scrollbar-thumb:hover {
                    background: rgba(255, 255, 255, 0.3);
                }
            `;
        } else {
            return `
                /* ==========================================================
                   CLEAN MONOCHROME LIGHT MODE SODO SEARCH
                   ========================================================== */
                html, body {
                    background: transparent !important;
                    color-scheme: light !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                }

                /* Backdrop Blur */
                div.bg-gradient-to-br,
                div[class*="backdrop-blur"] {
                    background: rgba(15, 23, 42, 0.35) !important;
                    backdrop-filter: blur(12px) !important;
                    -webkit-backdrop-filter: blur(12px) !important;
                }

                /* Modal Dialog Container */
                div[role="dialog"],
                .animate-popup {
                    background: #ffffff !important;
                    border: 1px solid rgba(15, 23, 42, 0.09) !important;
                    border-radius: 16px !important;
                    box-shadow: 0 20px 48px rgba(0, 0, 0, 0.12), 0 2px 6px rgba(0, 0, 0, 0.04) !important;
                    overflow: hidden !important;
                }

                /* Search Header Bar */
                div[role="dialog"] > div:first-child,
                div[role="dialog"] .bg-white.rounded-t-lg,
                div[role="dialog"] .bg-white.rounded-lg {
                    background: #f8fafc !important;
                    border-bottom: 1px solid rgba(15, 23, 42, 0.06) !important;
                    border-radius: 16px 16px 0 0 !important;
                    box-shadow: none !important;
                }

                /* Search Input Field */
                #sodo-search-input {
                    background: transparent !important;
                    color: #0f172a !important;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                    font-size: 1.15rem !important;
                    letter-spacing: -0.01em !important;
                }
                #sodo-search-input::placeholder {
                    color: #94a3b8 !important;
                }

                /* Search Icons */
                div[role="dialog"] svg {
                    color: #334155 !important;
                    stroke: currentColor !important;
                }
                div[role="dialog"] svg path {
                    fill: currentColor !important;
                }

                /* Clear button */
                button[aria-label="Clear search"] svg:hover {
                    color: #0f172a !important;
                }

                /* Cancel button */
                div[role="dialog"] button.text-neutral-500 {
                    color: #64748b !important;
                }
                div[role="dialog"] button.text-neutral-500:hover {
                    color: #0f172a !important;
                }

                /* Group Headers (Posts, Authors, Tags) */
                div[id*="-label"],
                div.uppercase.text-xs {
                    color: #64748b !important;
                    font-family: 'Inter', sans-serif !important;
                    font-weight: 700 !important;
                    font-size: 11px !important;
                    letter-spacing: 0.08em !important;
                }
                div.border-neutral-200 {
                    border-color: rgba(15, 23, 42, 0.06) !important;
                }

                /* Result Item Cards */
                a[role="option"] {
                    background: transparent !important;
                    transition: background-color 0.15s ease, transform 0.15s ease !important;
                    border-radius: 10px !important;
                    margin: 2px 0 !important;
                    padding: 10px 16px !important;
                }
                a[role="option"]:hover,
                a[role="option"][aria-selected="true"] {
                    background: rgba(15, 23, 42, 0.04) !important;
                }

                /* Result Title */
                a[role="option"] div[class*="text-[1.65rem]"],
                a[role="option"] .text-neutral-800 {
                    color: #0f172a !important;
                    font-family: 'Inter', sans-serif !important;
                    font-size: 1.05rem !important;
                    font-weight: 600 !important;
                    line-height: 1.35 !important;
                }

                /* Result Excerpt / Snippet */
                a[role="option"] p,
                a[role="option"] .text-neutral-400 {
                    color: #64748b !important;
                    font-family: 'Inter', sans-serif !important;
                    font-size: 0.85rem !important;
                    margin-top: 4px !important;
                    line-height: 1.45 !important;
                }

                /* Matching bold highlight */
                a[role="option"] span.font-bold {
                    color: #0284c7 !important;
                    font-weight: 700 !important;
                    text-decoration: underline !important;
                    text-underline-offset: 2px !important;
                }

                /* Empty state */
                div.py-12.text-center,
                div[role="dialog"] .text-neutral-400 {
                    color: #64748b !important;
                }

                /* Custom scrollbar */
                div.overflow-y-auto::-webkit-scrollbar {
                    width: 6px;
                }
                div.overflow-y-auto::-webkit-scrollbar-track {
                    background: rgba(0, 0, 0, 0.04);
                }
                div.overflow-y-auto::-webkit-scrollbar-thumb {
                    background: rgba(0, 0, 0, 0.15);
                    border-radius: 999px;
                }
                div.overflow-y-auto::-webkit-scrollbar-thumb:hover {
                    background: rgba(0, 0, 0, 0.25);
                }
            `;
        }
    }

    function getAllSearchFrames() {
        const frames = [];
        const seen = new Set();

        function add(f) {
            if (f && !seen.has(f)) {
                seen.add(f);
                frames.push(f);
            }
        }

        // 1. Root container iframes
        document.querySelectorAll('#sodo-search-root iframe, [data-sodo-search] iframe').forEach(add);

        // 2. Title matching
        document.querySelectorAll('iframe[title*="Search" i]').forEach(add);

        // 3. Inspect contentDocument for sodo elements
        document.querySelectorAll('iframe').forEach(function(f) {
            try {
                if (f.contentDocument && f.contentDocument.querySelector('#sodo-search-input, [role="dialog"][aria-label*="Search" i]')) {
                    add(f);
                }
            } catch(e) {}
        });

        return frames;
    }

    function styleSearchFrame(frame) {
        if (!frame) return;
        try {
            const doc = frame.contentDocument;
            if (!doc || !doc.head || !doc.body) return;

            const isDark = getIsDark();
            const root = doc.documentElement;

            // Sync theme classes onto the iframe root
            if (isDark) {
                root.classList.add('dark', 'dark-mode');
                root.classList.remove('light-mode');
                root.setAttribute('data-theme', 'dark');
                root.style.colorScheme = 'dark';
            } else {
                root.classList.remove('dark', 'dark-mode');
                root.classList.add('light-mode');
                root.setAttribute('data-theme', 'light');
                root.style.colorScheme = 'light';
            }

            // Inject or update stylesheet
            let style = doc.getElementById(STYLE_ID);
            if (!style) {
                style = doc.createElement('style');
                style.id = STYLE_ID;
                doc.head.appendChild(style);
            }

            const css = generateSodoCss(isDark);
            if (style.textContent !== css) {
                style.textContent = css;
            }

            // Attach MutationObserver inside iframe to keep styles intact during React re-renders
            if (!frame._gmSearchObserverAttached) {
                frame._gmSearchObserverAttached = true;
                const innerObserver = new MutationObserver(function() {
                    if (frame._gmInnerApplying) return;
                    frame._gmInnerApplying = true;
                    try {
                        styleSearchFrame(frame);
                    } finally {
                        frame._gmInnerApplying = false;
                    }
                });
                innerObserver.observe(doc.body, { childList: true, subtree: true, attributes: false });
            }
        } catch(e) {}
    }

    function applyAllSearchFrames() {
        const frames = getAllSearchFrames();
        frames.forEach(styleSearchFrame);
    }

    // 1. Observe host DOM for sodo-search insertion
    const domObserver = new MutationObserver(function(mutations) {
        let shouldCheck = false;
        for (let i = 0; i < mutations.length; i++) {
            const added = mutations[i].addedNodes;
            for (let j = 0; j < added.length; j++) {
                const node = added[j];
                if (node.nodeType === 1) {
                    if (node.id === 'sodo-search-root' ||
                        node.tagName === 'IFRAME' ||
                        (node.querySelector && node.querySelector('#sodo-search-root, iframe[title*="Search" i]'))) {
                        shouldCheck = true;
                        break;
                    }
                }
            }
            if (shouldCheck) break;
        }
        if (shouldCheck) {
            applyAllSearchFrames();
        }
    });

    if (document.documentElement) {
        domObserver.observe(document.documentElement, { childList: true, subtree: true });
    }

    // 2. Observe theme changes in host document
    const themeObserver = new MutationObserver(function() {
        applyAllSearchFrames();
    });
    themeObserver.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['class', 'data-theme']
    });

    // 3. Click handler on search button
    document.addEventListener('click', function(e) {
        const target = e.target;
        if (target && target.closest && target.closest('.gh-search, [data-ghost-search], .gm-search-btn, .gm-search-bar-btn')) {
            let count = 0;
            const timer = setInterval(function() {
                applyAllSearchFrames();
                count++;
                if (count >= 15) clearInterval(timer);
            }, 50);
        }
    });

    // 4. Keyboard shortcut handler (Ctrl+K / ⌘K)
    window.addEventListener('keydown', function(e) {
        if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
            let count = 0;
            const timer = setInterval(function() {
                applyAllSearchFrames();
                count++;
                if (count >= 15) clearInterval(timer);
            }, 50);
        }
    });

    // Polling backup
    setInterval(applyAllSearchFrames, 500);
    applyAllSearchFrames();
})();

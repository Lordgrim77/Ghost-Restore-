/* Theme Runtime Engine (Externalized from default.hbs for Strict CSP) */

(function () {
    function initKoenigPostDefense() {
        // 1. Safe Koenig Gallery Handling: ensure ratio calculation never crashes
        document.querySelectorAll('.kg-gallery-image img').forEach(function (img) {
            const container = img.closest('.kg-gallery-image');
            if (!container) return;
            const w = parseFloat(img.getAttribute('width')) || img.naturalWidth || 4;
            const h = parseFloat(img.getAttribute('height')) || img.naturalHeight || 3;
            if (w && h && h > 0) {
                const ratio = w / h;
                container.style.flex = ratio + ' 1 0%';
            } else {
                container.style.flex = '1 1 0%';
            }
            if (!img.complete) {
                img.addEventListener('load', function () {
                    const nw = img.naturalWidth || 4;
                    const nh = img.naturalHeight || 3;
                    if (nw && nh && nh > 0) {
                        container.style.flex = (nw / nh) + ' 1 0%';
                    }
                }, { once: true });
            }
        });

        // 2. Safe Koenig Toggle Cards
        document.querySelectorAll('.kg-toggle-heading').forEach(function (heading) {
            if (heading.dataset.toggleInit) return;
            heading.dataset.toggleInit = 'true';
            heading.addEventListener('click', function () {
                const card = heading.closest('.kg-toggle-card');
                if (!card) return;
                const state = card.getAttribute('data-kg-toggle-state');
                card.setAttribute('data-kg-toggle-state', state === 'open' ? 'close' : 'open');
            });
        });

        // 3. Iframe & Embed Anti-Collapse Protection
        document.querySelectorAll('.gh-content iframe').forEach(function (iframe) {
            const reframeWrap = iframe.closest('.js-reframe');
            if (reframeWrap) {
                const pt = parseFloat(reframeWrap.style.paddingTop);
                if (isNaN(pt) || pt <= 5) {
                    reframeWrap.style.paddingTop = '56.25%';
                }
            }
        });

        // 4. Safe Wide Table Scroll Container (Prevents Mobile Grid Blowout & Scroll Chaining)
        document.querySelectorAll('.gh-content table').forEach(function (table) {
            if (table.closest('.gm-table-scroll')) return;
            const wrapper = document.createElement('div');
            wrapper.className = 'gm-table-scroll';
            if (table.parentNode) {
                table.parentNode.insertBefore(wrapper, table);
                wrapper.appendChild(table);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initKoenigPostDefense);
    } else {
        initKoenigPostDefense();
    }
    window.addEventListener('load', initKoenigPostDefense);
})();

(function () {
    const html = document.documentElement;
    const saved = localStorage.getItem('user-theme');
    const defaultTheme = (html.getAttribute('data-default-theme') === 'light') ? 'light' : 'dark';
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    let theme = saved || (prefersDark ? 'dark' : defaultTheme);

    function apply(t) {
        if (t === 'dark') {
            html.classList.add('dark-mode');
            html.classList.remove('light-mode');
            html.setAttribute('data-theme', 'dark');
            document.querySelectorAll('#gmThemeIcon, .gm-theme-icon').forEach(el => { el.textContent = '🌙'; });
            document.querySelectorAll('#gmThemeText, .gm-theme-text, .gm-menu-theme-badge').forEach(el => { el.textContent = 'Dark'; });
        } else {
            html.classList.remove('dark-mode');
            html.classList.add('light-mode');
            html.setAttribute('data-theme', 'light');
            document.querySelectorAll('#gmThemeIcon, .gm-theme-icon').forEach(el => { el.textContent = '☀️'; });
            document.querySelectorAll('#gmThemeText, .gm-theme-text, .gm-menu-theme-badge').forEach(el => { el.textContent = 'Light'; });
        }
        localStorage.setItem('user-theme', t);
    }

    apply(theme);

    document.querySelectorAll('.gm-theme-toggle').forEach(function (toggleBtn) {
        toggleBtn.addEventListener('click', function (e) {
            if (e) e.preventDefault();
            theme = (html.getAttribute('data-theme') === 'dark') ? 'light' : 'dark';
            apply(theme);
        });
    });

    // Mobile Hamburger Dropdown Menu
    const menuBtn = document.getElementById('gmMobileMenuBtn');
    const head = document.getElementById('gh-head');
    if (menuBtn && head) {
        function setMenuOpen(open) {
            head.classList.toggle('is-menu-open', open);
            menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        }

        menuBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            setMenuOpen(!head.classList.contains('is-menu-open'));
        });

        document.addEventListener('click', function (e) {
            if (head.classList.contains('is-menu-open') && !head.contains(e.target)) {
                setMenuOpen(false);
            }
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && head.classList.contains('is-menu-open')) {
                const returnFocus = head.contains(document.activeElement);
                setMenuOpen(false);
                if (returnFocus) menuBtn.focus();
            }
        });

        const mobileMenuNav = head.querySelector('.gh-head-menu');
        if (mobileMenuNav) {
            mobileMenuNav.addEventListener('click', function (e) {
                if (e.target && e.target.closest('a, button') && head.classList.contains('is-menu-open')) {
                    setMenuOpen(false);
                }
            });
        }
    }

    // Card & Newsletter Cursor Spotlight (Pointer-Fine Hover Devices Only)
    function initSpotlights() {
        if (!window.matchMedia || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
        const cards = document.querySelectorAll('.gm-post-card, .gm-newsletter-card');
        cards.forEach(function (card) {
            if (card.dataset.spotlightInit) return;
            card.dataset.spotlightInit = 'true';
            let raf = null;
            let mx = -500, my = -500;

            card.addEventListener('mousemove', function (e) {
                const rect = card.getBoundingClientRect();
                mx = e.clientX - rect.left;
                my = e.clientY - rect.top;
                if (!raf) {
                    raf = requestAnimationFrame(function () {
                        card.style.setProperty('--mouse-x', mx + 'px');
                        card.style.setProperty('--mouse-y', my + 'px');
                        raf = null;
                    });
                }
            }, { passive: true });

            card.addEventListener('mouseleave', function () {
                if (raf) { cancelAnimationFrame(raf); raf = null; }
                card.style.removeProperty('--mouse-x');
                card.style.removeProperty('--mouse-y');
            });
        });
    }

    initSpotlights();
    window.addEventListener('load', initSpotlights);

    // Dynamic Active Navigation Highlight (Handles Custom Routes like /posts/)
    function highlightActiveNav() {
        const path = (window.location.pathname || '').replace(/\/+$/, '') || '/';
        document.querySelectorAll('.gh-head-menu .nav li, .gh-foot-menu .nav li').forEach(function (li) {
            const a = li.querySelector('a');
            if (!a) return;
            const aPath = (a.pathname || '').replace(/\/+$/, '') || '/';
            if (aPath === path) {
                li.classList.add('nav-current');
            } else {
                li.classList.remove('nav-current');
            }
        });
    }

    window.gmHighlightActiveNav = highlightActiveNav;
    highlightActiveNav();
    window.addEventListener('load', highlightActiveNav);

    // Dynamic search keyboard shortcut detection (⌘K on macOS, Ctrl K on Windows/Linux)
    try {
        const isMac = /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform || navigator.userAgent);
        const kbd = document.getElementById('gmSearchKbd');
        if (kbd) kbd.textContent = isMac ? '⌘K' : 'Ctrl K';
    } catch (e) {}

    // Keep all menu links (Home, About, etc.) visible next to the logo; disable 3-dots collapse
    function unwrapNavigation() {
        const nav = document.querySelector('.gh-head-menu .nav');
        const dropdown = document.querySelector('.gh-dropdown');
        const toggle = document.querySelector('.nav-more-toggle');
        if (nav && dropdown) {
            while (dropdown.firstChild) {
                nav.insertBefore(dropdown.firstChild, toggle);
            }
            if (toggle) toggle.remove();
        }
        highlightActiveNav();
    }

    window.addEventListener('load', unwrapNavigation);
    let lastUnwrapWidth = window.innerWidth;
    window.addEventListener('resize', function () {
        const w = window.innerWidth;
        if (w === lastUnwrapWidth) return;
        lastUnwrapWidth = w;
        setTimeout(unwrapNavigation, 20);
    });
    setTimeout(unwrapNavigation, 100);
})();

(function () {
    const SITE_URL = (window.location.origin || document.documentElement.getAttribute('data-site-url') || '').replace(/\/$/, '');

    function syncMemberFormUI(form) {
        if (!form) return;
        const isLoading = form.classList.contains('loading');
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = isLoading;
            if (isLoading) {
                submitBtn.setAttribute('aria-busy', 'true');
            } else {
                submitBtn.removeAttribute('aria-busy');
            }
        }
        const isSuccess = form.classList.contains('success');
        if (isSuccess && form.dataset.gmWasSuccess !== '1') {
            form.dataset.gmWasSuccess = '1';
            const emailInput = form.querySelector('input[data-members-email]');
            if (emailInput) {
                emailInput.value = '';
            }
        } else if (!isSuccess) {
            form.dataset.gmWasSuccess = '0';
        }
    }

    function attachFormObserver(form) {
        if (!form || form.dataset.gmFormObserved === '1') return;
        form.dataset.gmFormObserved = '1';
        const observer = new MutationObserver(function () {
            syncMemberFormUI(form);
        });
        observer.observe(form, { attributes: true, attributeFilter: ['class'] });
        const emailInput = form.querySelector('input[data-members-email]');
        if (emailInput) {
            emailInput.addEventListener('input', function () {
                form.classList.remove('error', 'invalid', 'success');
            });
        }
        syncMemberFormUI(form);
    }

    function initMemberFormObservers() {
        document.querySelectorAll('form[data-members-form]').forEach(attachFormObserver);
    }

    // Block rapid repeat submits while an async request is already in flight
    document.addEventListener('submit', function (e) {
        const form = e.target && e.target.closest ? e.target.closest('form[data-members-form]') : null;
        if (!form) return;
        attachFormObserver(form);
        if (form.classList.contains('loading')) {
            e.preventDefault();
            e.stopImmediatePropagation();
        }
    }, true);

    // Fallback handler if Ghost Portal is delayed, blocked, or unbound
    document.addEventListener('submit', async function (e) {
        const form = e.target && e.target.closest ? e.target.closest('form[data-members-form]') : null;
        if (!form || e.defaultPrevented) return;

        e.preventDefault();
        attachFormObserver(form);

        const emailInput = form.querySelector('input[data-members-email]');
        const errorEl = form.querySelector('[data-members-error]');
        const email = (emailInput ? emailInput.value : '').trim();

        form.classList.remove('success', 'invalid', 'error');
        if (errorEl) errorEl.textContent = '';

        if (!email || (emailInput && !emailInput.checkValidity())) {
            form.classList.add('error');
            if (errorEl) errorEl.textContent = 'Please enter a valid email address.';
            return;
        }

        form.classList.add('loading');
        syncMemberFormUI(form);

        try {
            const emailType = form.getAttribute('data-members-form') || 'subscribe';
            const labelInputs = form.querySelectorAll('input[data-members-label]');
            const labels = Array.from(labelInputs).map((el) => el.value).filter(Boolean);
            const nameInput = form.querySelector('input[data-members-name]');
            const autoRedirect = form.getAttribute('data-members-autoredirect');
            const reqBody = {
                email: email,
                emailType: emailType,
                labels: labels,
                name: nameInput ? (nameInput.value || '').trim() || undefined : undefined,
                autoRedirect: autoRedirect === null ? true : autoRedirect !== 'false'
            };

            const tokenRes = await fetch(SITE_URL + '/members/api/integrity-token/', { method: 'GET' });
            if (!tokenRes.ok) {
                throw new Error('Unable to verify request. Please try again.');
            }
            reqBody.integrityToken = (await tokenRes.text()).trim();

            const res = await fetch(SITE_URL + '/members/api/send-magic-link/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(reqBody)
            });

            if (res.ok) {
                form.classList.add('success');
            } else {
                let errMsg = 'Unable to send confirmation email. Please try again.';
                try {
                    const data = await res.json();
                    if (data && Array.isArray(data.errors) && data.errors[0] && data.errors[0].message) {
                        errMsg = data.errors[0].message;
                    }
                } catch (_) {}
                if (errorEl) errorEl.textContent = errMsg;
                form.classList.add('error');
            }
        } catch (err) {
            if (errorEl) errorEl.textContent = (err && err.message) ? err.message : 'Something went wrong. Please try again.';
            form.classList.add('error');
        } finally {
            form.classList.remove('loading');
            syncMemberFormUI(form);
        }
    }, false);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initMemberFormObservers);
    } else {
        initMemberFormObservers();
    }
})();

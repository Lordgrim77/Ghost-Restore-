/* Synchronous Head Bootstrap (Externalized from default.hbs for Strict CSP) */
(function () {
    // 0. Trusted Types Default Policy Bootstrap (Zero-Crash Compatibility)
    if (window.trustedTypes && window.trustedTypes.createPolicy) {
        try {
            window.trustedTypes.createPolicy('default', {
                createHTML: function (s) { return s; },
                createScript: function (s) { return s; },
                createScriptURL: function (s) { return s; }
            });
        } catch (e) {}
    }

    var root = document.documentElement;

    // 1. Synchronous Anti-FOUC Theme Detection (Runs BEFORE first paint)
    try {
        var saved = localStorage.getItem('user-theme');
        var defaultTheme = (root.getAttribute('data-default-theme') === 'light') ? 'light' : 'dark';
        var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        var theme = saved || (prefersDark ? 'dark' : defaultTheme);

        if (theme === 'light') {
            root.classList.remove('dark-mode');
            root.classList.add('light-mode');
            root.setAttribute('data-theme', 'light');
        } else {
            root.classList.remove('light-mode');
            root.classList.add('dark-mode');
            root.setAttribute('data-theme', 'dark');
        }
    } catch (e) {}

    // 2. Anti-Splash Flash (Runs on posts; once per session on home/pages; resets on reload)
    try {
        var isPost = root.getAttribute('data-is-post') === 'true';
        var isReload = false;
        var navEntries = window.performance && performance.getEntriesByType && performance.getEntriesByType('navigation');
        if (navEntries && navEntries.length > 0 && navEntries[0].type === 'reload') {
            isReload = true;
        } else if (window.performance && window.performance.navigation && window.performance.navigation.type === 1) {
            isReload = true;
        }

        if (isPost) {
            window.gmIsPostPage = true;
        } else if (isReload) {
            sessionStorage.removeItem('gm_cyber_splash_shown');
        } else if (sessionStorage.getItem('gm_cyber_splash_shown') === '1') {
            root.classList.add('gm-splash-skip');
        }
    } catch (e) {}

    // 3. Synchronously expose authenticated member metadata if present
    var metaEl = document.getElementById('gm-member-meta');
    if (metaEl) {
        window.gmCurrentMember = {
            name: metaEl.getAttribute('data-name') || '',
            email: metaEl.getAttribute('data-email') || ''
        };
    }
})();

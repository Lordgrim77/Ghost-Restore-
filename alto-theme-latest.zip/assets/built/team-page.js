/**
 * Ghost Alto Theme - Dedicated Team Page Engine
 * Manages manual member order, custom titles/roles, department filters, and Ghost author linkage.
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', initTeamPage);

    function initTeamPage() {
        const grid = document.getElementById('gm-team-grid');
        if (!grid) return;

        // Collect existing SSR author data from the DOM
        const ssrAuthors = {};
        const ssrCards = grid.querySelectorAll('.gm-team-card-ssr');
        ssrCards.forEach(card => {
            const slug = (card.getAttribute('data-slug') || '').toLowerCase().trim();
            const name = (card.getAttribute('data-name') || '').trim();
            const avatarImg = card.querySelector('.gm-team-avatar');
            const profileLink = card.querySelector('.gm-team-name a');
            const countBadge = card.querySelector('.gm-team-count-badge');

            const postCountMatch = countBadge ? countBadge.textContent.match(/\d+/) : null;
            const postCount = postCountMatch ? parseInt(postCountMatch[0], 10) : 0;

            const data = {
                slug: slug,
                name: name,
                url: profileLink ? profileLink.getAttribute('href') : (slug ? `/author/${slug}/` : ''),
                avatar: avatarImg ? avatarImg.getAttribute('src') : '',
                postCount: postCount
            };

            if (slug) ssrAuthors[slug] = data;
            if (name) ssrAuthors[name.toLowerCase()] = data;
        });

        // Load config: first try /assets/data/team.json, then fallback to embedded #gm-team-default-data
        loadTeamConfig(function(teamMembers) {
            if (!teamMembers || !teamMembers.length) {
                // If no config found, keep SSR cards
                grid.setAttribute('data-team-loaded', 'true');
                return;
            }

            renderTeamGrid(grid, teamMembers, ssrAuthors);
            setupFilters();
        });
    }

    function loadTeamConfig(callback) {
        // Try fetching external team.json first
        const jsonUrl = '/assets/data/team.json?v=' + Date.now();
        fetch(jsonUrl)
            .then(res => {
                if (!res.ok) throw new Error('Status ' + res.status);
                return res.json();
            })
            .then(data => {
                if (Array.isArray(data) && data.length > 0) {
                    callback(data);
                } else {
                    fallbackToInline();
                }
            })
            .catch(() => {
                fallbackToInline();
            });

        function fallbackToInline() {
            try {
                const inlineTag = document.getElementById('gm-team-default-data');
                if (inlineTag && inlineTag.textContent) {
                    const parsed = JSON.parse(inlineTag.textContent);
                    if (Array.isArray(parsed) && parsed.length > 0) {
                        callback(parsed);
                        return;
                    }
                }
            } catch (err) {
                console.warn('[GM Team] Failed to parse inline team data:', err);
            }
            callback([]);
        }
    }

    function renderTeamGrid(container, members, ssrAuthors) {
        // Sort strictly by manual order (1, 2, 3...)
        members.sort((a, b) => {
            const orderA = typeof a.order === 'number' ? a.order : 999;
            const orderB = typeof b.order === 'number' ? b.order : 999;
            return orderA - orderB;
        });

        const cardsHtml = members.map(member => {
            const slug = (member.slug || '').toLowerCase().trim();
            const name = member.name || 'Team Operative';
            const ssrMatch = ssrAuthors[slug] || ssrAuthors[name.toLowerCase()] || null;

            // Resolve author profile link
            const authorUrl = member.url || (slug ? `/author/${slug}/` : (ssrMatch ? ssrMatch.url : ''));

            // Resolve avatar
            let avatarUrl = member.avatar || (ssrMatch ? ssrMatch.avatar : '');
            
            // Post count
            const postCount = typeof member.postCount === 'number' 
                ? member.postCount 
                : (ssrMatch ? ssrMatch.postCount : 0);

            // Manual title, badge, department, bio
            const title = member.title || 'Investigator';
            const badge = member.badge || member.department || 'Core Team';
            const department = member.department || 'Operations';
            const bio = member.bio || 'Intelligence and cyber operations specialist.';
            const location = member.location || '';
            const statusClass = member.status === 'standby' ? 'standby' : 'active';

            // Social links
            let linksHtml = '';
            if (member.telegram) {
                linksHtml += `
                    <a href="${escapeHtml(member.telegram)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Telegram" title="Telegram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                    </a>`;
            }
            if (member.twitter) {
                linksHtml += `
                    <a href="${escapeHtml(member.twitter)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Twitter / X" title="Twitter / X">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
                    </a>`;
            }
            if (member.github) {
                linksHtml += `
                    <a href="${escapeHtml(member.github)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="GitHub" title="GitHub">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg>
                    </a>`;
            }
            if (member.website) {
                linksHtml += `
                    <a href="${escapeHtml(member.website)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Website" title="Website">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    </a>`;
            }
            if (member.email) {
                linksHtml += `
                    <a href="mailto:${escapeHtml(member.email)}" class="gm-team-link" aria-label="Email" title="Email">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    </a>`;
            }

            // Action button
            let actionBtnHtml = '';
            if (authorUrl) {
                actionBtnHtml = `
                    <a href="${escapeHtml(authorUrl)}" class="gm-team-profile-btn">
                        <span>Profile & Posts</span>
                        ${postCount > 0 ? `<span class="gm-team-count-badge">(${postCount})</span>` : ''}
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>`;
            } else if (member.website || member.telegram) {
                actionBtnHtml = `
                    <a href="${escapeHtml(member.website || member.telegram)}" target="_blank" rel="noopener noreferrer" class="gm-team-profile-btn">
                        <span>Contact</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                    </a>`;
            }

            // Avatar markup
            let avatarMarkup = '';
            if (avatarUrl) {
                avatarMarkup = `<img class="gm-team-avatar u-object-fit" src="${escapeHtml(avatarUrl)}" alt="${escapeHtml(name)}" loading="lazy">`;
            } else {
                // Sleek initials avatar fallback
                const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'OP';
                avatarMarkup = `<div class="gm-team-avatar-fallback gm-team-avatar-initials">${initials}</div>`;
            }

            return `
                <div class="gm-team-card" data-department="${escapeHtml(department)}" data-order="${member.order || 99}">
                    <div class="gm-team-card-inner">
                        <div class="gm-team-avatar-wrap">
                            ${avatarMarkup}
                            <span class="gm-team-status-ring ${statusClass}" title="${statusClass === 'active' ? 'Active Operative' : 'Standby'}"></span>
                        </div>

                        <div class="gm-team-info">
                            <div class="gm-team-name-row">
                                <div class="gm-team-name-group">
                                    <h3 class="gm-team-name">
                                        ${authorUrl ? `<a href="${escapeHtml(authorUrl)}">${escapeHtml(name)}</a>` : `<span>${escapeHtml(name)}</span>`}
                                    </h3>
                                    <span class="gm-team-role-title">${escapeHtml(title)}</span>
                                </div>
                                <span class="gm-team-badge">${escapeHtml(badge)}</span>
                            </div>

                            ${location ? `<div class="gm-team-location"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span>${escapeHtml(location)}</span></div>` : ''}

                            <p class="gm-team-bio">${escapeHtml(bio)}</p>

                            <div class="gm-team-meta-row">
                                <div class="gm-team-links">
                                    ${linksHtml}
                                </div>
                                ${actionBtnHtml}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = cardsHtml;
        container.setAttribute('data-team-loaded', 'true');
    }

    function setupFilters() {
        const filterBar = document.getElementById('gm-team-filters');
        const grid = document.getElementById('gm-team-grid');
        if (!filterBar || !grid) return;

        const buttons = filterBar.querySelectorAll('.gm-team-filter-btn');
        buttons.forEach(btn => {
            btn.addEventListener('click', function() {
                buttons.forEach(b => b.classList.remove('is-active'));
                this.classList.add('is-active');

                const filter = this.getAttribute('data-filter') || 'all';
                const cards = grid.querySelectorAll('.gm-team-card');

                cards.forEach(card => {
                    const dept = card.getAttribute('data-department') || '';
                    if (filter === 'all' || dept.toLowerCase().includes(filter.toLowerCase())) {
                        card.style.display = '';
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
})();


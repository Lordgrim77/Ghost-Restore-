/**
 * Ghost Alto Theme - Dedicated Team Page Engine
 * Automatically imports bio, avatar, location, website, and social links directly from Ghost staff/authors.
 * Allows manual sequence ordering, custom titles, badges, and external operatives via team.json.
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', initTeamPage);

    function initTeamPage() {
        const grid = document.getElementById('gm-team-grid');
        if (!grid) return;

        // 1. Automatically scrape and import all Ghost Staff data from the SSR markup
        const ghostStaff = {};
        const ssrCards = grid.querySelectorAll('.gm-team-card-ssr');
        ssrCards.forEach(card => {
            const rawSlug = card.getAttribute('data-slug') || '';
            const slug = rawSlug.toLowerCase().trim();
            const nameEl = card.querySelector('.gm-team-name a') || card.querySelector('.gm-team-name');
            const name = (nameEl ? nameEl.textContent : (card.getAttribute('data-name') || '')).trim();
            const avatarImg = card.querySelector('.gm-team-avatar');
            const locationEl = card.querySelector('.gm-team-staff-location');
            const bioEl = card.querySelector('.gm-team-staff-bio');
            const websiteEl = card.querySelector('[data-link="website"]');
            const twitterEl = card.querySelector('[data-link="twitter"]');
            const facebookEl = card.querySelector('[data-link="facebook"]');
            const postCount = parseInt(card.getAttribute('data-posts') || '0', 10);
            const authorUrl = card.getAttribute('data-url') || (slug ? `/author/${slug}/` : '');

            const staffObj = {
                slug: slug,
                rawSlug: rawSlug,
                name: name,
                avatar: avatarImg ? avatarImg.getAttribute('src') : '',
                location: locationEl ? locationEl.textContent.trim() : '',
                bio: bioEl ? bioEl.textContent.trim() : '',
                website: websiteEl ? websiteEl.getAttribute('data-href') : '',
                twitter: twitterEl ? twitterEl.getAttribute('data-href') : '',
                facebook: facebookEl ? facebookEl.getAttribute('data-href') : '',
                url: authorUrl,
                postCount: postCount,
                matched: false
            };

            if (slug) ghostStaff[slug] = staffObj;
            if (name) ghostStaff[name.toLowerCase()] = staffObj;
        });

        // 2. Load manual team configuration (order, custom titles, extra channels)
        loadTeamConfig(function(configMembers) {
            renderTeamGrid(grid, configMembers, ghostStaff);
            setupFilters();
        });
    }

    function loadTeamConfig(callback) {
        const jsonUrl = '/assets/data/team.json?v=' + Date.now();
        fetch(jsonUrl)
            .then(res => {
                if (!res.ok) throw new Error('Status ' + res.status);
                return res.json();
            })
            .then(data => {
                if (Array.isArray(data) && data.length > 0) {
                    callback(data);
                } else {
                    fallbackToInline();
                }
            })
            .catch(() => {
                fallbackToInline();
            });

        function fallbackToInline() {
            try {
                const inlineTag = document.getElementById('gm-team-default-data');
                if (inlineTag && inlineTag.textContent) {
                    const parsed = JSON.parse(inlineTag.textContent);
                    if (Array.isArray(parsed) && parsed.length > 0) {
                        callback(parsed);
                        return;
                    }
                }
            } catch (err) {
                console.warn('[GM Team] Failed to parse inline team data:', err);
            }
            callback([]);
        }
    }

    function renderTeamGrid(container, configMembers, ghostStaff) {
        const mergedList = [];
        const processedSlugs = new Set();

        // Step A: Process members listed in manual configuration
        if (Array.isArray(configMembers)) {
            configMembers.forEach((member, idx) => {
                const slug = (member.slug || '').toLowerCase().trim();
                const nameKey = (member.name || '').toLowerCase().trim();
                const staff = ghostStaff[slug] || ghostStaff[nameKey] || null;

                if (staff) {
                    staff.matched = true;
                    if (staff.slug) processedSlugs.add(staff.slug);
                }
                if (slug) processedSlugs.add(slug);

                // Auto-import details from Ghost staff if not explicitly overridden in JSON
                const resolvedName = member.name || (staff ? staff.name : 'Team Operative');
                const resolvedBio = member.bio || (staff ? staff.bio : 'Investigator & Research Contributor.');
                const resolvedAvatar = member.avatar || (staff ? staff.avatar : '');
                const resolvedLocation = member.location || (staff ? staff.location : '');
                const resolvedWebsite = member.website || (staff ? staff.website : '');
                const resolvedTwitter = member.twitter || (staff ? staff.twitter : '');
                const resolvedFacebook = member.facebook || (staff ? staff.facebook : '');
                const resolvedUrl = member.url || (staff ? staff.url : (slug ? `/author/${slug}/` : ''));
                const postCount = typeof member.postCount === 'number' 
                    ? member.postCount 
                    : (staff ? staff.postCount : 0);

                mergedList.push({
                    order: typeof member.order === 'number' ? member.order : (idx + 1),
                    name: resolvedName,
                    slug: slug || (staff ? staff.slug : ''),
                    title: member.title || (staff && staff.location ? staff.location : 'Staff Investigator'),
                    badge: member.badge || member.department || 'Core Team',
                    department: member.department || 'Operations',
                    bio: resolvedBio,
                    avatar: resolvedAvatar,
                    location: resolvedLocation,
                    status: member.status === 'standby' ? 'standby' : 'active',
                    website: resolvedWebsite,
                    twitter: resolvedTwitter,
                    facebook: resolvedFacebook,
                    telegram: member.telegram || '',
                    github: member.github || '',
                    email: member.email || '',
                    url: resolvedUrl,
                    postCount: postCount
                });
            });
        }

        // Step B: Automatically import any unlisted Ghost Staff members
        const seenStaff = new Set();
        Object.keys(ghostStaff).forEach(k => {
            const staff = ghostStaff[k];
            if (!staff || staff.matched || seenStaff.has(staff.slug)) return;
            seenStaff.add(staff.slug);

            mergedList.push({
                order: 100 + mergedList.length,
                name: staff.name,
                slug: staff.slug,
                title: staff.location || 'Staff Contributor',
                badge: 'Contributor',
                department: 'Operations',
                bio: staff.bio || 'Investigator & Research Contributor.',
                avatar: staff.avatar,
                location: staff.location,
                status: 'active',
                website: staff.website,
                twitter: staff.twitter,
                facebook: staff.facebook,
                telegram: '',
                github: '',
                email: '',
                url: staff.url,
                postCount: staff.postCount
            });
        });

        // Step C: Sort strictly by manual order (1, 2, 3...)
        mergedList.sort((a, b) => a.order - b.order);

        // Step D: Render cards
        const cardsHtml = mergedList.map(member => {
            const authorUrl = member.url;
            const statusClass = member.status === 'standby' ? 'standby' : 'active';

            // Social links
            let linksHtml = '';
            if (member.telegram) {
                linksHtml += `
                    <a href="${escapeHtml(member.telegram)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Telegram" title="Telegram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                    </a>`;
            }
            if (member.twitter) {
                linksHtml += `
                    <a href="${escapeHtml(member.twitter)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Twitter / X" title="Twitter / X">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg>
                    </a>`;
            }
            if (member.facebook) {
                linksHtml += `
                    <a href="${escapeHtml(member.facebook)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Facebook" title="Facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
                    </a>`;
            }
            if (member.github) {
                linksHtml += `
                    <a href="${escapeHtml(member.github)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="GitHub" title="GitHub">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/></svg>
                    </a>`;
            }
            if (member.website) {
                linksHtml += `
                    <a href="${escapeHtml(member.website)}" target="_blank" rel="noopener noreferrer" class="gm-team-link" aria-label="Website" title="Website">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    </a>`;
            }
            if (member.email) {
                linksHtml += `
                    <a href="mailto:${escapeHtml(member.email)}" class="gm-team-link" aria-label="Email" title="Email">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    </a>`;
            }

            // Action button
            let actionBtnHtml = '';
            if (authorUrl) {
                actionBtnHtml = `
                    <a href="${escapeHtml(authorUrl)}" class="gm-team-profile-btn">
                        <span>Profile & Posts</span>
                        ${member.postCount > 0 ? `<span class="gm-team-count-badge">(${member.postCount})</span>` : ''}
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>`;
            } else if (member.website || member.telegram) {
                actionBtnHtml = `
                    <a href="${escapeHtml(member.website || member.telegram)}" target="_blank" rel="noopener noreferrer" class="gm-team-profile-btn">
                        <span>Contact</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                    </a>`;
            }

            // Avatar markup
            let avatarMarkup = '';
            if (member.avatar) {
                avatarMarkup = `<img class="gm-team-avatar u-object-fit" src="${escapeHtml(member.avatar)}" alt="${escapeHtml(member.name)}" loading="lazy">`;
            } else {
                const initials = member.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'OP';
                avatarMarkup = `<div class="gm-team-avatar-fallback gm-team-avatar-initials">${initials}</div>`;
            }

            return `
                <div class="gm-team-card" data-department="${escapeHtml(member.department)}" data-order="${member.order}">
                    <div class="gm-team-card-inner">
                        <div class="gm-team-avatar-wrap">
                            ${avatarMarkup}
                            <span class="gm-team-status-ring ${statusClass}" title="${statusClass === 'active' ? 'Active Operative' : 'Standby'}"></span>
                        </div>

                        <div class="gm-team-info">
                            <div class="gm-team-name-row">
                                <div class="gm-team-name-group">
                                    <h3 class="gm-team-name">
                                        ${authorUrl ? `<a href="${escapeHtml(authorUrl)}">${escapeHtml(member.name)}</a>` : `<span>${escapeHtml(member.name)}</span>`}
                                    </h3>
                                    <span class="gm-team-role-title">${escapeHtml(member.title)}</span>
                                </div>
                                <span class="gm-team-badge">${escapeHtml(member.badge)}</span>
                            </div>

                            ${member.location ? `<div class="gm-team-location"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span>${escapeHtml(member.location)}</span></div>` : ''}

                            <p class="gm-team-bio">${escapeHtml(member.bio)}</p>

                            <div class="gm-team-meta-row">
                                <div class="gm-team-links">
                                    ${linksHtml}
                                </div>
                                ${actionBtnHtml}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = cardsHtml;
        container.setAttribute('data-team-loaded', 'true');
    }

    function setupFilters() {
        const filterBar = document.getElementById('gm-team-filters');
        const grid = document.getElementById('gm-team-grid');
        if (!filterBar || !grid) return;

        const buttons = filterBar.querySelectorAll('.gm-team-filter-btn');
        buttons.forEach(btn => {
            btn.addEventListener('click', function() {
                buttons.forEach(b => b.classList.remove('is-active'));
                this.classList.add('is-active');

                const filter = this.getAttribute('data-filter') || 'all';
                const cards = grid.querySelectorAll('.gm-team-card');

                cards.forEach(card => {
                    const dept = card.getAttribute('data-department') || '';
                    if (filter === 'all' || dept.toLowerCase().includes(filter.toLowerCase())) {
                        card.style.display = '';
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
})();

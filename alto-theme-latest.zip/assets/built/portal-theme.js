/**
 * Ghost Portal Glassmorphism Styler (v7 - Definitive Fix for Email Preferences & Your Account)
 * - Complete redesign of "Email preferences" and "Your account" popups
 * - Replaces broken single-box layout with elegant glassmorphism cards per item
 * - Eradicates all pink from toggle switches (.input-toggle-component) with Electric Cyan #38bdf8
 * - Overrides Ghost's internal --brandcolor variable to #38bdf8
 * - Sets script[data-ghost].dataset.accentColor to prevent Ghost from ever generating pink
 * - Mobile responsive architecture with full-width action stacking and flex-start scrolling
 */
(function() {
  // Pre-seed Ghost Portal config if script tag exists
  function seedGhostAccent() {
    try {
      const ghostScript = document.querySelector('script[data-ghost]');
      if (ghostScript && ghostScript.dataset.accentColor !== '#38bdf8') {
        ghostScript.setAttribute('data-accent-color', '#38bdf8');
        ghostScript.dataset.accentColor = '#38bdf8';
      }
    } catch(e) {}
  }
  seedGhostAccent();
  document.addEventListener('DOMContentLoaded', seedGhostAccent);

  const darkCSS = `
    /* Force Obsidian/Cyan palette across the entire iframe */
    :root, html, body {
      --brandcolor: #38bdf8 !important;
      --ghost-accent-color: #38bdf8 !important;
      accent-color: #38bdf8 !important;
      box-sizing: border-box !important;
    }

    /* Reset html and body */
    html, body {
      background: transparent !important;
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
      height: 100% !important;
      overflow-x: hidden !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Inter", sans-serif !important;
      -webkit-font-smoothing: antialiased !important;
    }

    /* Fullscreen Backdrop Blur */
    .gh-portal-popup-background {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: rgba(4, 6, 9, 0.82) !important;
      backdrop-filter: blur(20px) !important;
      -webkit-backdrop-filter: blur(20px) !important;
      z-index: 10 !important;
      animation: gmPortalFade 0.2s ease forwards !important;
    }

    /* Flexbox Modal Wrapper: Uses flex-start to prevent cutting off top on mobile */
    .gh-portal-popup-wrapper {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      display: flex !important;
      align-items: flex-start !important;
      justify-content: center !important;
      background: transparent !important;
      padding: 36px 16px 48px 16px !important;
      box-sizing: border-box !important;
      z-index: 20 !important;
      overflow-y: auto !important;
      -webkit-overflow-scrolling: touch !important;
    }

    /* Monochromatic Obsidian Glass Portal Container */
    .gh-portal-popup-container {
      margin: auto !important;
      width: 100% !important;
      max-width: 480px !important;
      min-height: auto !important;
      position: relative !important;
      box-sizing: border-box !important;
      padding: 36px 32px !important;
      border-radius: 24px !important;
      background: rgba(13, 17, 26, 0.96) !important;
      backdrop-filter: blur(32px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(32px) saturate(180%) !important;
      border: 1px solid rgba(255, 255, 255, 0.12) !important;
      box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.92), 
                  0 0 30px rgba(56, 189, 248, 0.08), 
                  inset 0 1px 0 rgba(255, 255, 255, 0.12) !important;
      color: #f8fafc !important;
      animation: gmPortalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
    }

    /* Account & Newsletter Preferences (Wide Modal Layout) */
    .gh-portal-popup-container.account,
    .gh-portal-popup-container:has(.gh-portal-email-preferences-header),
    .gh-portal-popup-container:has(.gh-portal-account-header),
    .gh-portal-popup-container:has(.gh-portal-list-toggle-wrapper) {
      max-width: 520px !important;
      padding: 36px 32px !important;
    }

    @keyframes gmPortalFade {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes gmPortalFadeIn {
      from { opacity: 0; transform: scale(0.96) translateY(8px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }

    /* ========================================================================
       HEADER & NAVIGATION
       ======================================================================== */
    .gh-portal-main-title,
    .gh-portal-detail-header h3,
    .gh-portal-account-header h2 {
      color: #ffffff !important;
      font-weight: 800 !important;
      font-size: 22px !important;
      letter-spacing: -0.03em !important;
      margin: 0 !important;
      text-align: center !important;
    }

    .gh-portal-email-preferences-header,
    .gh-portal-detail-header {
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      position: relative !important;
      width: 100% !important;
      margin-bottom: 24px !important;
      min-height: 36px !important;
    }

    .gh-portal-detail-header .gh-portal-btn-back {
      position: absolute !important;
      left: 0 !important;
      top: 50% !important;
      transform: translateY(-50%) !important;
      width: 36px !important;
      height: 36px !important;
      border-radius: 50% !important;
      background: rgba(255, 255, 255, 0.06) !important;
      border: 1px solid rgba(255, 255, 255, 0.12) !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      cursor: pointer !important;
      padding: 0 !important;
      color: #94a3b8 !important;
      transition: all 0.2s ease !important;
    }

    .gh-portal-detail-header .gh-portal-btn-back:hover {
      background: rgba(255, 255, 255, 0.12) !important;
      color: #ffffff !important;
      border-color: rgba(56, 189, 248, 0.4) !important;
    }

    .gh-portal-detail-header .gh-portal-btn-back svg {
      width: 18px !important;
      height: 18px !important;
    }

    /* Close Button in Modal Top-Right */
    .gh-portal-closeicon-container {
      cursor: pointer !important;
      top: 18px !important;
      right: 18px !important;
      position: absolute !important;
      width: 34px !important;
      height: 34px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      z-index: 50 !important;
      border-radius: 50% !important;
      background: rgba(255, 255, 255, 0.05) !important;
      border: 1px solid rgba(255, 255, 255, 0.1) !important;
      transition: all 0.2s ease !important;
    }

    .gh-portal-closeicon-container:hover {
      background: rgba(255, 255, 255, 0.12) !important;
      border-color: rgba(255, 255, 255, 0.2) !important;
    }

    .gh-portal-closeicon {
      color: #94a3b8 !important;
      transition: color 0.2s ease !important;
    }

    .gh-portal-closeicon:hover {
      color: #ffffff !important;
    }

    /* ========================================================================
       EMAIL PREFERENCES & LIST REDESIGN
       ======================================================================== */
    /* Container list: clean vertical stack */
    .gh-portal-list {
      display: flex !important;
      flex-direction: column !important;
      gap: 12px !important;
      width: 100% !important;
      background: transparent !important;
      border: none !important;
      padding: 0 !important;
      margin: 0 !important;
      box-shadow: none !important;
    }

    .gh-portal-section.flex {
      display: block !important;
      width: 100% !important;
      margin: 0 !important;
      padding: 0 !important;
    }

    /* Each Newsletter / Preference Row: Distinct Glass Card */
    .gh-portal-list-toggle-wrapper,
    .gh-portal-list-clickable,
    .gh-portal-list > section {
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: space-between !important;
      background: rgba(255, 255, 255, 0.04) !important;
      border: 1px solid rgba(255, 255, 255, 0.09) !important;
      border-radius: 16px !important;
      padding: 18px 20px !important;
      margin: 0 !important;
      width: 100% !important;
      box-sizing: border-box !important;
      transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
      cursor: pointer !important;
      text-align: left !important;
    }

    .gh-portal-list-toggle-wrapper:hover,
    .gh-portal-list-clickable:hover,
    .gh-portal-list > section:hover {
      background: rgba(255, 255, 255, 0.07) !important;
      border-color: rgba(56, 189, 248, 0.35) !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.35) !important;
    }

    /* Content inside card */
    .gh-portal-list-detail {
      flex: 1 1 auto !important;
      min-width: 0 !important;
      padding: 0 !important;
      margin-right: 16px !important;
      text-align: left !important;
    }

    .gh-portal-list-detail h3 {
      color: #ffffff !important;
      font-size: 15px !important;
      font-weight: 700 !important;
      margin: 0 0 3px 0 !important;
      letter-spacing: -0.01em !important;
      line-height: 1.3 !important;
    }

    .gh-portal-list-detail p {
      color: #94a3b8 !important;
      font-size: 13px !important;
      margin: 0 !important;
      line-height: 1.45 !important;
      word-break: break-word !important;
    }

    /* Action button in row (e.g. Edit) */
    .gh-portal-list-action {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      padding: 6px 14px !important;
      border-radius: 999px !important;
      background: rgba(56, 189, 248, 0.1) !important;
      border: 1px solid rgba(56, 189, 248, 0.25) !important;
      color: #38bdf8 !important;
      font-size: 13px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      flex-shrink: 0 !important;
    }

    .gh-portal-list-action:hover {
      background: #38bdf8 !important;
      color: #040609 !important;
      box-shadow: 0 0 12px rgba(56, 189, 248, 0.35) !important;
    }

    /* Help Section ("Not receiving emails? Get help →") */
    .gh-portal-list-help {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      padding: 14px 18px !important;
      background: rgba(255, 255, 255, 0.02) !important;
      border: 1px dashed rgba(255, 255, 255, 0.12) !important;
      border-radius: 14px !important;
      margin-top: 8px !important;
      box-sizing: border-box !important;
      width: 100% !important;
    }

    .gh-portal-list-help-label {
      color: #94a3b8 !important;
      font-size: 13px !important;
      font-weight: 500 !important;
    }

    .gh-portal-btn-text.gh-email-faq-page-button {
      color: #38bdf8 !important;
      font-size: 13px !important;
      font-weight: 600 !important;
      background: none !important;
      border: none !important;
      cursor: pointer !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 4px !important;
      padding: 0 !important;
      transition: color 0.2s ease !important;
    }

    .gh-portal-btn-text.gh-email-faq-page-button:hover {
      color: #7dd3fc !important;
      text-decoration: underline !important;
    }

    /* Unsubscribe from All Emails */
    .gh-portal-btn-unsubscribe {
      margin-top: 24px !important;
      width: 100% !important;
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
    }

    .gh-portal-btn-unsubscribe button,
    .gh-portal-btn-unsubscribe .gh-portal-btn {
      width: 100% !important;
      height: 44px !important;
      border-radius: 999px !important;
      background: rgba(239, 68, 68, 0.08) !important;
      border: 1px solid rgba(239, 68, 68, 0.25) !important;
      color: #f87171 !important;
      font-size: 14px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
    }

    .gh-portal-btn-unsubscribe button:hover,
    .gh-portal-btn-unsubscribe .gh-portal-btn:hover {
      background: rgba(239, 68, 68, 0.18) !important;
      border-color: #ef4444 !important;
      color: #ffffff !important;
      box-shadow: 0 0 16px rgba(239, 68, 68, 0.25) !important;
    }

    .gh-portal-btn-unsubscribe-note {
      color: #64748b !important;
      font-size: 12px !important;
      text-align: center !important;
      margin-top: 10px !important;
      line-height: 1.4 !important;
    }

    /* ========================================================================
       ERADICATE ALL PINK TOGGLE SWITCHES (.input-toggle-component)
       Electric Cyan #38bdf8 in Dark Mode
       ======================================================================== */
    /* Target Ghost Portal's Exact Switch Component */
    .gh-portal-for-switch {
      position: relative !important;
      display: inline-flex !important;
      align-items: center !important;
      flex-shrink: 0 !important;
      margin: 0 !important;
    }

    .gh-portal-for-switch .switch {
      position: relative !important;
      display: inline-block !important;
      width: 46px !important;
      height: 26px !important;
      margin: 0 !important;
      cursor: pointer !important;
    }

    .gh-portal-for-switch input[type="checkbox"] {
      position: absolute !important;
      opacity: 0 !important;
      width: 0 !important;
      height: 0 !important;
      pointer-events: none !important;
    }

    /* Inactive Track */
    .gh-portal-for-switch .input-toggle-component,
    .input-toggle-component {
      position: absolute !important;
      inset: 0 !important;
      background: rgba(255, 255, 255, 0.16) !important;
      border: 1px solid rgba(255, 255, 255, 0.18) !important;
      border-radius: 999px !important;
      transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
      cursor: pointer !important;
      width: 46px !important;
      height: 26px !important;
      box-sizing: border-box !important;
    }

    /* Inactive Knob */
    .gh-portal-for-switch .input-toggle-component:before,
    .input-toggle-component:before {
      position: absolute !important;
      content: "" !important;
      height: 18px !important;
      width: 18px !important;
      left: 3px !important;
      bottom: 3px !important;
      background: #ffffff !important;
      border-radius: 50% !important;
      transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4) !important;
    }

    /* Active Track: Pure Electric Cyan #38bdf8 - ZERO PINK! */
    .gh-portal-for-switch input:checked + .input-toggle-component,
    input[type="checkbox"]:checked + .input-toggle-component,
    .input-toggle-component.checked,
    [style*="rgb(240, 37, 116)"],
    [style*="#ff0077"],
    [style*="rgb(255, 0, 119)"] {
      background: #38bdf8 !important;
      background-color: #38bdf8 !important;
      border-color: #38bdf8 !important;
      box-shadow: 0 0 16px rgba(56, 189, 248, 0.5) !important;
    }

    /* Active Knob: Slide right */
    .gh-portal-for-switch input:checked + .input-toggle-component:before,
    input[type="checkbox"]:checked + .input-toggle-component:before {
      transform: translateX(20px) !important;
      background: #ffffff !important;
    }

    /* ========================================================================
       YOUR ACCOUNT POPUP LAYOUT
       ======================================================================== */
    .gh-portal-account-header {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      margin-bottom: 24px !important;
      text-align: center !important;
      width: 100% !important;
    }

    .gh-portal-account-header .gh-portal-avatar {
      width: 60px !important;
      height: 60px !important;
      border-radius: 50% !important;
      margin: 0 auto 12px auto !important;
      border: 2px solid rgba(56, 189, 248, 0.4) !important;
      box-shadow: 0 0 16px rgba(56, 189, 248, 0.2) !important;
      overflow: hidden !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      background: #090d16 !important;
    }

    .gh-portal-account-header .gh-portal-avatar svg {
      width: 36px !important;
      height: 36px !important;
      color: #38bdf8 !important;
    }

    /* Account Action Footer */
    footer.gh-portal-account-footer {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      margin-top: 24px !important;
      width: 100% !important;
      padding: 0 !important;
    }

    .gh-portal-account-footermenu {
      display: flex !important;
      align-items: center !important;
      list-style: none !important;
      padding: 0 !important;
      margin: 0 !important;
    }

    .gh-portal-account-footer button.gh-portal-btn,
    button[data-test-button="footer-signout"] {
      background: rgba(255, 255, 255, 0.08) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #cbd5e1 !important;
      border-radius: 999px !important;
      padding: 8px 18px !important;
      font-size: 13px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
    }

    .gh-portal-account-footer button.gh-portal-btn:hover,
    button[data-test-button="footer-signout"]:hover {
      background: rgba(255, 255, 255, 0.16) !important;
      color: #ffffff !important;
    }

    a[data-test-link="footer-support"],
    .gh-portal-account-footerright a.gh-portal-btn {
      background: #ffffff !important;
      border: 1px solid #ffffff !important;
      color: #040609 !important;
      border-radius: 999px !important;
      padding: 8px 18px !important;
      font-size: 13px !important;
      font-weight: 700 !important;
      text-decoration: none !important;
      display: inline-flex !important;
      align-items: center !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
    }

    a[data-test-link="footer-support"]:hover,
    .gh-portal-account-footerright a.gh-portal-btn:hover {
      background: #f1f5f9 !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 4px 14px rgba(255, 255, 255, 0.2) !important;
    }

    /* Watermark Killer */
    .gh-portal-powered,
    #ghost-portal-root .gh-portal-powered {
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
    }

    /* ========================================================================
       MOBILE VIEW FIXES (iPhone, Android < 640px)
       ======================================================================== */
    @media (max-width: 640px) {
      .gh-portal-popup-wrapper {
        padding: 16px 12px 36px 12px !important;
        align-items: flex-start !important;
      }

      .gh-portal-popup-container {
        padding: 24px 16px !important;
        border-radius: 20px !important;
        max-width: 100% !important;
        width: 100% !important;
        margin: 8px auto 24px auto !important;
      }

      .gh-portal-list-toggle-wrapper,
      .gh-portal-list-clickable,
      .gh-portal-list > section {
        padding: 14px 16px !important;
        border-radius: 14px !important;
      }

      .gh-portal-list-detail h3 {
        font-size: 14px !important;
      }

      .gh-portal-list-detail p {
        font-size: 12px !important;
      }

      footer.gh-portal-account-footer {
        flex-direction: column !important;
        gap: 10px !important;
        width: 100% !important;
      }

      .gh-portal-account-footermenu,
      .gh-portal-account-footerright {
        width: 100% !important;
      }

      .gh-portal-account-footermenu li {
        width: 100% !important;
      }

      .gh-portal-account-footer button.gh-portal-btn,
      button[data-test-button="footer-signout"],
      a[data-test-link="footer-support"],
      .gh-portal-account-footerright a.gh-portal-btn {
        width: 100% !important;
        height: 44px !important;
        justify-content: center !important;
        display: inline-flex !important;
        align-items: center !important;
      }
    }
  `;

  const lightCSS = `
    /* Force Lunar/Blue palette across the entire iframe */
    :root, html, body {
      --brandcolor: #0284c7 !important;
      --ghost-accent-color: #0284c7 !important;
      accent-color: #0284c7 !important;
      box-sizing: border-box !important;
    }

    html, body {
      background: transparent !important;
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
      height: 100% !important;
      overflow-x: hidden !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Inter", sans-serif !important;
    }

    .gh-portal-popup-background {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: rgba(15, 23, 42, 0.45) !important;
      backdrop-filter: blur(16px) !important;
      -webkit-backdrop-filter: blur(16px) !important;
      z-index: 10 !important;
      animation: gmPortalFade 0.2s ease forwards !important;
    }

    .gh-portal-popup-wrapper {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      display: flex !important;
      align-items: flex-start !important;
      justify-content: center !important;
      background: transparent !important;
      padding: 36px 16px 48px 16px !important;
      box-sizing: border-box !important;
      z-index: 20 !important;
      overflow-y: auto !important;
      -webkit-overflow-scrolling: touch !important;
    }

    .gh-portal-popup-container {
      margin: auto !important;
      width: 100% !important;
      max-width: 480px !important;
      position: relative !important;
      box-sizing: border-box !important;
      padding: 36px 32px !important;
      border-radius: 24px !important;
      background: rgba(255, 255, 255, 0.96) !important;
      backdrop-filter: blur(32px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(32px) saturate(180%) !important;
      border: 1px solid rgba(0, 0, 0, 0.1) !important;
      box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.2), 
                  0 0 20px rgba(0, 0, 0, 0.05), 
                  inset 0 1px 0 rgba(255, 255, 255, 0.9) !important;
      color: #0f172a !important;
      animation: gmPortalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
    }

    .gh-portal-popup-container.account,
    .gh-portal-popup-container:has(.gh-portal-email-preferences-header),
    .gh-portal-popup-container:has(.gh-portal-account-header),
    .gh-portal-popup-container:has(.gh-portal-list-toggle-wrapper) {
      max-width: 520px !important;
      padding: 36px 32px !important;
    }

    .gh-portal-main-title,
    .gh-portal-detail-header h3,
    .gh-portal-account-header h2 {
      color: #0f172a !important;
      font-weight: 800 !important;
      font-size: 22px !important;
      letter-spacing: -0.03em !important;
      margin: 0 !important;
      text-align: center !important;
    }

    .gh-portal-email-preferences-header,
    .gh-portal-detail-header {
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      position: relative !important;
      width: 100% !important;
      margin-bottom: 24px !important;
      min-height: 36px !important;
    }

    .gh-portal-detail-header .gh-portal-btn-back {
      position: absolute !important;
      left: 0 !important;
      top: 50% !important;
      transform: translateY(-50%) !important;
      width: 36px !important;
      height: 36px !important;
      border-radius: 50% !important;
      background: rgba(0, 0, 0, 0.05) !important;
      border: 1px solid rgba(0, 0, 0, 0.1) !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      cursor: pointer !important;
      padding: 0 !important;
      color: #64748b !important;
      transition: all 0.2s ease !important;
    }

    .gh-portal-detail-header .gh-portal-btn-back:hover {
      background: rgba(0, 0, 0, 0.1) !important;
      color: #0f172a !important;
    }

    .gh-portal-list {
      display: flex !important;
      flex-direction: column !important;
      gap: 12px !important;
      width: 100% !important;
      background: transparent !important;
      border: none !important;
      padding: 0 !important;
      margin: 0 !important;
    }

    .gh-portal-section.flex {
      display: block !important;
      width: 100% !important;
      margin: 0 !important;
      padding: 0 !important;
    }

    .gh-portal-list-toggle-wrapper,
    .gh-portal-list-clickable,
    .gh-portal-list > section {
      display: flex !important;
      flex-direction: row !important;
      align-items: center !important;
      justify-content: space-between !important;
      background: rgba(0, 0, 0, 0.03) !important;
      border: 1px solid rgba(0, 0, 0, 0.08) !important;
      border-radius: 16px !important;
      padding: 18px 20px !important;
      margin: 0 !important;
      width: 100% !important;
      box-sizing: border-box !important;
      transition: all 0.2s ease !important;
      cursor: pointer !important;
      text-align: left !important;
    }

    .gh-portal-list-toggle-wrapper:hover,
    .gh-portal-list-clickable:hover,
    .gh-portal-list > section:hover {
      background: rgba(0, 0, 0, 0.06) !important;
      border-color: rgba(2, 132, 199, 0.3) !important;
      transform: translateY(-1px) !important;
    }

    .gh-portal-list-detail h3 {
      color: #0f172a !important;
      font-size: 15px !important;
      font-weight: 700 !important;
      margin: 0 0 3px 0 !important;
    }

    .gh-portal-list-detail p {
      color: #64748b !important;
      font-size: 13px !important;
      margin: 0 !important;
      line-height: 1.45 !important;
    }

    .gh-portal-list-action {
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      padding: 6px 14px !important;
      border-radius: 999px !important;
      background: rgba(2, 132, 199, 0.08) !important;
      border: 1px solid rgba(2, 132, 199, 0.25) !important;
      color: #0284c7 !important;
      font-size: 13px !important;
      font-weight: 600 !important;
    }

    /* Switches (Light Mode -> Lunar Blue #0284c7) */
    .gh-portal-for-switch {
      position: relative !important;
      display: inline-flex !important;
      align-items: center !important;
      flex-shrink: 0 !important;
      margin: 0 !important;
    }

    .gh-portal-for-switch .switch {
      position: relative !important;
      display: inline-block !important;
      width: 46px !important;
      height: 26px !important;
      margin: 0 !important;
      cursor: pointer !important;
    }

    .gh-portal-for-switch input[type="checkbox"] {
      position: absolute !important;
      opacity: 0 !important;
      width: 0 !important;
      height: 0 !important;
    }

    .gh-portal-for-switch .input-toggle-component,
    .input-toggle-component {
      position: absolute !important;
      inset: 0 !important;
      background: rgba(0, 0, 0, 0.14) !important;
      border: 1px solid rgba(0, 0, 0, 0.12) !important;
      border-radius: 999px !important;
      transition: all 0.25s ease !important;
      cursor: pointer !important;
      width: 46px !important;
      height: 26px !important;
    }

    .gh-portal-for-switch .input-toggle-component:before,
    .input-toggle-component:before {
      position: absolute !important;
      content: "" !important;
      height: 18px !important;
      width: 18px !important;
      left: 3px !important;
      bottom: 3px !important;
      background: #ffffff !important;
      border-radius: 50% !important;
      transition: transform 0.25s ease !important;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2) !important;
    }

    .gh-portal-for-switch input:checked + .input-toggle-component,
    input[type="checkbox"]:checked + .input-toggle-component,
    .input-toggle-component.checked,
    [style*="rgb(240, 37, 116)"],
    [style*="#ff0077"],
    [style*="rgb(255, 0, 119)"] {
      background: #0284c7 !important;
      background-color: #0284c7 !important;
      border-color: #0284c7 !important;
      box-shadow: 0 0 14px rgba(2, 132, 199, 0.35) !important;
    }

    .gh-portal-for-switch input:checked + .input-toggle-component:before,
    input[type="checkbox"]:checked + .input-toggle-component:before {
      transform: translateX(20px) !important;
      background: #ffffff !important;
    }

    .gh-portal-list-help {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      padding: 14px 18px !important;
      background: rgba(0, 0, 0, 0.02) !important;
      border: 1px dashed rgba(0, 0, 0, 0.15) !important;
      border-radius: 14px !important;
      margin-top: 8px !important;
    }

    .gh-portal-list-help-label {
      color: #64748b !important;
      font-size: 13px !important;
    }

    .gh-portal-btn-text.gh-email-faq-page-button {
      color: #0284c7 !important;
      font-size: 13px !important;
      font-weight: 600 !important;
      background: none !important;
      border: none !important;
    }

    .gh-portal-btn-unsubscribe button {
      width: 100% !important;
      height: 44px !important;
      border-radius: 999px !important;
      background: rgba(239, 68, 68, 0.08) !important;
      border: 1px solid rgba(239, 68, 68, 0.25) !important;
      color: #dc2626 !important;
      font-size: 14px !important;
      font-weight: 600 !important;
    }

    footer.gh-portal-account-footer {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      margin-top: 24px !important;
      width: 100% !important;
    }

    .gh-portal-account-footer button.gh-portal-btn {
      background: rgba(0, 0, 0, 0.06) !important;
      border: 1px solid rgba(0, 0, 0, 0.12) !important;
      color: #334155 !important;
      border-radius: 999px !important;
      padding: 8px 18px !important;
      font-size: 13px !important;
    }

    a[data-test-link="footer-support"] {
      background: #0f172a !important;
      color: #ffffff !important;
      border-radius: 999px !important;
      padding: 8px 18px !important;
      font-size: 13px !important;
      font-weight: 700 !important;
      text-decoration: none !important;
    }

    .gh-portal-powered,
    #ghost-portal-root .gh-portal-powered {
      display: none !important;
    }

    @media (max-width: 640px) {
      .gh-portal-popup-wrapper {
        padding: 16px 12px 36px 12px !important;
      }
      .gh-portal-popup-container {
        padding: 24px 16px !important;
        border-radius: 20px !important;
        max-width: 100% !important;
        width: 100% !important;
      }
      footer.gh-portal-account-footer {
        flex-direction: column !important;
        gap: 10px !important;
      }
      .gh-portal-account-footermenu,
      .gh-portal-account-footerright {
        width: 100% !important;
      }
      .gh-portal-account-footer button.gh-portal-btn,
      a[data-test-link="footer-support"] {
        width: 100% !important;
        height: 44px !important;
        justify-content: center !important;
        display: inline-flex !important;
        align-items: center !important;
      }
    }
  `;

  let isDebounceScheduled = false;

  function scheduleApplyModalThemes() {
    if (isDebounceScheduled) return;
    isDebounceScheduled = true;
    requestAnimationFrame(function() {
      isDebounceScheduled = false;
      applyModalThemes();
    });
  }

  function cleanPinkDOM(doc, isDark) {
    if (!doc) return;
    const accent = isDark ? '#38bdf8' : '#0284c7';
    try {
      const allEls = doc.querySelectorAll('*');
      for (let i = 0; i < allEls.length; i++) {
        const el = allEls[i];
        const s = el.getAttribute('style');
        if (s && (s.includes('240, 37, 116') || s.includes('ff0077') || s.includes('255, 0, 119'))) {
          el.style.setProperty('background-color', accent, 'important');
          el.style.setProperty('border-color', accent, 'important');
          el.style.setProperty('color', '#ffffff', 'important');
        }
      }
    } catch (e) {}
  }

  function injectCSS(iframe, styleId, cssContent, themeName, isDark) {
    try {
      const doc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
      if (!doc) return;

      const targetHead = doc.head || doc.body;
      if (!targetHead) return;

      let style = doc.getElementById(styleId);
      if (style) {
        if (style.getAttribute('data-applied-theme') !== themeName || style.textContent !== cssContent) {
          style.setAttribute('data-applied-theme', themeName);
          style.textContent = cssContent;
        }
        // Ensure our style tag is always at the very bottom of <head>
        if (targetHead.lastElementChild !== style) {
          targetHead.appendChild(style);
        }
      } else {
        style = doc.createElement('style');
        style.id = styleId;
        style.setAttribute('data-applied-theme', themeName);
        style.textContent = cssContent;
        targetHead.appendChild(style);
      }

      cleanPinkDOM(doc, isDark);

      // Attach local frame observer to clean dynamically toggled states
      if (!doc._gmObserved) {
        doc._gmObserved = true;
        const frameObs = new MutationObserver(function() {
          cleanPinkDOM(doc, isDark);
          // Keep style element at the very bottom
          const currentStyle = doc.getElementById(styleId);
          if (currentStyle && targetHead.lastElementChild !== currentStyle) {
            targetHead.appendChild(currentStyle);
          }
        });
        frameObs.observe(doc.documentElement, {
          attributes: true,
          childList: true,
          subtree: true,
          attributeFilter: ['style', 'class']
        });
      }
    } catch (e) {}
  }

  function applyModalThemes() {
    seedGhostAccent();
    const root = document.documentElement;
    const isDark = root.classList.contains('dark-mode') || root.getAttribute('data-theme') === 'dark';
    const isLight = root.classList.contains('light-mode') || root.getAttribute('data-theme') === 'light' || !isDark;
    const themeName = isLight ? 'light' : 'dark';
    const targetPortalCSS = isLight ? lightCSS : darkCSS;

    const portalIframes = Array.from(document.querySelectorAll('iframe')).filter(function(iframe) {
      return iframe.title === 'portal-popup' ||
             iframe.closest('#ghost-portal-root') ||
             (iframe.id && iframe.id.includes('portal')) ||
             (iframe.src && iframe.src.includes('portal'));
    });

    portalIframes.forEach(function(iframe) {
      injectCSS(iframe, 'gm-portal-custom-style', targetPortalCSS, themeName, isDark);
    });
  }

  // 1. Observe addition of portal container & iframes
  const observer = new MutationObserver(function(mutations) {
    for (let i = 0; i < mutations.length; i++) {
      const addedNodes = mutations[i].addedNodes;
      for (let j = 0; j < addedNodes.length; j++) {
        const node = addedNodes[j];
        if (node.nodeType === 1 && (node.id === 'ghost-portal-root' || node.tagName === 'IFRAME' || (node.querySelector && node.querySelector('iframe')))) {
          scheduleApplyModalThemes();
          return;
        }
      }
    }
  });

  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // 2. Observe theme changes on <html>
  const themeObserver = new MutationObserver(function() {
    scheduleApplyModalThemes();
  });
  themeObserver.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class', 'data-theme']
  });

  // 3. Listen for clicks & hash changes
  window.addEventListener('hashchange', function() {
    scheduleApplyModalThemes();
    // Short burst of updates to ensure React mounting completes
    let count = 0;
    const interval = setInterval(function() {
      applyModalThemes();
      count++;
      if (count >= 15) clearInterval(interval);
    }, 60);
  });

  document.addEventListener('click', function(e) {
    const target = e.target;
    if (target && target.closest && target.closest('[data-portal], a[href*="#/portal"], .gh-portal-trigger, .gm-head-signin-btn, button, input')) {
      scheduleApplyModalThemes();
      let count = 0;
      const interval = setInterval(function() {
        applyModalThemes();
        count++;
        if (count >= 10) clearInterval(interval);
      }, 50);
    }
  });

  scheduleApplyModalThemes();
  setInterval(applyModalThemes, 500);
})();

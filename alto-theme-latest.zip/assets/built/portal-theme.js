/**
 * Ghost Portal Glassmorphism Styler (v6 - Zero Pink, Flawless Mobile & Preferences)
 * - Eradicates all pink from toggle switches, active controls, and inline styles
 * - Re-architects mobile layout for "Your account" and "Email preferences" popups
 * - Ensures modals never cut off at the top on small mobile screens
 */
(function() {
  const darkCSS = `
    /* Force Obsidian/Cyan palette across the entire iframe */
    :root, body, * {
      --ghost-accent-color: #38bdf8 !important;
      accent-color: #38bdf8 !important;
      box-sizing: border-box !important;
    }

    /* Reset html and body */
    html, body {
      background: transparent !important;
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
      height: 100% !important;
      overflow-x: hidden !important;
    }

    /* Fullscreen Backdrop Blur */
    .gh-portal-popup-background {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: rgba(4, 6, 9, 0.8) !important;
      backdrop-filter: blur(16px) !important;
      -webkit-backdrop-filter: blur(16px) !important;
      z-index: 10 !important;
      animation: gmPortalFade 0.2s ease forwards !important;
    }

    /* Flexbox Modal Wrapper: Uses flex-start to prevent cutting off top on tall modals */
    .gh-portal-popup-wrapper {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      display: flex !important;
      align-items: flex-start !important;
      justify-content: center !important;
      background: transparent !important;
      padding: 32px 16px 48px 16px !important;
      box-sizing: border-box !important;
      z-index: 20 !important;
      overflow-y: auto !important;
      -webkit-overflow-scrolling: touch !important;
    }

    /* Monochromatic Obsidian Glass Portal Container */
    .gh-portal-popup-container {
      margin: auto !important;
      width: 100% !important;
      max-width: 440px !important;
      min-height: auto !important;
      position: relative !important;
      box-sizing: border-box !important;
      padding: 36px 32px !important;
      border-radius: 24px !important;
      background: rgba(13, 17, 26, 0.95) !important;
      backdrop-filter: blur(28px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(28px) saturate(180%) !important;
      border: 1px solid rgba(255, 255, 255, 0.12) !important;
      box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.92), 
                  0 0 30px rgba(56, 189, 248, 0.06), 
                  inset 0 1px 0 rgba(255, 255, 255, 0.12) !important;
      color: #f8fafc !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Inter", sans-serif !important;
      animation: gmPortalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
    }

    /* Account & Newsletter Preferences (Spacious Glass Modal) */
    .gh-portal-popup-container:has(.gh-portal-account-wrapper),
    .gh-portal-popup-container:has(.gh-portal-account-main),
    .gh-portal-popup-container:has(.gh-portal-list),
    .gh-portal-popup-container:has(.gh-portal-newsletters),
    .gh-portal-popup-container:has(.gh-portal-newsletter-card),
    .gh-portal-popup-container.account,
    .gh-portal-popup-container.newsletters {
      max-width: 620px !important;
      padding: 36px 32px !important;
    }

    @keyframes gmPortalFade {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes gmPortalFadeIn {
      from { opacity: 0; transform: scale(0.96) translateY(8px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }

    /* Typography */
    .gh-portal-main-title,
    .gh-portal-account-main h2 {
      color: #ffffff !important;
      font-weight: 800 !important;
      font-size: 24px !important;
      letter-spacing: -0.03em !important;
      margin: 0 0 8px 0 !important;
      text-align: center !important;
    }

    .gh-portal-signup-logo {
      border-radius: 14px !important;
      max-height: 52px !important;
      object-fit: contain !important;
      margin: 0 auto 16px auto !important;
      display: block !important;
    }

    .gh-portal-input-label {
      color: #94a3b8 !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      text-transform: uppercase !important;
      letter-spacing: 0.06em !important;
      margin-bottom: 6px !important;
    }

    /* Input Fields */
    .gh-portal-input {
      background: rgba(255, 255, 255, 0.06) !important;
      border: 1px solid rgba(255, 255, 255, 0.14) !important;
      border-radius: 12px !important;
      color: #ffffff !important;
      font-size: 15px !important;
      height: 48px !important;
      padding: 0 16px !important;
      outline: none !important;
      transition: all 0.2s ease !important;
      box-sizing: border-box !important;
      width: 100% !important;
    }

    .gh-portal-input:focus {
      border-color: #38bdf8 !important;
      background: rgba(255, 255, 255, 0.1) !important;
      box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15) !important;
    }

    .gh-portal-input::placeholder {
      color: #64748b !important;
    }

    /* Primary Action Buttons */
    .gh-portal-btn-primary,
    .gh-portal-btn-main,
    .gh-portal-btn-branded,
    .gh-portal-btn-action,
    button[type="submit"].gh-portal-btn,
    .gh-portal-btn[type="submit"],
    button.gh-portal-btn-main {
      background-color: #ffffff !important;
      color: #090b10 !important;
      border-radius: 999px !important;
      font-weight: 700 !important;
      font-size: 15px !important;
      height: 48px !important;
      width: 100% !important;
      border: 1px solid #ffffff !important;
      box-shadow: 0 4px 14px rgba(255, 255, 255, 0.15) !important;
      cursor: pointer !important;
      transition: transform 0.2s ease, background-color 0.2s ease, box-shadow 0.2s ease !important;
      margin-top: 12px !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
    }

    .gh-portal-btn-primary:hover,
    .gh-portal-btn-main:hover,
    .gh-portal-btn-branded:hover,
    .gh-portal-btn-action:hover,
    button[type="submit"].gh-portal-btn:hover,
    button.gh-portal-btn-main:hover {
      background-color: #f1f5f9 !important;
      color: #000000 !important;
      transform: translateY(-2px) !important;
      box-shadow: 0 8px 24px rgba(255, 255, 255, 0.25) !important;
    }

    /* Buttons inside Account & Preferences: Prevent 100% width blowout */
    .gh-portal-account-wrapper .gh-portal-btn,
    .gh-portal-account-main .gh-portal-btn,
    .gh-portal-list .gh-portal-btn,
    .gh-portal-setting button,
    .gh-portal-action-footer .gh-portal-btn,
    .gh-portal-account-footer .gh-portal-btn {
      width: auto !important;
      min-width: 90px !important;
      height: 40px !important;
      padding: 0 20px !important;
      font-size: 13px !important;
      margin-top: 0 !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
    }

    .gh-portal-action-footer,
    .gh-portal-account-footer {
      display: flex !important;
      align-items: center !important;
      justify-content: flex-end !important;
      gap: 12px !important;
      margin-top: 24px !important;
      width: 100% !important;
    }

    .gh-portal-btn-cancel,
    button.gh-portal-btn-secondary {
      background: rgba(255, 255, 255, 0.08) !important;
      border: 1px solid rgba(255, 255, 255, 0.16) !important;
      color: #cbd5e1 !important;
      border-radius: 999px !important;
    }

    .gh-portal-btn-cancel:hover,
    button.gh-portal-btn-secondary:hover {
      background: rgba(255, 255, 255, 0.16) !important;
      color: #ffffff !important;
    }

    /* ========================================================================
       ERADICATE ALL PINK TOGGLE SWITCHES (Dark Mode -> Electric Cyan #38bdf8)
       ======================================================================== */
    [style*="rgb(240, 37, 116)"],
    [style*="#ff0077"],
    [style*="rgb(255, 0, 119)"],
    [style*="var(--ghost-accent-color)"] {
      background-color: #38bdf8 !important;
      background: #38bdf8 !important;
      border-color: #38bdf8 !important;
    }

    .switch,
    .gh-portal-for-switch,
    .gh-portal-switch-container {
      position: relative !important;
      display: inline-block !important;
      width: 48px !important;
      height: 28px !important;
      margin: 0 !important;
      flex-shrink: 0 !important;
    }

    .switch input,
    .gh-portal-for-switch input {
      opacity: 0 !important;
      width: 0 !important;
      height: 0 !important;
    }

    /* Inactive Track */
    .slider,
    .gh-portal-switch,
    .switch span,
    .gh-portal-for-switch span:not(.slider) {
      position: absolute !important;
      cursor: pointer !important;
      inset: 0 !important;
      background: rgba(255, 255, 255, 0.16) !important;
      border-radius: 999px !important;
      transition: all 0.25s ease !important;
      border: 1px solid rgba(255, 255, 255, 0.14) !important;
    }

    /* Knob */
    .slider:before,
    .gh-portal-switch:before,
    .switch span:before,
    .gh-portal-for-switch span:before {
      position: absolute !important;
      content: "" !important;
      height: 20px !important;
      width: 20px !important;
      left: 3px !important;
      bottom: 3px !important;
      background: #ffffff !important;
      border-radius: 50% !important;
      transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4) !important;
    }

    /* Active (ON) State: Pure Cyan #38bdf8 */
    input:checked + .slider,
    input:checked + .gh-portal-switch,
    input:checked + span,
    input:checked ~ span,
    input:checked ~ .slider,
    .switch input:checked + .slider,
    .gh-portal-for-switch input:checked + span,
    .gh-portal-for-switch input:checked + div {
      background-color: #38bdf8 !important;
      background: #38bdf8 !important;
      border-color: #38bdf8 !important;
      box-shadow: 0 0 14px rgba(56, 189, 248, 0.4) !important;
    }

    input:checked + .slider:before,
    input:checked + .gh-portal-switch:before,
    input:checked + span:before,
    input:checked ~ span:before,
    input:checked ~ .slider:before {
      transform: translateX(20px) !important;
      background: #ffffff !important;
    }

    /* Newsletter & Account List Rows */
    .gh-portal-list,
    .gh-portal-setting {
      background: rgba(255, 255, 255, 0.04) !important;
      border: 1px solid rgba(255, 255, 255, 0.1) !important;
      border-radius: 16px !important;
      padding: 16px 20px !important;
      margin-bottom: 12px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      gap: 16px !important;
      box-sizing: border-box !important;
      width: 100% !important;
    }

    .gh-portal-list-detail {
      flex: 1 1 auto !important;
      min-width: 0 !important;
    }

    .gh-portal-list-title,
    .gh-portal-setting-title {
      color: #ffffff !important;
      font-size: 15px !important;
      font-weight: 700 !important;
      margin: 0 0 4px 0 !important;
    }

    .gh-portal-list-desc,
    .gh-portal-setting-desc {
      color: #94a3b8 !important;
      font-size: 13px !important;
      line-height: 1.5 !important;
      margin: 0 !important;
    }

    /* Close Icon */
    .gh-portal-closeicon-container {
      cursor: pointer !important;
      top: 18px !important;
      right: 18px !important;
      position: absolute !important;
      width: 34px !important;
      height: 34px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      z-index: 50 !important;
    }

    .gh-portal-closeicon {
      color: #94a3b8 !important;
      transition: color 0.2s ease !important;
    }

    .gh-portal-closeicon:hover {
      color: #ffffff !important;
    }

    /* Messages & Secondary Links */
    .gh-portal-signup-message,
    .gh-portal-signup-message-row,
    .gh-portal-signin-message,
    .gh-portal-footer,
    p {
      color: #94a3b8 !important;
      font-size: 14px !important;
      text-align: center !important;
    }

    .gh-portal-btn-link {
      color: #ffffff !important;
      font-weight: 700 !important;
      text-decoration: underline !important;
      cursor: pointer !important;
    }

    .gh-portal-btn-link:hover {
      color: #38bdf8 !important;
    }

    .gh-portal-btn-site-title-back {
      color: #94a3b8 !important;
      font-size: 13px !important;
      margin-bottom: 12px !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 6px !important;
    }

    .gh-portal-btn-site-title-back:hover {
      color: #ffffff !important;
    }

    /* Watermark Killer */
    .gh-portal-powered,
    #ghost-portal-root .gh-portal-powered {
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
    }

    /* ========================================================================
       MOBILE VIEW FIXES (iPhone, Android < 640px)
       ======================================================================== */
    @media (max-width: 640px) {
      .gh-portal-popup-wrapper {
        padding: 16px 12px 36px 12px !important;
        align-items: flex-start !important;
      }

      .gh-portal-popup-container,
      .gh-portal-popup-container.account,
      .gh-portal-popup-container.newsletters {
        padding: 24px 18px !important;
        border-radius: 20px !important;
        max-width: 100% !important;
        width: 100% !important;
        margin: 8px auto 24px auto !important;
      }

      .gh-portal-closeicon-container {
        top: 14px !important;
        right: 14px !important;
      }

      /* Account Header on Mobile */
      .gh-portal-account-header {
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
        text-align: center !important;
        gap: 12px !important;
        width: 100% !important;
        margin-bottom: 20px !important;
      }

      .gh-portal-account-data {
        width: 100% !important;
        text-align: center !important;
      }

      .gh-portal-account-name {
        font-size: 18px !important;
        margin-bottom: 2px !important;
        text-align: center !important;
      }

      .gh-portal-account-email {
        font-size: 13px !important;
        word-break: break-all !important;
        text-align: center !important;
      }

      .gh-portal-account-header .gh-portal-btn {
        width: 100% !important;
      }

      /* Newsletter Rows on Mobile */
      .gh-portal-list,
      .gh-portal-setting {
        padding: 14px 14px !important;
        gap: 12px !important;
        width: 100% !important;
      }

      .gh-portal-list-detail {
        min-width: 0 !important;
        flex: 1 1 auto !important;
        max-width: calc(100% - 56px) !important;
      }

      .gh-portal-list-title,
      .gh-portal-setting-title {
        font-size: 14px !important;
        margin-bottom: 2px !important;
        word-break: break-word !important;
      }

      .gh-portal-list-desc,
      .gh-portal-setting-desc {
        font-size: 12px !important;
        line-height: 1.4 !important;
        word-break: break-word !important;
      }

      .gh-portal-for-switch,
      .switch {
        flex-shrink: 0 !important;
        margin-left: auto !important;
      }

      /* Stack Action Footers Vertically on Mobile */
      .gh-portal-action-footer,
      .gh-portal-account-footer {
        display: flex !important;
        flex-direction: column !important;
        width: 100% !important;
        gap: 10px !important;
        margin-top: 20px !important;
      }

      .gh-portal-action-footer .gh-portal-btn,
      .gh-portal-account-footer .gh-portal-btn {
        width: 100% !important;
        height: 44px !important;
      }
    }
  `;

  const lightCSS = `
    /* Force Lunar/Blue palette across the entire iframe */
    :root, body, * {
      --ghost-accent-color: #0284c7 !important;
      accent-color: #0284c7 !important;
      box-sizing: border-box !important;
    }

    /* Reset html and body */
    html, body {
      background: transparent !important;
      margin: 0 !important;
      padding: 0 !important;
      width: 100% !important;
      height: 100% !important;
      overflow-x: hidden !important;
    }

    /* Fullscreen Backdrop Blur */
    .gh-portal-popup-background {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      background: rgba(15, 23, 42, 0.45) !important;
      backdrop-filter: blur(16px) !important;
      -webkit-backdrop-filter: blur(16px) !important;
      z-index: 10 !important;
      animation: gmPortalFade 0.2s ease forwards !important;
    }

    /* Flexbox Modal Wrapper: Never cut off the top on mobile */
    .gh-portal-popup-wrapper {
      position: fixed !important;
      inset: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      display: flex !important;
      align-items: flex-start !important;
      justify-content: center !important;
      background: transparent !important;
      padding: 32px 16px 48px 16px !important;
      box-sizing: border-box !important;
      z-index: 20 !important;
      overflow-y: auto !important;
      -webkit-overflow-scrolling: touch !important;
    }

    /* Monochromatic Lunar Glass Portal Container */
    .gh-portal-popup-container {
      margin: auto !important;
      width: 100% !important;
      max-width: 440px !important;
      min-height: auto !important;
      position: relative !important;
      box-sizing: border-box !important;
      padding: 36px 32px !important;
      border-radius: 24px !important;
      background: rgba(255, 255, 255, 0.96) !important;
      backdrop-filter: blur(28px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(28px) saturate(180%) !important;
      border: 1px solid rgba(0, 0, 0, 0.1) !important;
      box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.2), 
                  0 0 20px rgba(0, 0, 0, 0.05), 
                  inset 0 1px 0 rgba(255, 255, 255, 0.9) !important;
      color: #0f172a !important;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Inter", sans-serif !important;
      animation: gmPortalFadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
    }

    /* Account & Newsletter Preferences (Wide Modal Layout) */
    .gh-portal-popup-container:has(.gh-portal-account-wrapper),
    .gh-portal-popup-container:has(.gh-portal-account-main),
    .gh-portal-popup-container:has(.gh-portal-list),
    .gh-portal-popup-container:has(.gh-portal-newsletters),
    .gh-portal-popup-container:has(.gh-portal-newsletter-card),
    .gh-portal-popup-container.account,
    .gh-portal-popup-container.newsletters {
      max-width: 620px !important;
      padding: 36px 32px !important;
    }

    @keyframes gmPortalFade {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes gmPortalFadeIn {
      from { opacity: 0; transform: scale(0.96) translateY(8px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }

    /* Typography */
    .gh-portal-main-title,
    .gh-portal-account-main h2 {
      color: #090b10 !important;
      font-weight: 800 !important;
      font-size: 24px !important;
      letter-spacing: -0.03em !important;
      margin: 0 0 8px 0 !important;
      text-align: center !important;
    }

    .gh-portal-signup-logo {
      border-radius: 14px !important;
      max-height: 52px !important;
      object-fit: contain !important;
      margin: 0 auto 16px auto !important;
      display: block !important;
    }

    .gh-portal-input-label {
      color: #475569 !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      text-transform: uppercase !important;
      letter-spacing: 0.06em !important;
      margin-bottom: 6px !important;
    }

    /* Input Fields */
    .gh-portal-input {
      background: #f8fafc !important;
      border: 1px solid #cbd5e1 !important;
      border-radius: 12px !important;
      color: #090b10 !important;
      font-size: 15px !important;
      height: 48px !important;
      padding: 0 16px !important;
      outline: none !important;
      transition: all 0.2s ease !important;
      box-sizing: border-box !important;
      width: 100% !important;
    }

    .gh-portal-input:focus {
      border-color: #0284c7 !important;
      background: #ffffff !important;
      box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.15) !important;
    }

    .gh-portal-input::placeholder {
      color: #94a3b8 !important;
    }

    /* Primary Action Buttons */
    .gh-portal-btn-primary,
    .gh-portal-btn-main,
    .gh-portal-btn-branded,
    .gh-portal-btn-action,
    button[type="submit"].gh-portal-btn,
    .gh-portal-btn[type="submit"],
    button.gh-portal-btn-main {
      background-color: #090b10 !important;
      color: #ffffff !important;
      border-radius: 999px !important;
      font-weight: 700 !important;
      font-size: 15px !important;
      height: 48px !important;
      width: 100% !important;
      border: 1px solid #090b10 !important;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15) !important;
      cursor: pointer !important;
      transition: transform 0.2s ease, background-color 0.2s ease, box-shadow 0.2s ease !important;
      margin-top: 12px !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
    }

    .gh-portal-btn-primary:hover,
    .gh-portal-btn-main:hover,
    .gh-portal-btn-branded:hover,
    .gh-portal-btn-action:hover,
    button[type="submit"].gh-portal-btn:hover,
    button.gh-portal-btn-main:hover {
      background-color: #1e293b !important;
      color: #ffffff !important;
      transform: translateY(-2px) !important;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2) !important;
    }

    /* Buttons inside Account & Preferences */
    .gh-portal-account-wrapper .gh-portal-btn,
    .gh-portal-account-main .gh-portal-btn,
    .gh-portal-list .gh-portal-btn,
    .gh-portal-setting button,
    .gh-portal-action-footer .gh-portal-btn,
    .gh-portal-account-footer .gh-portal-btn {
      width: auto !important;
      min-width: 90px !important;
      height: 40px !important;
      padding: 0 20px !important;
      font-size: 13px !important;
      margin-top: 0 !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
    }

    .gh-portal-action-footer,
    .gh-portal-account-footer {
      display: flex !important;
      align-items: center !important;
      justify-content: flex-end !important;
      gap: 12px !important;
      margin-top: 24px !important;
      width: 100% !important;
    }

    .gh-portal-btn-cancel,
    button.gh-portal-btn-secondary {
      background: #f1f5f9 !important;
      border: 1px solid #cbd5e1 !important;
      color: #475569 !important;
      border-radius: 999px !important;
    }

    .gh-portal-btn-cancel:hover,
    button.gh-portal-btn-secondary:hover {
      background: #e2e8f0 !important;
      color: #090b10 !important;
    }

    /* ========================================================================
       ERADICATE ALL PINK TOGGLE SWITCHES (Light Mode -> Deep Celestial Blue #0284c7)
       ======================================================================== */
    [style*="rgb(240, 37, 116)"],
    [style*="#ff0077"],
    [style*="rgb(255, 0, 119)"],
    [style*="var(--ghost-accent-color)"] {
      background-color: #0284c7 !important;
      background: #0284c7 !important;
      border-color: #0284c7 !important;
    }

    .switch,
    .gh-portal-for-switch,
    .gh-portal-switch-container {
      position: relative !important;
      display: inline-block !important;
      width: 48px !important;
      height: 28px !important;
      margin: 0 !important;
      flex-shrink: 0 !important;
    }

    .switch input,
    .gh-portal-for-switch input {
      opacity: 0 !important;
      width: 0 !important;
      height: 0 !important;
    }

    /* Inactive Track */
    .slider,
    .gh-portal-switch,
    .switch span,
    .gh-portal-for-switch span:not(.slider) {
      position: absolute !important;
      cursor: pointer !important;
      inset: 0 !important;
      background: #cbd5e1 !important;
      border-radius: 999px !important;
      transition: all 0.25s ease !important;
      border: 1px solid #94a3b8 !important;
    }

    /* Knob */
    .slider:before,
    .gh-portal-switch:before,
    .switch span:before,
    .gh-portal-for-switch span:before {
      position: absolute !important;
      content: "" !important;
      height: 20px !important;
      width: 20px !important;
      left: 3px !important;
      bottom: 3px !important;
      background: #ffffff !important;
      border-radius: 50% !important;
      transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15) !important;
    }

    /* Active (ON) State: Pure Blue #0284c7 */
    input:checked + .slider,
    input:checked + .gh-portal-switch,
    input:checked + span,
    input:checked ~ span,
    input:checked ~ .slider,
    .switch input:checked + .slider,
    .gh-portal-for-switch input:checked + span,
    .gh-portal-for-switch input:checked + div {
      background-color: #0284c7 !important;
      background: #0284c7 !important;
      border-color: #0284c7 !important;
      box-shadow: 0 0 10px rgba(2, 132, 199, 0.3) !important;
    }

    input:checked + .slider:before,
    input:checked + .gh-portal-switch:before,
    input:checked + span:before,
    input:checked ~ span:before,
    input:checked ~ .slider:before {
      transform: translateX(20px) !important;
      background: #ffffff !important;
    }

    /* Newsletter & Account List Rows (Light Mode) */
    .gh-portal-list,
    .gh-portal-setting {
      background: #f8fafc !important;
      border: 1px solid #e2e8f0 !important;
      border-radius: 16px !important;
      padding: 16px 20px !important;
      margin-bottom: 12px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      gap: 16px !important;
      box-sizing: border-box !important;
      width: 100% !important;
    }

    .gh-portal-list-detail {
      flex: 1 1 auto !important;
      min-width: 0 !important;
    }

    .gh-portal-list-title,
    .gh-portal-setting-title {
      color: #090b10 !important;
      font-size: 15px !important;
      font-weight: 700 !important;
      margin: 0 0 4px 0 !important;
    }

    .gh-portal-list-desc,
    .gh-portal-setting-desc {
      color: #64748b !important;
      font-size: 13px !important;
      line-height: 1.5 !important;
      margin: 0 !important;
    }

    /* Close Icon */
    .gh-portal-closeicon-container {
      cursor: pointer !important;
      top: 18px !important;
      right: 18px !important;
      position: absolute !important;
      width: 34px !important;
      height: 34px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      z-index: 50 !important;
    }

    .gh-portal-closeicon {
      color: #64748b !important;
      transition: color 0.2s ease !important;
    }

    .gh-portal-closeicon:hover {
      color: #090b10 !important;
    }

    /* Messages & Secondary Links */
    .gh-portal-signup-message,
    .gh-portal-signup-message-row,
    .gh-portal-signin-message,
    .gh-portal-footer,
    p {
      color: #64748b !important;
      font-size: 14px !important;
      text-align: center !important;
    }

    .gh-portal-btn-link {
      color: #090b10 !important;
      font-weight: 700 !important;
      text-decoration: underline !important;
      cursor: pointer !important;
    }

    .gh-portal-btn-link:hover {
      color: #0284c7 !important;
    }

    .gh-portal-btn-site-title-back {
      color: #64748b !important;
      font-size: 13px !important;
      margin-bottom: 12px !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 6px !important;
    }

    .gh-portal-btn-site-title-back:hover {
      color: #090b10 !important;
    }

    /* Watermark Killer */
    .gh-portal-powered,
    #ghost-portal-root .gh-portal-powered {
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
    }

    /* ========================================================================
       MOBILE VIEW FIXES (Light Mode < 640px)
       ======================================================================== */
    @media (max-width: 640px) {
      .gh-portal-popup-wrapper {
        padding: 16px 12px 36px 12px !important;
        align-items: flex-start !important;
      }

      .gh-portal-popup-container,
      .gh-portal-popup-container.account,
      .gh-portal-popup-container.newsletters {
        padding: 24px 18px !important;
        border-radius: 20px !important;
        max-width: 100% !important;
        width: 100% !important;
        margin: 8px auto 24px auto !important;
      }

      .gh-portal-closeicon-container {
        top: 14px !important;
        right: 14px !important;
      }

      /* Account Header on Mobile */
      .gh-portal-account-header {
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
        text-align: center !important;
        gap: 12px !important;
        width: 100% !important;
        margin-bottom: 20px !important;
      }

      .gh-portal-account-data {
        width: 100% !important;
        text-align: center !important;
      }

      .gh-portal-account-name {
        font-size: 18px !important;
        margin-bottom: 2px !important;
        text-align: center !important;
      }

      .gh-portal-account-email {
        font-size: 13px !important;
        word-break: break-all !important;
        text-align: center !important;
      }

      .gh-portal-account-header .gh-portal-btn {
        width: 100% !important;
      }

      /* Newsletter Rows on Mobile */
      .gh-portal-list,
      .gh-portal-setting {
        padding: 14px 14px !important;
        gap: 12px !important;
        width: 100% !important;
      }

      .gh-portal-list-detail {
        min-width: 0 !important;
        flex: 1 1 auto !important;
        max-width: calc(100% - 56px) !important;
      }

      .gh-portal-list-title,
      .gh-portal-setting-title {
        font-size: 14px !important;
        margin-bottom: 2px !important;
        word-break: break-word !important;
      }

      .gh-portal-list-desc,
      .gh-portal-setting-desc {
        font-size: 12px !important;
        line-height: 1.4 !important;
        word-break: break-word !important;
      }

      .gh-portal-for-switch,
      .switch {
        flex-shrink: 0 !important;
        margin-left: auto !important;
      }

      /* Stack Action Footers Vertically on Mobile */
      .gh-portal-action-footer,
      .gh-portal-account-footer {
        display: flex !important;
        flex-direction: column !important;
        width: 100% !important;
        gap: 10px !important;
        margin-top: 20px !important;
      }

      .gh-portal-action-footer .gh-portal-btn,
      .gh-portal-account-footer .gh-portal-btn {
        width: 100% !important;
        height: 44px !important;
      }
    }
  `;

  let isDebounceScheduled = false;

  function scheduleApplyModalThemes() {
    if (isDebounceScheduled) return;
    isDebounceScheduled = true;
    requestAnimationFrame(function() {
      isDebounceScheduled = false;
      applyModalThemes();
    });
  }

  function cleanPinkDOM(doc, isDark) {
    if (!doc) return;
    const accent = isDark ? '#38bdf8' : '#0284c7';
    try {
      const allEls = doc.querySelectorAll('*');
      for (let i = 0; i < allEls.length; i++) {
        const el = allEls[i];
        const s = el.getAttribute('style');
        if (s && (s.includes('240, 37, 116') || s.includes('ff0077') || s.includes('255, 0, 119'))) {
          el.style.setProperty('background-color', accent, 'important');
          el.style.setProperty('border-color', accent, 'important');
        }
      }
    } catch (e) {}
  }

  function injectCSS(iframe, styleId, cssContent, themeName, isDark) {
    try {
      const doc = iframe.contentDocument || iframe.contentWindow.document;
      if (!doc || !doc.head) return;

      let style = doc.getElementById(styleId);
      if (style) {
        if (style.getAttribute('data-applied-theme') !== themeName) {
          style.setAttribute('data-applied-theme', themeName);
          style.textContent = cssContent;
        }
      } else {
        style = doc.createElement('style');
        style.id = styleId;
        style.setAttribute('data-applied-theme', themeName);
        style.textContent = cssContent;
        doc.head.appendChild(style);
      }

      cleanPinkDOM(doc, isDark);

      // Attach local frame observer to clean any freshly rendered pink toggles
      if (!doc._gmObserved) {
        doc._gmObserved = true;
        const frameObs = new MutationObserver(function() {
          cleanPinkDOM(doc, isDark);
        });
        if (doc.body) {
          frameObs.observe(doc.body, { attributes: true, subtree: true, attributeFilter: ['style', 'class'] });
        }
      }
    } catch (e) {}
  }

  function applyModalThemes() {
    const root = document.documentElement;
    const isDark = root.classList.contains('dark-mode') || root.getAttribute('data-theme') === 'dark';
    const isLight = root.classList.contains('light-mode') || root.getAttribute('data-theme') === 'light' || !isDark;
    const themeName = isLight ? 'light' : 'dark';
    const targetPortalCSS = isLight ? lightCSS : darkCSS;

    const portalIframes = Array.from(document.querySelectorAll('iframe')).filter(function(iframe) {
      return iframe.title === 'portal-popup' ||
             iframe.closest('#ghost-portal-root') ||
             (iframe.id && iframe.id.includes('portal')) ||
             (iframe.src && iframe.src.includes('portal'));
    });

    portalIframes.forEach(function(iframe) {
      injectCSS(iframe, 'gm-portal-custom-style', targetPortalCSS, themeName, isDark);
    });
  }

  // 1. Observe addition of portal container
  const observer = new MutationObserver(function(mutations) {
    for (let i = 0; i < mutations.length; i++) {
      const addedNodes = mutations[i].addedNodes;
      for (let j = 0; j < addedNodes.length; j++) {
        const node = addedNodes[j];
        if (node.nodeType === 1 && (node.id === 'ghost-portal-root' || node.tagName === 'IFRAME' || (node.querySelector && node.querySelector('iframe')))) {
          scheduleApplyModalThemes();
          return;
        }
      }
    }
  });

  if (document.body) {
    observer.observe(document.body, { childList: true });
  }

  // 2. Observe theme changes on <html>
  const themeObserver = new MutationObserver(function() {
    scheduleApplyModalThemes();
  });
  themeObserver.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class', 'data-theme']
  });

  // 3. Listen for URL hash changes & clicks
  window.addEventListener('hashchange', function() {
    scheduleApplyModalThemes();
    setTimeout(scheduleApplyModalThemes, 200);
  });

  document.addEventListener('click', function(e) {
    const target = e.target;
    if (target && target.closest && target.closest('[data-portal], a[href*="#/portal"], .gh-portal-trigger, .gm-head-signin-btn')) {
      scheduleApplyModalThemes();
      setTimeout(scheduleApplyModalThemes, 150);
      setTimeout(scheduleApplyModalThemes, 400);
    }
  });

  scheduleApplyModalThemes();
})();

/**
 * Inbuilt Member Avatar Presets (Zero-Storage Local Identity)
 * Features:
 * - 8 High-Contrast Monochrome Vector Operative Avatars (No Text Naming)
 * - Pencil Badge on Profile Avatar to open Selection Modal (Never Cropped)
 * - Saved in localStorage (0 server storage used)
 * - Synchronizes with Comments Form (Active Typing, Reply Forms & Existing Comments)
 * - Deterministic Vector Operative Avatars for all other commenters (Eradicates raw letter circles)
 */
(function() {
    'use strict';

    if (window._gmMemberAvatarsInitialized) return;
    window._gmMemberAvatarsInitialized = true;

    const AVATARS = [
        {
            id: 'sentinel',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#ffffff" stroke-width="2"/><path d="M24 10L36 16V26C36 33 24 38 24 38C24 38 12 33 12 26V16L24 10Z" fill="url(#gradSentinel)" stroke="#ffffff" stroke-width="2"/><circle cx="24" cy="22" r="4" fill="#ffffff"/><path d="M19 28C19 25.5 21.2 24 24 24C26.8 24 29 25.5 29 28" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"/><defs><linearGradient id="gradSentinel" x1="12" y1="10" x2="36" y2="38"><stop stop-color="#334155"/><stop offset="1" stop-color="#0f172a"/></linearGradient></defs></svg>'
        },
        {
            id: 'detective',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#000000" stroke="#e2e8f0" stroke-width="2"/><path d="M14 22C14 22 17 14 24 14C31 14 34 22 34 22L38 23L36 25H12L10 23L14 22Z" fill="#334155"/><rect x="17" y="27" width="14" height="4" rx="2" fill="#cbd5e1"/><circle cx="20" cy="23" r="2" fill="#000000"/><circle cx="28" cy="23" r="2" fill="#000000"/><path d="M20 34C20 31.8 21.8 30 24 30C26.2 30 28 31.8 28 34" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/></svg>'
        },
        {
            id: 'operative',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#ffffff" stroke-width="2"/><path d="M16 20C16 15.6 19.6 12 24 12C28.4 12 32 15.6 32 20V26C32 29 29.5 31 24 31C18.5 31 16 29 16 26V20Z" fill="#1e293b"/><rect x="18" y="21" width="12" height="4" rx="2" fill="#ffffff"/><path d="M14 36C14 32.7 18.5 31 24 31C29.5 31 34 32.7 34 36" stroke="#cbd5e1" stroke-width="2"/></svg>'
        },
        {
            id: 'guardian',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#000000" stroke="#ffffff" stroke-width="2"/><polygon points="16,15 20,24 12,25" fill="#475569"/><polygon points="32,15 28,24 36,25" fill="#475569"/><path d="M16 24L24 18L32 24L30 33L24 37L18 33L16 24Z" fill="#1e293b" stroke="#ffffff" stroke-width="1.5"/><circle cx="20" cy="26" r="2" fill="#ffffff"/><circle cx="28" cy="26" r="2" fill="#ffffff"/></svg>'
        },
        {
            id: 'vector',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#94a3b8" stroke-width="2"/><path d="M24 10C24 10 27 16 27 20C27 24 24 26 24 26C24 26 21 24 21 20C21 16 24 10 24 10Z" fill="#ffffff"/><path d="M13 22C18 20 23 23 23 23C23 23 17 26 14 31C13 27 12 24 13 22Z" fill="#475569"/><path d="M35 22C30 20 25 23 25 23C25 23 31 26 34 31C35 27 36 24 35 22Z" fill="#475569"/><circle cx="24" cy="32" r="3" fill="#ffffff"/></svg>'
        },
        {
            id: 'wolf',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#cbd5e1" stroke-width="2"/><polygon points="17,14 21,22 14,24" fill="#475569"/><polygon points="31,14 27,22 34,24" fill="#475569"/><path d="M17 23L24 17L31 23L29 32L24 38L19 32L17 23Z" fill="#1e293b" stroke="#ffffff" stroke-width="1.5"/><circle cx="21" cy="25" r="2" fill="#ffffff"/><circle cx="27" cy="25" r="2" fill="#ffffff"/></svg>'
        },
        {
            id: 'aegis',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#000000" stroke="#cbd5e1" stroke-width="2"/><path d="M24 12L34 17V26C34 32 24 37 24 37C24 37 14 32 14 26V17L24 12Z" fill="#334155" stroke="#e2e8f0" stroke-width="2"/><path d="M24 16V33" stroke="#e2e8f0" stroke-width="2"/><path d="M18 24H30" stroke="#e2e8f0" stroke-width="2"/></svg>'
        },
        {
            id: 'cipher',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#ffffff" stroke-width="2"/><rect x="16" y="16" width="16" height="16" rx="4" fill="#1e293b" stroke="#ffffff" stroke-width="2"/><circle cx="24" cy="24" r="4" fill="#ffffff"/><line x1="24" y1="11" x2="24" y2="16" stroke="#ffffff" stroke-width="2"/><line x1="24" y1="32" x2="24" y2="37" stroke="#ffffff" stroke-width="2"/><line x1="11" y1="24" x2="16" y2="24" stroke="#ffffff" stroke-width="2"/><line x1="32" y1="24" x2="37" y2="24" stroke="#ffffff" stroke-width="2"/></svg>'
        }
    ];

    window.gmMemberAvatars = AVATARS;

    function getSelectedAvatarId() {
        try {
            return localStorage.getItem('gm_member_avatar_id') || 'sentinel';
        } catch (e) {
            return 'sentinel';
        }
    }

    function setSelectedAvatarId(id) {
        try {
            localStorage.setItem('gm_member_avatar_id', id);
        } catch (e) {}
    }

    function getSelectedAvatarSvg(id) {
        const targetId = id || getSelectedAvatarId();
        const item = AVATARS.find(a => a.id === targetId) || AVATARS[0];
        return item.svg;
    }
    window.gmGetSelectedAvatarSvg = getSelectedAvatarSvg;

    function getAvatarForName(name) {
        if (!name || typeof name !== 'string') return AVATARS[0];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = ((hash << 5) - hash) + name.charCodeAt(i);
            hash |= 0;
        }
        const index = Math.abs(hash) % AVATARS.length;
        return AVATARS[index];
    }
    window.gmGetAvatarForName = getAvatarForName;

    function renderAvatarElement(svgStr) {
        return '<div class="gm-comment-avatar-svg" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;border-radius:50%;overflow:hidden;background:transparent;">' + svgStr + '</div>';
    }

    function syncCommentsAvatar(avatarId) {
        const currentId = avatarId || getSelectedAvatarId();
        const userAvatar = AVATARS.find(a => a.id === currentId) || AVATARS[0];

        const frames = document.querySelectorAll(
            '#ghost-comments-root iframe, ' +
            'iframe[title="comments-frame"], ' +
            'iframe[title="deleteComment"], ' +
            'iframe[title*="Comment"], ' +
            'iframe[title*="comment"]'
        );
        frames.forEach(frame => {
            try {
                const doc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
                if (!doc || !doc.body) return;

                // 1. Detect current logged-in user name
                let currentUserName = (window.gmCurrentMember && window.gmCurrentMember.name) || '';
                if (!currentUserName) {
                    const formNameEl = doc.querySelector('[data-testid="main-form"] [data-testid="member-name"], [data-testid="main-form"] .font-semibold');
                    if (formNameEl && formNameEl.textContent.trim()) {
                        currentUserName = formNameEl.textContent.trim();
                        try { localStorage.setItem('gm_member_name', currentUserName); } catch(e) {}
                    } else {
                        try { currentUserName = localStorage.getItem('gm_member_name') || ''; } catch(e) {}
                    }
                }

                // 2. Sync Form Figures (Active Typing user in main-form, reply-forms)
                const formFigures = doc.querySelectorAll(
                    '[data-testid="main-form"] figure, ' +
                    '[data-testid="reply-form"] figure, ' +
                    'form figure'
                );

                formFigures.forEach(fig => {
                    if (fig.getAttribute('data-gm-avatar-id') === currentId && fig.querySelector('.gm-comment-avatar-svg')) return;
                    fig.setAttribute('data-gm-avatar-id', currentId);
                    fig.style.overflow = 'hidden';
                    fig.style.borderRadius = '50%';
                    fig.style.background = 'transparent';
                    fig.innerHTML = renderAvatarElement(userAvatar.svg);
                });

                // 3. Sync Comments Thread Figures (Eradicate letter initials on all comments)
                const commentFigures = doc.querySelectorAll(
                    'figure[data-testid="avatar"]:not([data-testid="main-form"] figure):not([data-testid="reply-form"] figure), ' +
                    'figure[data-testid="blank-avatar"]:not([data-testid="main-form"] figure):not([data-testid="reply-form"] figure)'
                );

                commentFigures.forEach(fig => {
                    // Check if custom uploaded image exists
                    const hasPhoto = fig.querySelector('img[data-testid="avatar-image"]');
                    if (hasPhoto && hasPhoto.getAttribute('src')) return;

                    // Find comment wrapper
                    const commentCard = fig.closest('[data-testid="comment-component"], div[id^="ghost-comment-"], article, div[class*="comment"]') || fig.parentElement;
                    let authorName = '';
                    if (commentCard) {
                        const nameEl = commentCard.querySelector('[data-testid="member-name"], .font-semibold, h4, [class*="font-semibold"]');
                        if (nameEl && nameEl.textContent.trim()) {
                            authorName = nameEl.textContent.trim();
                        }
                    }

                    // Determine if this is the current user's comment
                    const isCurrentUser = (currentUserName && authorName && currentUserName.toLowerCase() === authorName.toLowerCase()) ||
                                          (commentCard && commentCard.querySelector('button[data-testid="delete-popup-confirm"], [data-testid="more-options-popup"]'));

                    const targetItem = isCurrentUser ? userAvatar : getAvatarForName(authorName);
                    const appliedKey = targetItem.id + '_' + (isCurrentUser ? 'me' : authorName);

                    if (fig.getAttribute('data-gm-applied') === appliedKey && fig.querySelector('.gm-comment-avatar-svg')) return;

                    fig.setAttribute('data-gm-applied', appliedKey);
                    fig.style.overflow = 'hidden';
                    fig.style.borderRadius = '50%';
                    fig.style.background = 'transparent';
                    fig.innerHTML = renderAvatarElement(targetItem.svg);
                });

                // 4. MutationObserver & event hooks for dynamic typing
                if (!doc._gmObserverAttached) {
                    doc._gmObserverAttached = true;

                    // Re-sync immediately on typing / focus / click
                    doc.addEventListener('input', function(e) {
                        const formFig = doc.querySelector('[data-testid="main-form"] figure, [data-testid="reply-form"] figure');
                        if (formFig && (!formFig.querySelector('.gm-comment-avatar-svg') || formFig.getAttribute('data-gm-avatar-id') !== currentId)) {
                            formFig.setAttribute('data-gm-avatar-id', currentId);
                            formFig.style.overflow = 'hidden';
                            formFig.style.borderRadius = '50%';
                            formFig.style.background = 'transparent';
                            formFig.innerHTML = renderAvatarElement(userAvatar.svg);
                        }
                    }, true);

                    doc.addEventListener('focusin', function() {
                        setTimeout(() => syncCommentsAvatar(getSelectedAvatarId()), 40);
                    }, true);

                    doc.addEventListener('click', function() {
                        setTimeout(() => syncCommentsAvatar(getSelectedAvatarId()), 60);
                    }, true);

                    const observer = new MutationObserver(function() {
                        if (doc._gmSyncTimeout) clearTimeout(doc._gmSyncTimeout);
                        doc._gmSyncTimeout = setTimeout(function() {
                            syncCommentsAvatar(getSelectedAvatarId());
                        }, 50);
                    });

                    observer.observe(doc.body, { childList: true, subtree: true });
                }
            } catch (e) {}
        });
    }
    window.gmSyncCommentsAvatar = syncCommentsAvatar;

    function applyAvatarEverywhere(avatarId) {
        const currentId = avatarId || getSelectedAvatarId();
        const item = AVATARS.find(a => a.id === currentId) || AVATARS[0];

        // 1. Update account page profile avatar
        const display = document.getElementById('gmCurrentAvatarDisplay');
        if (display) {
            display.innerHTML = '<div class="gm-account-avatar-svg">' + item.svg + '</div>';
        }

        // Also update any fallback wraps
        const avatarWraps = document.querySelectorAll('.gm-account-avatar-wrap .gm-account-avatar-placeholder');
        avatarWraps.forEach(wrap => {
            wrap.innerHTML = '<div class="gm-account-avatar-svg">' + item.svg + '</div>';
        });

        // 2. Update mini avatar in top bar header
        const accountBtns = document.querySelectorAll('.gm-head-account-btn');
        accountBtns.forEach(btn => {
            let mini = btn.querySelector('.gm-head-avatar-mini');
            if (!mini) {
                mini = document.createElement('span');
                mini.className = 'gm-head-avatar-mini';
                btn.prepend(mini);
            }
            mini.innerHTML = item.svg;
        });

        // 3. Mark selected in modal grid
        const options = document.querySelectorAll('.gm-avatar-option');
        options.forEach(opt => {
            if (opt.getAttribute('data-avatar-id') === currentId) {
                opt.classList.add('is-selected');
                opt.setAttribute('aria-selected', 'true');
            } else {
                opt.classList.remove('is-selected');
                opt.setAttribute('aria-selected', 'false');
            }
        });

        // 4. Synchronize with comments input form avatar and comment list
        syncCommentsAvatar(currentId);
    }

    function openAvatarModal() {
        const modal = document.getElementById('gmAvatarModal');
        if (modal) {
            modal.classList.add('is-open');
            document.body.classList.add('gm-modal-active');
        }
    }

    function closeAvatarModal() {
        const modal = document.getElementById('gmAvatarModal');
        if (modal) {
            modal.classList.remove('is-open');
            document.body.classList.remove('gm-modal-active');
        }
    }

    function initAvatarPicker() {
        const grid = document.getElementById('gmAvatarModalGrid');
        if (grid) {
            grid.innerHTML = '';
            const currentId = getSelectedAvatarId();

            AVATARS.forEach(av => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'gm-avatar-option' + (av.id === currentId ? ' is-selected' : '');
                btn.setAttribute('data-avatar-id', av.id);
                btn.innerHTML = '<div class="gm-avatar-option-preview">' + av.svg + '</div>' +
                                '<span class="gm-avatar-check-badge">✓</span>';

                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    setSelectedAvatarId(av.id);
                    applyAvatarEverywhere(av.id);
                    setTimeout(closeAvatarModal, 150);
                });

                grid.appendChild(btn);
            });

            const pencilBtn = document.getElementById('gmAvatarPencilBtn');
            const trigger = document.getElementById('gmAvatarTrigger');
            const closeBtn = document.getElementById('gmAvatarModalClose');
            const backdrop = document.getElementById('gmAvatarModalBackdrop');

            if (pencilBtn) {
                pencilBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    openAvatarModal();
                });
            }

            if (trigger) {
                trigger.addEventListener('click', function() {
                    openAvatarModal();
                });
            }

            if (closeBtn) closeBtn.addEventListener('click', closeAvatarModal);
            if (backdrop) backdrop.addEventListener('click', closeAvatarModal);

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') closeAvatarModal();
            });
        }

        // Apply saved or default avatar everywhere on load
        applyAvatarEverywhere(getSelectedAvatarId());

        // Periodic check to keep comments in sync when comments iframe loads asynchronously
        let syncCount = 0;
        const syncInterval = setInterval(function() {
            syncCount++;
            syncCommentsAvatar();
            if (syncCount > 15) clearInterval(syncInterval);
        }, 1000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAvatarPicker);
    } else {
        initAvatarPicker();
    }
})();

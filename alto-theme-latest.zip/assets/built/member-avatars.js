/**
 * Inbuilt Member Avatar Presets (Zero-Storage Local Identity)
 * Features:
 * - 8 High-Contrast Vector Operative Avatars (No Text Naming)
 * - Pencil Badge on Profile Avatar to open Selection Modal
 * - Saved in localStorage (0 server storage used)
 */
(function() {
    const AVATARS = [
        {
            id: 'sentinel',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#00f2fe" stroke-width="2"/><path d="M24 10L36 16V26C36 33 24 38 24 38C24 38 12 33 12 26V16L24 10Z" fill="url(#gradSentinel)" stroke="#38bdf8" stroke-width="2"/><circle cx="24" cy="22" r="4" fill="#ffffff"/><path d="M19 28C19 25.5 21.2 24 24 24C26.8 24 29 25.5 29 28" stroke="#38bdf8" stroke-width="2" stroke-linecap="round"/><defs><linearGradient id="gradSentinel" x1="12" y1="10" x2="36" y2="38"><stop stop-color="#0284c7"/><stop offset="1" stop-color="#0369a1"/></linearGradient></defs></svg>'
        },
        {
            id: 'detective',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#13110a" stroke="#f59e0b" stroke-width="2"/><path d="M14 22C14 22 17 14 24 14C31 14 34 22 34 22L38 23L36 25H12L10 23L14 22Z" fill="#f59e0b"/><rect x="17" y="27" width="14" height="4" rx="2" fill="#fbbf24"/><circle cx="20" cy="23" r="2" fill="#13110a"/><circle cx="28" cy="23" r="2" fill="#13110a"/><path d="M20 34C20 31.8 21.8 30 24 30C26.2 30 28 31.8 28 34" stroke="#fbbf24" stroke-width="2" stroke-linecap="round"/></svg>'
        },
        {
            id: 'operative',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#140c1e" stroke="#c084fc" stroke-width="2"/><path d="M16 20C16 15.6 19.6 12 24 12C28.4 12 32 15.6 32 20V26C32 29 29.5 31 24 31C18.5 31 16 29 16 26V20Z" fill="#a855f7"/><rect x="18" y="21" width="12" height="4" rx="2" fill="#f3e8ff"/><path d="M14 36C14 32.7 18.5 31 24 31C29.5 31 34 32.7 34 36" stroke="#c084fc" stroke-width="2"/></svg>'
        },
        {
            id: 'panther',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#071912" stroke="#34d399" stroke-width="2"/><polygon points="16,15 20,24 12,25" fill="#10b981"/><polygon points="32,15 28,24 36,25" fill="#10b981"/><path d="M16 24L24 18L32 24L30 33L24 37L18 33L16 24Z" fill="#047857" stroke="#34d399" stroke-width="1.5"/><circle cx="20" cy="26" r="2" fill="#6ee7b7"/><circle cx="28" cy="26" r="2" fill="#6ee7b7"/></svg>'
        },
        {
            id: 'phoenix',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#1c0a0a" stroke="#f87171" stroke-width="2"/><path d="M24 10C24 10 27 16 27 20C27 24 24 26 24 26C24 26 21 24 21 20C21 16 24 10 24 10Z" fill="#f87171"/><path d="M13 22C18 20 23 23 23 23C23 23 17 26 14 31C13 27 12 24 13 22Z" fill="#ef4444"/><path d="M35 22C30 20 25 23 25 23C25 23 31 26 34 31C35 27 36 24 35 22Z" fill="#ef4444"/><circle cx="24" cy="32" r="3" fill="#fef08a"/></svg>'
        },
        {
            id: 'wolf',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#0a1224" stroke="#60a5fa" stroke-width="2"/><polygon points="17,14 21,22 14,24" fill="#3b82f6"/><polygon points="31,14 27,22 34,24" fill="#3b82f6"/><path d="M17 23L24 17L31 23L29 32L24 38L19 32L17 23Z" fill="#1d4ed8" stroke="#93c5fd" stroke-width="1.5"/><circle cx="21" cy="25" r="2" fill="#bfdbfe"/><circle cx="27" cy="25" r="2" fill="#bfdbfe"/></svg>'
        },
        {
            id: 'aegis',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#0f172a" stroke="#cbd5e1" stroke-width="2"/><path d="M24 12L34 17V26C34 32 24 37 24 37C24 37 14 32 14 26V17L24 12Z" fill="#334155" stroke="#e2e8f0" stroke-width="2"/><path d="M24 16V33" stroke="#e2e8f0" stroke-width="2"/><path d="M18 24H30" stroke="#e2e8f0" stroke-width="2"/></svg>'
        },
        {
            id: 'matrix',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#02140e" stroke="#34d399" stroke-width="2"/><rect x="16" y="16" width="16" height="16" rx="4" fill="#065f46" stroke="#6ee7b7" stroke-width="2"/><circle cx="24" cy="24" r="4" fill="#34d399"/><line x1="24" y1="11" x2="24" y2="16" stroke="#34d399" stroke-width="2"/><line x1="24" y1="32" x2="24" y2="37" stroke="#34d399" stroke-width="2"/><line x1="11" y1="24" x2="16" y2="24" stroke="#34d399" stroke-width="2"/><line x1="32" y1="24" x2="37" y2="24" stroke="#34d399" stroke-width="2"/></svg>'
        }
    ];

    function getSelectedAvatarId() {
        try {
            return localStorage.getItem('gm_member_avatar_id') || 'sentinel';
        } catch (e) {
            return 'sentinel';
        }
    }

    function setSelectedAvatarId(id) {
        try {
            localStorage.setItem('gm_member_avatar_id', id);
        } catch (e) {}
    }

    function applyAvatarEverywhere(avatarId) {
        const item = AVATARS.find(a => a.id === avatarId) || AVATARS[0];
        
        // 1. Update account page profile avatar
        const display = document.getElementById('gmCurrentAvatarDisplay');
        if (display) {
            display.innerHTML = `<div class="gm-account-avatar-svg">${item.svg}</div>`;
        }

        // Also update any fallback wraps
        const avatarWraps = document.querySelectorAll('.gm-account-avatar-wrap .gm-account-avatar-placeholder');
        avatarWraps.forEach(wrap => {
            wrap.innerHTML = `<div class="gm-account-avatar-svg">${item.svg}</div>`;
        });

        // 2. Update mini avatar in top bar header
        const accountBtns = document.querySelectorAll('.gm-head-account-btn');
        accountBtns.forEach(btn => {
            let mini = btn.querySelector('.gm-head-avatar-mini');
            if (!mini) {
                mini = document.createElement('span');
                mini.className = 'gm-head-avatar-mini';
                btn.prepend(mini);
            }
            mini.innerHTML = item.svg;
        });

        // 3. Mark selected in modal grid
        const options = document.querySelectorAll('.gm-avatar-option');
        options.forEach(opt => {
            if (opt.getAttribute('data-avatar-id') === avatarId) {
                opt.classList.add('is-selected');
                opt.setAttribute('aria-selected', 'true');
            } else {
                opt.classList.remove('is-selected');
                opt.setAttribute('aria-selected', 'false');
            }
        });
    }

    function openAvatarModal() {
        const modal = document.getElementById('gmAvatarModal');
        if (modal) {
            modal.classList.add('is-open');
            document.body.classList.add('gm-modal-active');
        }
    }

    function closeAvatarModal() {
        const modal = document.getElementById('gmAvatarModal');
        if (modal) {
            modal.classList.remove('is-open');
            document.body.classList.remove('gm-modal-active');
        }
    }

    function initAvatarPicker() {
        const grid = document.getElementById('gmAvatarModalGrid');
        if (!grid) return;

        grid.innerHTML = '';
        const currentId = getSelectedAvatarId();

        AVATARS.forEach(av => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'gm-avatar-option' + (av.id === currentId ? ' is-selected' : '');
            btn.setAttribute('data-avatar-id', av.id);
            // Pure visual avatar - NO text naming as requested
            btn.innerHTML = `
                <div class="gm-avatar-option-preview">${av.svg}</div>
                <span class="gm-avatar-check-badge">✓</span>
            `;

            btn.addEventListener('click', function(e) {
                e.preventDefault();
                setSelectedAvatarId(av.id);
                applyAvatarEverywhere(av.id);
                setTimeout(closeAvatarModal, 150);
            });

            grid.appendChild(btn);
        });

        // Wire triggers
        const trigger = document.getElementById('gmAvatarTrigger');
        const pencil = document.getElementById('gmAvatarPencilBtn');
        const closeBtn = document.getElementById('gmAvatarModalClose');
        const backdrop = document.getElementById('gmAvatarModalBackdrop');

        if (trigger) trigger.addEventListener('click', openAvatarModal);
        if (pencil) {
            pencil.addEventListener('click', function(e) {
                e.stopPropagation();
                openAvatarModal();
            });
        }
        if (closeBtn) closeBtn.addEventListener('click', closeAvatarModal);
        if (backdrop) backdrop.addEventListener('click', closeAvatarModal);

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closeAvatarModal();
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        const currentId = getSelectedAvatarId();
        applyAvatarEverywhere(currentId);
        initAvatarPicker();
    });

    window.GMAvatars = {
        list: AVATARS,
        get: getSelectedAvatarId,
        set: setSelectedAvatarId,
        apply: applyAvatarEverywhere,
        open: openAvatarModal,
        close: closeAvatarModal
    };
})();

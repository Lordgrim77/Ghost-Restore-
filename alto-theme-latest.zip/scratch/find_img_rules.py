with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\screen.css', 'r', encoding='utf-8') as f:
    text = f.read()

import re
rules = re.findall(r'([^{}]+)\{([^}]+)\}', text)
for sel, body in rules:
    if sel.strip() == 'img' or '.gh-content img' in sel:
        print(f"{sel.strip()} {{ {body.strip()} }}")


with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_css.txt', 'r', encoding='utf-8') as f:
    text = f.read()

import re
rules = re.findall(r'([^{}]+)\{([^}]+)\}', text)
for sel, body in rules:
    if 'bookmark' in sel:
        print(f"{sel.strip()} {{ {body.strip()} }}")


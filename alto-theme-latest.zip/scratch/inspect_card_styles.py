import re

with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\screen.css', 'r', encoding='utf-8') as f:
    screen_css = f.read()

with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\glassmorphism.css', 'r', encoding='utf-8') as f:
    gm_css = f.read()

cards = [
    'kg-card', 'kg-embed-card', 'kg-image-card', 'kg-gallery-card', 'kg-bookmark-card',
    'kg-callout-card', 'kg-toggle-card', 'kg-product-card', 'kg-header-card',
    'kg-audio-card', 'kg-video-card', 'kg-file-card', 'kg-button-card', 'kg-width-wide',
    'kg-width-full', 'js-reframe'
]

for card in cards:
    print(f"\n==================== {card} ====================")
    # in screen_css
    m1 = re.findall(rf'([^{{}}]*{card}[^{{}}]*\{{[^}}]+\}})', screen_css)
    print(f"screen.css ({len(m1)} matches):")
    for r in m1[:3]:
        print(" ", " ".join(r.split())[:160])
    
    # in gm_css
    m2 = re.findall(rf'([^{{}}]*{card}[^{{}}]*\{{[^}}]+\}})', gm_css)
    print(f"glassmorphism.css ({len(m2)} matches):")
    for r in m2[:3]:
        print(" ", " ".join(r.split())[:160])


import urllib.request
import re

url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/'
with urllib.request.urlopen(url) as res:
    html = res.read().decode('utf-8')

scripts = re.findall(r'<script\b[^>]*>(.*?)</script>', html, re.DOTALL)
print(f"Total script tags: {len(scripts)}")
for i, s in enumerate(scripts):
    m = re.search(r'<script\b([^>]*)>', html)
    print(f"--- SCRIPT {i+1} ---")
    print(s[:300].strip())
    print("...")

# Also find external script tags src attributes
srcs = re.findall(r'<script\b[^>]*src=[\"\']([^\"\']+)[\"\']', html)
print("\nExternal Script SRCs:")
for src in srcs:
    print(" -", src)


const { spawn } = require('child_process');
const fs = require('fs');

async function testDisneyPost() {
  const url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/';
  
  // Desktop
  let chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9257',
    '--window-size=1280,2400',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  let list = await (await fetch('http://127.0.0.1:9257/json')).json();
  let page = list.find(t => t.type === 'page');
  let ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (wsInstance, method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        wsInstance.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    wsInstance.addEventListener('message', handler);
    wsInstance.send(JSON.stringify({ id, method, params }));
  });

  await new Promise((resolve) => {
    ws.onopen = async () => {
      await send(ws, 'Runtime.enable');
      await new Promise(r => setTimeout(r, 1500));

      const res = await send(ws, 'Runtime.evaluate', {
        expression: `(() => {
          const content = document.querySelector('.gh-content');
          const items = Array.from(content.children).map((el, i) => {
            const rect = el.getBoundingClientRect();
            return {
              i,
              tag: el.tagName,
              cls: el.className,
              rect: { top: Math.round(rect.top), bottom: Math.round(rect.bottom), height: Math.round(rect.height), width: Math.round(rect.width) },
              text: (el.textContent || '').slice(0, 40)
            };
          });
          return {
            scrollWidth: document.documentElement.scrollWidth,
            clientWidth: document.documentElement.clientWidth,
            items
          };
        })()`,
        returnByValue: true
      });

      console.log('Disney Post Desktop:', JSON.stringify(res.result.value, null, 2));

      const shot = await send(ws, 'Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/post-disney-verified-desktop.png', Buffer.from(shot.data, 'base64'));
      console.log('Saved post-disney-verified-desktop.png');

      chrome.kill();
      resolve();
    };
  });

  // Mobile
  chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9258',
    '--window-size=375,1800',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  list = await (await fetch('http://127.0.0.1:9258/json')).json();
  page = list.find(t => t.type === 'page');
  ws = new WebSocket(page.webSocketDebuggerUrl);

  await new Promise((resolve) => {
    ws.onopen = async () => {
      await send(ws, 'Runtime.enable');
      await new Promise(r => setTimeout(r, 1500));

      const res = await send(ws, 'Runtime.evaluate', {
        expression: `(() => ({
          scrollWidth: document.documentElement.scrollWidth,
          clientWidth: document.documentElement.clientWidth
        }))()`,
        returnByValue: true
      });

      console.log('Disney Post Mobile:', JSON.stringify(res.result.value, null, 2));

      const shot = await send(ws, 'Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/post-disney-verified-mobile.png', Buffer.from(shot.data, 'base64'));
      console.log('Saved post-disney-verified-mobile.png');

      chrome.kill();
      resolve();
    };
  });
}

testDisneyPost().catch(e => { console.error(e); process.exit(1); });


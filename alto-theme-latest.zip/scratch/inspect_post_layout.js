const { spawn } = require('child_process');
const fs = require('fs');

async function inspectPostPage() {
  const url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/';
  const chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9252',
    '--window-size=1200,1600',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  const list = await (await fetch('http://127.0.0.1:9252/json')).json();
  const page = list.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        ws.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id, method, params }));
  });

  ws.onopen = async () => {
    // Enable Runtime & Console
    await send('Console.enable');
    await send('Runtime.enable');

    // Wait a bit for images & scripts
    await new Promise(r => setTimeout(r, 1000));

    // Evaluate content elements and their layout metrics
    const evalRes = await send('Runtime.evaluate', {
      expression: `(() => {
        const content = document.querySelector('.gh-content');
        if (!content) return { error: 'No .gh-content' };
        
        const children = Array.from(content.children);
        const metrics = children.map((el, i) => {
          const rect = el.getBoundingClientRect();
          const comp = window.getComputedStyle(el);
          return {
            index: i,
            tag: el.tagName,
            className: el.className,
            textSnippet: (el.textContent || '').trim().slice(0, 50),
            rect: { top: rect.top, bottom: rect.bottom, height: rect.height, width: rect.width },
            display: comp.display,
            visibility: comp.visibility,
            opacity: comp.opacity,
            overflow: comp.overflow,
            position: comp.position,
            gridColumn: comp.gridColumn
          };
        });

        // Check if any element has 0 height or overlap
        const overlaps = [];
        for (let i = 0; i < metrics.length - 1; i++) {
          const cur = metrics[i];
          const next = metrics[i+1];
          if (cur.rect.height > 0 && next.rect.top < cur.rect.bottom - 5) {
            overlaps.push({ curIndex: i, nextIndex: i+1, curBottom: cur.rect.bottom, nextTop: next.rect.top });
          }
        }

        return {
          totalChildren: children.length,
          contentRect: content.getBoundingClientRect(),
          metrics,
          overlaps
        };
      })()`,
      returnByValue: true
    });

    console.log('--- POST PAGE METRICS ---');
    console.log(JSON.stringify(evalRes.result.value, null, 2));

    // Capture screenshot
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/post-disney-initial.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved post-disney-initial.png');

    chrome.kill();
    process.exit(0);
  };
}

inspectPostPage().catch(err => {
  console.error(err);
  process.exit(1);
});


import urllib.request
import re

try:
    with urllib.request.urlopen('http://localhost:2368/posts/') as res:
        html = res.read().decode('utf-8')
except Exception as e:
    with urllib.request.urlopen('http://localhost:2368/') as res:
        html = res.read().decode('utf-8')

links = re.findall(r'href="([^"]+)"', html)
posts = []
for l in links:
    if l.startswith('http://localhost:2368/'):
        l = l.replace('http://localhost:2368', '')
    if l.startswith('/') and not any(l.startswith(x) for x in ['/tag/', '/author/', '/page/', '/about/', '/contact/', '/posts/', '/account/', '/support/', '/assets/', '#', '/favicon']):
        if l != '/' and l != '/ghost/':
            posts.append(l)

print("Posts found:", sorted(list(set(posts))))


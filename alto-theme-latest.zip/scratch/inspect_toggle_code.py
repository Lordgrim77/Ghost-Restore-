with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_full.txt', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('kg-toggle-heading')
print(text[max(0, idx-100):min(len(text), idx+600)])


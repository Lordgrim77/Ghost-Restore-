import urllib.request

url = 'http://localhost:2368/public/cards.min.js'
with urllib.request.urlopen(url) as res:
    code = res.read().decode('utf-8')

print("cards.min.js length:", len(code))
print(code[:2000])


import sqlite3
import re

conn = sqlite3.connect(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\data\ghost-local.db')
c = conn.cursor()
h = c.execute("SELECT html FROM posts WHERE slug='fbi-seizes-virtualine-domain-over-alleged-criminal-hosting-and-bitcoin-money-laundering'").fetchone()[0]
conn.close()

tags = re.findall(r'<([a-zA-Z0-9]+)\b[^>]*class=[\"\']([^\"\']+)[\"\']', h)
print("Tags with classes:", set(tags))
figures = re.findall(r'<figure\b[^>]*>.*?</figure>', h, re.DOTALL)
print("Figures count:", len(figures))
for f in figures:
    print(f[:300])
    print("---")


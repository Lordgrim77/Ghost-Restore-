import sqlite3

conn = sqlite3.connect(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\data\ghost-local.db')
c = conn.cursor()
c.execute("UPDATE settings SET value='#ffffff' WHERE key='accent_color'")
conn.commit()
print("Updated local db accent_color to #ffffff")
conn.close()


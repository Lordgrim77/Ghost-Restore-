css_to_add = """
/* ==========================================================================
   POST CONTENT & KOENIG CARDS ANTI-GLITCH & LAYOUT DEFENSE
   Prevents layout clipping, CSS Grid blowouts, zero-height collapses,
   and visual disappearance across all Koenig blocks and embeds.
   ========================================================================== */

/* 1. CSS Grid Containment on Canvas & Content */
.gh-canvas {
  --main: min(var(--content-width, 720px), 100% - var(--gap, 2rem) * 2);
  --wide: minmax(0, calc(.5 * (var(--container-width, 1200px) - var(--content-width, 720px))));
  --full: minmax(var(--gap, 2rem), 1fr);
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
}

/* Crucial: min-width: 0 prevents grid items from refusing to shrink and blowing out tracks */
.gh-canvas > *,
.gh-content > * {
  min-width: 0 !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  word-break: break-word !important;
  overflow-wrap: break-word !important;
}

.gh-content {
  width: 100% !important;
  max-width: 100% !important;
  box-sizing: border-box !important;
  contain: none !important;
  content-visibility: visible !important;
}

/* Wide and Full Width Content Tracks */
.gh-canvas > .kg-width-wide,
.gh-content > .kg-width-wide {
  grid-column: wide !important;
  max-width: 100% !important;
  min-width: 0 !important;
}

.gh-canvas > .kg-width-full,
.gh-content > .kg-width-full {
  grid-column: full !important;
  width: 100% !important;
  max-width: 100% !important;
  min-width: 0 !important;
}

/* 2. Universal Media & Embed Safe Bounds */
.gh-content img,
.gh-content video,
.gh-content audio,
.gh-content iframe,
.gh-content figure,
.gh-content object,
.gh-content embed {
  max-width: 100% !important;
  box-sizing: border-box !important;
}

.gh-content img {
  height: auto !important;
  display: block;
}

/* 3. Koenig Card Generic Wrappers */
.kg-card {
  width: 100% !important;
  max-width: 100% !important;
  margin-top: 2.5em !important;
  margin-bottom: 2.5em !important;
  box-sizing: border-box !important;
  position: relative !important;
  min-width: 0 !important;
}

/* 4. Koenig Embed Cards & Iframes (Zero-Height Collapse Fix) */
.kg-embed-card {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  width: 100% !important;
  max-width: 100% !important;
  position: relative !important;
  min-height: 120px !important;
  margin: 2.5em 0 !important;
  overflow: visible !important;
}

.kg-embed-card iframe,
.gh-content iframe {
  width: 100% !important;
  max-width: 100% !important;
  aspect-ratio: 16 / 9;
  border: none !important;
  border-radius: 14px !important;
  display: block !important;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35) !important;
}

/* Reframe wrapper defense: never allow 0px height */
.kg-embed-card .js-reframe,
.gh-content .js-reframe {
  position: relative !important;
  width: 100% !important;
  max-width: 100% !important;
  min-height: 220px !important;
  border-radius: 14px !important;
  overflow: hidden !important;
}

.kg-embed-card .js-reframe iframe,
.gh-content .js-reframe iframe {
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  width: 100% !important;
  height: 100% !important;
}

/* Twitter / X & Social Embeds */
.kg-embed-card .twitter-tweet,
.kg-embed-card blockquote.twitter-tweet {
  margin: 1.5em auto !important;
  max-width: 550px !important;
  width: 100% !important;
}

/* 5. Koenig Gallery Cards (Aspect Ratio & Height Fix) */
.kg-gallery-card {
  width: 100% !important;
  max-width: 100% !important;
  margin: 2.5em 0 !important;
}

.kg-gallery-container {
  display: flex !important;
  flex-direction: column !important;
  gap: 14px !important;
  width: 100% !important;
  position: relative !important;
}

.kg-gallery-row {
  display: flex !important;
  flex-direction: row !important;
  gap: 14px !important;
  width: 100% !important;
  align-items: stretch !important;
}

.kg-gallery-image {
  flex: 1 1 0% !important;
  min-width: 0 !important;
  position: relative !important;
  overflow: hidden !important;
  border-radius: 12px !important;
  background: rgba(255, 255, 255, 0.04) !important;
}

.kg-gallery-image img {
  width: 100% !important;
  height: 100% !important;
  min-height: 160px !important;
  max-height: 520px !important;
  object-fit: cover !important;
  display: block !important;
  border-radius: 12px !important;
  transition: transform 0.3s ease !important;
}

.kg-gallery-image img:hover {
  transform: scale(1.02);
}

/* 6. Koenig Bookmark Cards (Obsidian Glass & Mobile Stacking) */
.kg-bookmark-card {
  width: 100% !important;
  margin: 2.5em 0 !important;
}

.kg-bookmark-card a.kg-bookmark-container,
.dark-mode .kg-bookmark-card a.kg-bookmark-container {
  display: flex !important;
  flex-direction: row !important;
  width: 100% !important;
  text-decoration: none !important;
  background: rgba(255, 255, 255, 0.04) !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  border-radius: 16px !important;
  overflow: hidden !important;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25) !important;
  backdrop-filter: blur(16px) !important;
  -webkit-backdrop-filter: blur(16px) !important;
  transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
}

.kg-bookmark-card a.kg-bookmark-container:hover,
.dark-mode .kg-bookmark-card a.kg-bookmark-container:hover {
  background: rgba(255, 255, 255, 0.07) !important;
  border-color: rgba(56, 189, 248, 0.4) !important;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.35), 0 0 25px rgba(56, 189, 248, 0.15) !important;
  transform: translateY(-2px);
}

.kg-bookmark-content {
  display: flex !important;
  flex-direction: column !important;
  justify-content: space-between !important;
  flex-grow: 1 !important;
  flex-basis: 0 !important;
  min-width: 0 !important;
  padding: 20px 24px !important;
}

.kg-bookmark-title {
  color: #ffffff !important;
  font-size: 16px !important;
  font-weight: 700 !important;
  line-height: 1.4 !important;
  margin-bottom: 6px !important;
}

.kg-bookmark-description {
  color: var(--gm-text-muted, #94a3b8) !important;
  font-size: 14px !important;
  line-height: 1.5 !important;
  display: -webkit-box !important;
  -webkit-line-clamp: 2 !important;
  -webkit-box-orient: vertical !important;
  overflow: hidden !important;
}

.kg-bookmark-metadata {
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  font-size: 12px !important;
  font-weight: 600 !important;
  color: #64748b !important;
  margin-top: 14px !important;
}

.kg-bookmark-icon {
  width: 18px !important;
  height: 18px !important;
  border-radius: 4px !important;
  margin-right: 4px !important;
}

.kg-bookmark-thumbnail {
  position: relative !important;
  flex: 0 0 35% !important;
  min-width: 140px !important;
  max-width: 280px !important;
  min-height: 140px !important;
  overflow: hidden !important;
}

.kg-bookmark-thumbnail img {
  position: absolute !important;
  inset: 0 !important;
  width: 100% !important;
  height: 100% !important;
  object-fit: cover !important;
}

@media (max-width: 640px) {
  .kg-bookmark-card a.kg-bookmark-container,
  .dark-mode .kg-bookmark-card a.kg-bookmark-container {
    flex-direction: column-reverse !important;
  }
  .kg-bookmark-thumbnail {
    flex: none !important;
    width: 100% !important;
    height: 180px !important;
    min-width: 100% !important;
    max-width: 100% !important;
  }
}

/* 7. Koenig Callout Cards (Obsidian Glass Calibration) */
.kg-callout-card,
.dark-mode .kg-callout-card {
  display: flex !important;
  align-items: flex-start !important;
  padding: 22px 26px !important;
  border-radius: 16px !important;
  margin: 2.5em 0 !important;
  background: rgba(255, 255, 255, 0.04) !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  backdrop-filter: blur(14px) !important;
  -webkit-backdrop-filter: blur(14px) !important;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2) !important;
}

.kg-callout-emoji {
  font-size: 1.5em !important;
  line-height: 1 !important;
  margin-right: 16px !important;
  flex-shrink: 0 !important;
}

.kg-callout-text {
  font-size: 16px !important;
  line-height: 1.6 !important;
  color: #f1f5f9 !important;
  flex-grow: 1 !important;
  min-width: 0 !important;
}

.kg-callout-card a {
  color: #38bdf8 !important;
  text-decoration: underline !important;
}

/* Callout accent highlights */
.kg-callout-card-blue, .kg-callout-card-accent {
  background: rgba(56, 189, 248, 0.08) !important;
  border-color: rgba(56, 189, 248, 0.3) !important;
}

.kg-callout-card-green {
  background: rgba(16, 185, 129, 0.08) !important;
  border-color: rgba(16, 185, 129, 0.3) !important;
}

.kg-callout-card-red {
  background: rgba(239, 68, 68, 0.08) !important;
  border-color: rgba(239, 68, 68, 0.3) !important;
}

.kg-callout-card-yellow {
  background: rgba(245, 158, 11, 0.08) !important;
  border-color: rgba(245, 158, 11, 0.3) !important;
}

/* 8. Koenig Toggle Cards (Smooth Glass Accordion) */
.kg-toggle-card {
  width: 100% !important;
  margin: 2em 0 !important;
  background: rgba(255, 255, 255, 0.04) !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  border-radius: 14px !important;
  padding: 18px 22px !important;
  backdrop-filter: blur(12px) !important;
  -webkit-backdrop-filter: blur(12px) !important;
  transition: border-color 0.25s ease !important;
}

.kg-toggle-card:hover {
  border-color: rgba(255, 255, 255, 0.2) !important;
}

.kg-toggle-heading {
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  cursor: pointer !important;
  user-select: none !important;
}

.kg-toggle-heading-text {
  font-size: 18px !important;
  font-weight: 700 !important;
  color: #ffffff !important;
  margin: 0 !important;
  line-height: 1.4 !important;
}

.kg-toggle-card-icon {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 28px !important;
  height: 28px !important;
  background: rgba(255, 255, 255, 0.06) !important;
  border-radius: 50% !important;
  border: none !important;
  cursor: pointer !important;
  transition: transform 0.25s ease !important;
}

.kg-toggle-card[data-kg-toggle-state="open"] .kg-toggle-card-icon {
  transform: rotate(180deg) !important;
}

.kg-toggle-content {
  margin-top: 14px !important;
  padding-top: 14px !important;
  border-top: 1px solid rgba(255, 255, 255, 0.06) !important;
  color: #cbd5e1 !important;
  line-height: 1.6 !important;
}

/* 9. Koenig Audio, Video, Product & File Cards */
.kg-audio-card,
.kg-file-card-container,
.kg-product-card-container {
  background: rgba(255, 255, 255, 0.04) !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  border-radius: 16px !important;
  color: #f8fafc !important;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2) !important;
}

.kg-audio-player-container {
  background: transparent !important;
}

.kg-product-card-title,
.kg-file-card-title {
  color: #ffffff !important;
  font-weight: 700 !important;
}

.kg-product-card-description,
.kg-file-card-caption {
  color: var(--gm-text-muted, #94a3b8) !important;
}

.kg-product-card-button {
  background: #38bdf8 !important;
  color: #040609 !important;
  font-weight: 700 !important;
  border-radius: 9999px !important;
  border: none !important;
}

/* 10. Tables & Code Blocks (No Grid blowout) */
.gh-content table {
  width: 100% !important;
  max-width: 100% !important;
  overflow-x: auto !important;
  display: block !important;
  border-collapse: collapse !important;
  background: rgba(255, 255, 255, 0.02) !important;
  border: 1px solid rgba(255, 255, 255, 0.08) !important;
  border-radius: 12px !important;
  margin: 2em 0 !important;
}

.gh-content pre {
  width: 100% !important;
  max-width: 100% !important;
  overflow-x: auto !important;
  box-sizing: border-box !important;
  background: #090d16 !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  border-radius: 14px !important;
  padding: 20px 24px !important;
  margin: 2em 0 !important;
}

/* 11. Single Post Header Spacing Consistency */
.post-template .content-area {
  padding-top: 0 !important;
}
.post-template .site-main {
  padding-top: 24px !important;
}
.single-post {
  padding-top: 0 !important;
}
"""

p = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\glassmorphism.css'
with open(p, 'a', encoding='utf-8') as f:
    f.write("\n" + css_to_add)

print("Successfully appended Koenig & Content Anti-Glitch styles to glassmorphism.css!")


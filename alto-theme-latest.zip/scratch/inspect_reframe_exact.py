with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('void 0===s&&(s="js-reframe")')
print("Found reframe at:", idx)
print(text[idx-50:idx+600])


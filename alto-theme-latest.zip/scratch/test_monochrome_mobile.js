const { spawn } = require('child_process');
const fs = require('fs');

async function testMobileAndMonochrome() {
  const url = 'http://localhost:2368/';
  console.log('--- STARTING MOBILE MENU & MONOCHROME TEST ---');

  const chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9260',
    '--window-size=375,812',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  const list = await (await fetch('http://127.0.0.1:9260/json')).json();
  const page = list.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        ws.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id, method, params }));
  });

  ws.onopen = async () => {
    await send('Runtime.enable');
    await send('Page.enable');
    await new Promise(r => setTimeout(r, 1000));

    // 1. Switch to Light Mode
    console.log('1. Switching to Light Mode...');
    await send('Runtime.evaluate', {
      expression: `(() => {
        document.documentElement.classList.remove('dark-mode');
        document.documentElement.classList.add('light-mode');
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('user-theme', 'light');
      })()`
    });
    await new Promise(r => setTimeout(r, 500));

    // 2. Inspect closed menu shadow in Light Mode
    const closedMenuMetrics = await send('Runtime.evaluate', {
      expression: `(() => {
        const menu = document.querySelector('.gh-head-menu');
        const comp = window.getComputedStyle(menu);
        return {
          boxShadow: comp.boxShadow,
          opacity: comp.opacity,
          visibility: comp.visibility,
          maxHeight: comp.maxHeight,
          transform: comp.transform
        };
      })()`,
      returnByValue: true
    });
    console.log('Closed Menu Metrics (Light Mode):', JSON.stringify(closedMenuMetrics.result.value, null, 2));

    let shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/mobile-menu-light-closed.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved mobile-menu-light-closed.png');

    // 3. Click Mobile Hamburger Button to Open
    console.log('2. Clicking hamburger button...');
    await send('Runtime.evaluate', {
      expression: `document.getElementById('gmMobileMenuBtn').click()`
    });

    // Wait 400ms for smooth transition
    await new Promise(r => setTimeout(r, 450));

    // Inspect open menu in Light Mode
    const openMenuMetrics = await send('Runtime.evaluate', {
      expression: `(() => {
        const menu = document.querySelector('.gh-head-menu');
        const comp = window.getComputedStyle(menu);
        return {
          boxShadow: comp.boxShadow,
          opacity: comp.opacity,
          visibility: comp.visibility,
          maxHeight: comp.maxHeight,
          transform: comp.transform,
          background: comp.backgroundColor,
          borderBottom: comp.borderBottom
        };
      })()`,
      returnByValue: true
    });
    console.log('Open Menu Metrics (Light Mode):', JSON.stringify(openMenuMetrics.result.value, null, 2));

    shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/mobile-menu-light-open.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved mobile-menu-light-open.png');

    // 4. Switch to Dark Mode while open
    console.log('3. Switching to Dark Mode...');
    await send('Runtime.evaluate', {
      expression: `(() => {
        document.documentElement.classList.remove('light-mode');
        document.documentElement.classList.add('dark-mode');
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('user-theme', 'dark');
      })()`
    });
    await new Promise(r => setTimeout(r, 500));

    shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/mobile-menu-dark-open.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved mobile-menu-dark-open.png');

    // 5. Navigate to a post to verify monochrome styles
    console.log('4. Navigating to post to verify monochrome rendering...');
    await send('Page.navigate', { url: 'http://localhost:2368/test-koenig-defense-verification/' });
    await new Promise(r => setTimeout(r, 2000));

    shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/post-monochrome-dark.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved post-monochrome-dark.png');

    // Light Mode on Post
    await send('Runtime.evaluate', {
      expression: `(() => {
        document.documentElement.classList.remove('dark-mode');
        document.documentElement.classList.add('light-mode');
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('user-theme', 'light');
      })()`
    });
    await new Promise(r => setTimeout(r, 1000));

    shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/post-monochrome-light.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved post-monochrome-light.png');

    console.log('All tests finished successfully!');
    chrome.kill();
    process.exit(0);
  };
}

testMobileAndMonochrome().catch(err => {
  console.error(err);
  process.exit(1);
});


import os
import sys

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"
partials_dir = os.path.join(theme_dir, 'partials')
for f in ['loop.hbs', 'pagination.hbs', 'related.hbs', 'post-image.hbs']:
    p = os.path.join(partials_dir, f)
    if os.path.exists(p):
        with open(p, 'r', encoding='utf-8', errors='replace') as fp:
            sys.stdout.buffer.write(f"\n=== PARTIAL: {f} ===\n".encode('utf-8'))
            sys.stdout.buffer.write(fp.read().encode('utf-8'))


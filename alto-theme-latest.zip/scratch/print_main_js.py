import json

with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js.map', 'r', encoding='utf-8') as f:
    sm = json.load(f)

for s, c in zip(sm['sources'], sm['sourcesContent']):
    if s == 'main.js' or 'main' in s:
        print(f"=== {s} ===")
        print(c)


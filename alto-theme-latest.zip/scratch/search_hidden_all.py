import os
import re

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"

for root, dirs, files in os.walk(theme_dir):
    for f in files:
        if f.endswith(('.css', '.hbs', '.js')):
            p = os.path.join(root, f)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                lines = fp.readlines()
            for idx, line in enumerate(lines):
                if ('display:' in line and 'none' in line) or ('visibility:' in line and 'hidden' in line):
                    rel = os.path.relpath(p, theme_dir)
                    print(f"{rel}:{idx+1}: {line.strip()[:100]}")


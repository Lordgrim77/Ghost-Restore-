const { spawn } = require('child_process');
const fs = require('fs');

async function testPostVerification() {
  const url = 'http://localhost:2368/test-koenig-defense-verification/';
  
  // 1. Desktop Test (1280x2400)
  console.log('--- LAUNCHING DESKTOP TEST (1280x2400) ---');
  let chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9255',
    '--window-size=1280,2400',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  let list = await (await fetch('http://127.0.0.1:9255/json')).json();
  let page = list.find(t => t.type === 'page');
  let ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (wsInstance, method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        wsInstance.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    wsInstance.addEventListener('message', handler);
    wsInstance.send(JSON.stringify({ id, method, params }));
  });

  await new Promise((resolve) => {
    ws.onopen = async () => {
      await send(ws, 'Runtime.enable');
      await send(ws, 'Console.enable');

      // Wait 1.5s for rendering & images
      await new Promise(r => setTimeout(r, 1500));

      // Check all content elements
      const res = await send(ws, 'Runtime.evaluate', {
        expression: `(() => {
          const content = document.querySelector('.gh-content');
          if (!content) return { error: 'No .gh-content' };

          const items = Array.from(content.children).map((el, i) => {
            const rect = el.getBoundingClientRect();
            const cs = window.getComputedStyle(el);
            return {
              i,
              tag: el.tagName,
              cls: el.className,
              rect: { top: Math.round(rect.top), bottom: Math.round(rect.bottom), height: Math.round(rect.height), width: Math.round(rect.width) },
              minWidth: cs.minWidth,
              overflow: cs.overflow,
              display: cs.display
            };
          });

          // Check toggle card interaction
          const toggleHead = document.querySelector('.kg-toggle-heading');
          const toggleCard = document.querySelector('.kg-toggle-card');
          const beforeState = toggleCard?.getAttribute('data-kg-toggle-state');
          if (toggleHead) toggleHead.click();
          const afterState = toggleCard?.getAttribute('data-kg-toggle-state');

          return {
            contentWidth: Math.round(content.getBoundingClientRect().width),
            scrollWidth: document.documentElement.scrollWidth,
            clientWidth: document.documentElement.clientWidth,
            items,
            toggleTest: { beforeState, afterState }
          };
        })()`,
        returnByValue: true
      });

      console.log('Desktop Results:', JSON.stringify(res.result.value, null, 2));

      // Capture screenshot
      const shot = await send(ws, 'Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/koenig-defense-desktop.png', Buffer.from(shot.data, 'base64'));
      console.log('Saved koenig-defense-desktop.png');

      chrome.kill();
      resolve();
    };
  });

  // 2. Mobile Test (375x1800)
  console.log('\n--- LAUNCHING MOBILE TEST (375x1800) ---');
  chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9256',
    '--window-size=375,1800',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  list = await (await fetch('http://127.0.0.1:9256/json')).json();
  page = list.find(t => t.type === 'page');
  ws = new WebSocket(page.webSocketDebuggerUrl);

  await new Promise((resolve) => {
    ws.onopen = async () => {
      await send(ws, 'Runtime.enable');
      await new Promise(r => setTimeout(r, 1500));

      const res = await send(ws, 'Runtime.evaluate', {
        expression: `(() => {
          const content = document.querySelector('.gh-content');
          return {
            contentWidth: Math.round(content.getBoundingClientRect().width),
            scrollWidth: document.documentElement.scrollWidth,
            clientWidth: document.documentElement.clientWidth,
            bodyWidth: Math.round(document.body.getBoundingClientRect().width)
          };
        })()`,
        returnByValue: true
      });

      console.log('Mobile Results:', JSON.stringify(res.result.value, null, 2));

      // Capture screenshot
      const shot = await send(ws, 'Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/koenig-defense-mobile.png', Buffer.from(shot.data, 'base64'));
      console.log('Saved koenig-defense-mobile.png');

      chrome.kill();
      resolve();
    };
  });

  console.log('\nAll tests complete!');
}

testPostVerification().catch(e => { console.error(e); process.exit(1); });


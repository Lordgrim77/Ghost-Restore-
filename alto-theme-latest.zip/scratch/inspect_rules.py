import os
import re

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"

def inspect_file(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        text = f.read()
    
    # Let's extract all CSS rules
    # Clean comments
    clean_text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    
    # Match selector { body }
    rules = re.findall(r'([^{]+)\{([^}]+)\}', clean_text)
    
    interesting_selectors = [
        'gh-content', 'gh-canvas', 'kg-', 'single-post', 'content-area',
        'site-main', 'site-content', 'article', 'iframe', 'figure', 'blockquote'
    ]
    
    matches = []
    for sel, body in rules:
        sel_s = sel.strip()
        body_s = body.strip()
        for kw in interesting_selectors:
            if kw in sel_s:
                matches.append((sel_s, body_s))
                break
    return matches

print("=== SCREEN.CSS & IMPORTS ===")
screen_css_dir = os.path.join(theme_dir, 'assets', 'css')
for root, dirs, files in os.walk(screen_css_dir):
    for file in files:
        if file.endswith('.css'):
            p = os.path.join(root, file)
            m = inspect_file(p)
            if m:
                print(f"\n--- {file} ({len(m)} rules) ---")
                for sel, body in m:
                    print(f"{sel} {{\n  {body}\n}}")

print("\n=== GLASSMORPHISM.CSS ===")
gm_css = os.path.join(theme_dir, 'assets', 'built', 'glassmorphism.css')
gm_matches = inspect_file(gm_css)
print(f"Found {len(gm_matches)} matching rules in glassmorphism.css")
for sel, body in gm_matches:
    print(f"{sel} {{\n  {body}\n}}")


import os
import re

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"

css_files = []
for root, dirs, files in os.walk(theme_dir):
    for f in files:
        if f.endswith('.css'):
            css_files.append(os.path.join(root, f))

print(f"Found {len(css_files)} CSS files.")

# Keywords to search
keywords = [
    'gh-content', 'gh-canvas', 'kg-', 'single-post', 'content-area', 'site-main',
    'overflow', 'contain', 'content-visibility', 'max-height', 'display: none', 'visibility: hidden'
]

results = []

for cpath in css_files:
    rel_path = os.path.relpath(cpath, theme_dir)
    with open(cpath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    # Search for specific problematic patterns:
    # 1. contain: content, paint, layout, strict
    for m in re.finditer(r'([^{}]*\{[^}]*contain\s*:[^}]*\})', content, re.IGNORECASE):
        results.append((rel_path, "CONTAIN_PROPERTY", m.group(1).strip()[:200]))

    # 2. content-visibility: auto / hidden
    for m in re.finditer(r'([^{}]*\{[^}]*content-visibility\s*:[^}]*\})', content, re.IGNORECASE):
        results.append((rel_path, "CONTENT_VISIBILITY", m.group(1).strip()[:200]))

    # 3. overflow: hidden on post/content/canvas containers
    for m in re.finditer(r'([^{}]*(?:gh-content|gh-canvas|single-post|site-main|content-area|article)[^{}]*\{[^}]*overflow\s*:\s*hidden[^}]*\})', content, re.IGNORECASE):
        results.append((rel_path, "OVERFLOW_HIDDEN_ON_CONTAINER", m.group(1).strip()[:200]))

    # 4. display: none or visibility: hidden on post / kg / embed / content
    for m in re.finditer(r'([^{}]*(?:kg-|embed|gh-content|post-content|article)[^{}]*\{[^}]*(?:display\s*:\s*none|visibility\s*:\s*hidden)[^}]*\})', content, re.IGNORECASE):
        results.append((rel_path, "HIDDEN_ON_CONTENT_OR_KG", m.group(1).strip()[:200]))

    # 5. max-height on post / gh-content / article / kg-
    for m in re.finditer(r'([^{}]*(?:gh-content|gh-canvas|single-post|article|kg-)[^{}]*\{[^}]*max-height\s*:[^}]*\})', content, re.IGNORECASE):
        results.append((rel_path, "MAX_HEIGHT_ON_CONTENT", m.group(1).strip()[:200]))

print(f"\n--- AUDIT RESULTS: {len(results)} matches found ---")
for rpath, cat, snippet in results:
    cleaned = " ".join(snippet.split())
    print(f"[{cat}] in {rpath}:\n  {cleaned}\n")


with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('reframe')
print("First reframe at:", idx)
idx2 = text.find('function reframe', 0)
if idx2 != -1:
    print(text[idx2:idx2+1000])
else:
    # search for reframe = 
    idx3 = text.find('reframe=', 0)
    print("reframe= at", idx3)
    print(text[idx3-50:idx3+500])


import os
import re

for fname in ['page-contact.hbs', 'page-support.hbs']:
    p_page = os.path.join(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto', fname)
    with open(p_page, 'r', encoding='utf-8') as f:
        page_code = f.read()
    page_code = page_code.replace('stroke="#00f2fe"', 'stroke="#ffffff"')
    page_code = page_code.replace('fill="#0284c7" stroke="#38bdf8"', 'fill="#1e293b" stroke="#ffffff"')
    page_code = page_code.replace('stroke="#38bdf8"', 'stroke="#e2e8f0"')
    page_code = page_code.replace('#229ED9', '#ffffff')
    page_code = page_code.replace('#229ed9', '#ffffff')
    page_code = page_code.replace('contact@pedohunters.xlordgrim.com', 'contact@pedohunters.help')
    with open(p_page, 'w', encoding='utf-8') as f:
        f.write(page_code)
    print(f"Updated {fname}!")

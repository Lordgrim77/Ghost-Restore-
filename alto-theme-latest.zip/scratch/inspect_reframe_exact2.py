with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('js-reframe')
print("Found js-reframe at:", idx)
print(text[max(0, idx-100):min(len(text), idx+600)])


import re

with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\screen.css', 'r', encoding='utf-8') as f:
    css = f.read()

# Let's inspect rules in screen.css
rules = re.findall(r'([^{}]+)\{([^}]+)\}', css)

checks = [
    'overflow', 'contain', 'content-visibility', 'max-height', 'display:none',
    'visibility:hidden', 'kg-', 'gh-content', 'gh-canvas', 'float', 'clear'
]

results = {c: [] for c in checks}

for sel, body in rules:
    sel_clean = " ".join(sel.split())
    body_clean = " ".join(body.split())
    rule_str = f"{sel_clean} {{ {body_clean} }}"
    for c in checks:
        if c in sel_clean.lower() or c in body_clean.lower():
            results[c].append(rule_str)

for c in checks:
    print(f"\n==================== CHECK: {c} ({len(results[c])} matches) ====================")
    for r in results[c][:10]:
        print(r[:200])


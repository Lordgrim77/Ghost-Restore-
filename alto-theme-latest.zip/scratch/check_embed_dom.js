const { spawn } = require('child_process');

async function checkDOM() {
  const url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/';
  const chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9253',
    '--window-size=1200,1600',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  const list = await (await fetch('http://127.0.0.1:9253/json')).json();
  const page = list.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        ws.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id, method, params }));
  });

  ws.onopen = async () => {
    await send('Runtime.enable');
    await new Promise(r => setTimeout(r, 1500));

    const res = await send('Runtime.evaluate', {
      expression: `(() => {
        const embeds = document.querySelectorAll('.kg-embed-card, figure, iframe');
        return Array.from(embeds).map(el => ({
          tagName: el.tagName,
          className: el.className,
          outerHTML: el.outerHTML.slice(0, 300),
          rect: el.getBoundingClientRect(),
          style: el.getAttribute('style'),
          computedHeight: window.getComputedStyle(el).height,
          computedWidth: window.getComputedStyle(el).width,
          computedDisplay: window.getComputedStyle(el).display,
          computedPosition: window.getComputedStyle(el).position
        }));
      })()`,
      returnByValue: true
    });

    console.log(JSON.stringify(res.result.value, null, 2));
    chrome.kill();
    process.exit(0);
  };
}

checkDOM().catch(e => { console.error(e); process.exit(1); });


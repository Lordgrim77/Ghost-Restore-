with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_full.txt', 'w', encoding='utf-8') as f:
    import urllib.request
    url = 'http://localhost:2368/public/cards.min.js'
    with urllib.request.urlopen(url) as res:
        code = res.read().decode('utf-8')
    f.write(code)
print("Saved cards_full.txt")


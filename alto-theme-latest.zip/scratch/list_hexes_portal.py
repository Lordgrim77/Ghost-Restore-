p = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\portal-theme.js'
with open(p, 'r', encoding='utf-8') as f:
    text = f.read()

import re
hexes = re.findall(r'#[0-9a-fA-F]{3,8}', text)
print("Unique hex codes in portal-theme.js:")
print(sorted(list(set(hexes))))


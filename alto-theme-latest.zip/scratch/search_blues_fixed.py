import os
import re

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"

targets = [
    '38bdf8', '0284c7', '0369a1', '00f2fe', '229ed9', '3b82f6', '1d4ed8', '60a5fa',
    '93c5fd', 'bfdbfe', '0ea5e9', '56, 189, 248', '34, 158, 217', '2, 132, 199',
    '0, 242, 254', '--ghost-accent-color'
]

results = {}
for root, dirs, files in os.walk(theme_dir):
    if os.path.basename(root) in ['scratch', 'node_modules', '.git']:
        continue
    for f in files:
        if f.endswith(('.css', '.js', '.hbs', '.json', '.sh')):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, theme_dir)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                lines = fp.readlines()
            for idx, line in enumerate(lines):
                for t in targets:
                    if t.lower() in line.lower():
                        results.setdefault(rel, []).append((idx+1, line.strip()))
                        break

for rel, entries in results.items():
    print(f"\n=== {rel} ({len(entries)} matches) ===")
    for lnum, text in entries[:15]:
        print(f"  {lnum}: {text[:110]}")
    if len(entries) > 15:
        print(f"  ... and {len(entries) - 15} more in {rel}")

# Also check Ghost-Restore repo
repo_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\Ghost-Restore"
print("\n=== GHOST-RESTORE REPO ===")
for root, dirs, files in os.walk(repo_dir):
    if os.path.basename(root) in ['scratch', '.git', '__pycache__']:
        continue
    for f in files:
        if f.endswith(('.py', '.sh', '.md')):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, repo_dir)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                lines = fp.readlines()
            for idx, line in enumerate(lines):
                for t in targets:
                    if t.lower() in line.lower():
                        print(f"  {rel}:{idx+1}: {line.strip()[:110]}")
                        break


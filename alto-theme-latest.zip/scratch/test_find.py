import os
import re

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"

targets = ['38bdf8', '0284c7', 'StopAbuseTeam', 'accent']
for root, dirs, files in os.walk(theme_dir):
    if 'scratch' in root: continue
    for f in files:
        if f.endswith(('.css', '.js', '.hbs')):
            p = os.path.join(root, f)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                txt = fp.read()
            for t in targets:
                if t in txt:
                    print(f"Found '{t}' in {os.path.relpath(p, theme_dir)} (count: {txt.count(t)})")


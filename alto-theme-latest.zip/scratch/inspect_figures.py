import urllib.request
import re

url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/'
with urllib.request.urlopen(url) as res:
    html = res.read().decode('utf-8')

m = re.search(r'<div class="gh-content gh-canvas">(.*?)</div>\s*<div class="gh-canvas">', html, re.DOTALL)
if m:
    content = m.group(1)
    tags = re.findall(r'<figure[^>]*>.*?</figure>', content, re.DOTALL)
    print("Found figures:", len(tags))
    for t in tags:
        print("FIGURE:", t[:300])
        print("---")


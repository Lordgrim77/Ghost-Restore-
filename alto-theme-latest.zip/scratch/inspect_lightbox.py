with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js', 'r', encoding='utf-8') as f:
    text = f.read()

import re
# Find lightbox function
m = re.search(r'function lightbox\([^)]*\)\{.*?\}\}\)\}\)', text)
if m:
    print("Found lightbox:")
    print(m.group(0)[:1500])
else:
    m2 = re.search(r'function lightbox.*?(?=function|\Z)', text)
    if m2:
        print("Found lightbox partial:")
        print(m2.group(0)[:1500])


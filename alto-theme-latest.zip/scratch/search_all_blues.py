import os
import re

theme_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"

blue_patterns = [
    r'#38bdf8', r'#0284c7', r'#0369a1', r'#00f2fe', r'#229ed9', r'#3b82f6',
    r'#1d4ed8', r'#60a5fa', r'#93c5fd', r'#bfdbfe', r'#0ea5e9', r'#0284c7',
    r'rgba?\s*\(\s*56\s*,\s*189\s*,\s*248',
    r'rgba?\s*\(\s*34\s*,\s*158\s*,\s*217',
    r'rgba?\s*\(\s*2\s*,\s*132\s*,\s*199',
    r'rgba?\s*\(\s*0\s*,\s*242\s*,\s*254',
    r'cyan', r'sky', r'accent-color'
]

results = []

for root, dirs, files in os.walk(theme_dir):
    if 'node_modules' in root or 'scratch' in root or '.git' in root:
        continue
    for f in files:
        if f.endswith(('.css', '.js', '.hbs', '.json', '.sh')):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, theme_dir)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                lines = fp.readlines()
            for idx, line in enumerate(lines):
                for pat in blue_patterns:
                    if re.search(pat, line, re.IGNORECASE):
                        results.append((rel, idx+1, line.strip()))
                        break

print(f"Total blue/cyan occurrences found: {len(results)}")
by_file = {}
for rel, line_num, text in results:
    by_file.setdefault(rel, []).append((line_num, text))

for rel, entries in by_file.items():
    print(f"\n--- {rel} ({len(entries)} matches) ---")
    for lnum, text in entries[:10]:
        print(f"  Line {lnum}: {text[:100]}")
    if len(entries) > 10:
        print(f"  ... and {len(entries)-10} more in {rel}")


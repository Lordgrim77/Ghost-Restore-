with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\screen.css', 'r', encoding='utf-8') as f:
    text = f.read()

import re
matches = re.findall(r'--content-width:[^;]+|--container-width:[^;]+|--gap:[^;]+', text)
print(set(matches))


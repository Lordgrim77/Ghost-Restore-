import urllib.request

url = 'http://localhost:2368/public/cards.min.css'
with urllib.request.urlopen(url) as res:
    css = res.read().decode('utf-8')

print("cards.min.css length:", len(css))
with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_css.txt', 'w', encoding='utf-8') as f:
    f.write(css)
print("Saved cards_css.txt")


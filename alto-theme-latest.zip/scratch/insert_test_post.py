import sqlite3
import datetime

conn = sqlite3.connect(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\data\ghost-local.db')
c = conn.cursor()

test_post_id = 'testpostkoenig0000000001'
slug = 'test-koenig-defense-verification'
title = 'Koenig Content Defense & Anti-Glitch Verification Suite'

html_content = """
<p>This post verifies that all Koenig cards, embeds, images, and rich media render reliably without overflow truncation, layout clipping, or DOM collapse.</p>

<h2>1. Standard Koenig Image Card</h2>
<figure class="kg-card kg-image-card">
  <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80" class="kg-image" alt="Cyber Grid Defense" loading="lazy">
  <figcaption>High-resolution Koenig Image Card with safe container bounds</figcaption>
</figure>

<h2>2. Koenig YouTube Video Embed</h2>
<p>Testing video embed aspect ratio and responsive wrapper containment:</p>
<figure class="kg-card kg-embed-card">
  <iframe allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen="" loading="lazy" src="https://www.youtube.com/embed/PkSXYr_jWjg" title="YouTube video player"></iframe>
  <figcaption>YouTube Embed inside kg-embed-card with 16:9 aspect-ratio</figcaption>
</figure>

<h2>3. Koenig Callout Cards in Obsidian Theme</h2>
<div class="kg-card kg-callout-card kg-callout-card-blue">
  <div class="kg-callout-emoji">🛡️</div>
  <div class="kg-callout-text"><strong>Security Alert:</strong> This is a blue callout card testing contrast, background tint, and emoji alignment against the dark obsidian palette.</div>
</div>

<div class="kg-card kg-callout-card kg-callout-card-green">
  <div class="kg-callout-emoji">✅</div>
  <div class="kg-callout-text"><strong>System Operational:</strong> Verification that callout cards with green accents provide clear readability and never collapse.</div>
</div>

<h2>4. Koenig Bookmark Card</h2>
<figure class="kg-card kg-bookmark-card">
  <a class="kg-bookmark-container" href="https://t.me/StopAbuseTeam" target="_blank" rel="noopener noreferrer">
    <div class="kg-bookmark-content">
      <div class="kg-bookmark-title">Stop Abuse Team Official Telegram</div>
      <div class="kg-bookmark-description">Join our official operations channel for real-time updates and community defense reports.</div>
      <div class="kg-bookmark-metadata">
        <span class="kg-bookmark-author">Pedo Hunters</span>
        <span class="kg-bookmark-publisher">Telegram</span>
      </div>
    </div>
    <div class="kg-bookmark-thumbnail">
      <img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80" alt="Thumbnail">
    </div>
  </a>
</figure>

<h2>5. Koenig Image Gallery Card (Defensive Rendering)</h2>
<figure class="kg-card kg-gallery-card kg-width-wide">
  <div class="kg-gallery-container">
    <div class="kg-gallery-row">
      <div class="kg-gallery-image"><img src="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80" alt="Terminal Matrix" width="600" height="400"></div>
      <div class="kg-gallery-image"><img src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=600&q=80" alt="Crypto Security" width="600" height="400"></div>
      <div class="kg-gallery-image"><img src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=600&q=80" alt="Data Streams"></div>
    </div>
  </div>
  <figcaption>Responsive 3-Column Image Gallery with automatic flex ratios</figcaption>
</figure>

<h2>6. Koenig Interactive Toggle Card</h2>
<div class="kg-card kg-toggle-card" data-kg-toggle-state="close">
  <div class="kg-toggle-heading">
    <h4 class="kg-toggle-heading-text">Click to Expand: Operative Protocol Guide</h4>
    <button class="kg-toggle-card-icon" aria-label="Toggle">
      <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><polyline points="6 9 12 15 18 9"></polyline></svg>
    </button>
  </div>
  <div class="kg-toggle-content">
    <p>This collapsible accordion content is verified to toggle reliably even if third-party scripts fail.</p>
    <ul>
      <li>Zero-storage local vector avatar system</li>
      <li>Clean CSS grid column containment</li>
      <li>Synchronous anti-FOUC shield protection</li>
    </ul>
  </div>
</div>

<h2>7. Wide Code Block & Table Containment (Anti-Blowout)</h2>
<p>Testing that preformatted code with unbroken characters does not blow out the CSS Grid track:</p>
<pre><code>const DEFENSE_TOKEN = "0x89205A3A3b2A553c0205605273de626121636154_NONCE_UNBROKEN_VERY_LONG_HEX_SEQUENCE_VERIFYING_HORIZONTAL_SCROLLBAR_CONTAINMENT_WITHOUT_GRID_EXPLOSION";
function verifyTrackBounds() {
    console.log("Grid item correctly respects min-width: 0 !important;");
}</code></pre>

<table style="width: 100%;">
  <thead>
    <tr>
      <th>Module</th>
      <th>Status</th>
      <th>Protection Layer</th>
      <th>Responsive State</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>.gh-canvas</td>
      <td>Stabilized</td>
      <td>min-width: 0 track lock</td>
      <td>100% Fluid</td>
    </tr>
    <tr>
      <td>.kg-embed-card</td>
      <td>Stabilized</td>
      <td>aspect-ratio 16:9 + min-height 220px</td>
      <td>Zero Collapse</td>
    </tr>
    <tr>
      <td>.kg-gallery-card</td>
      <td>Stabilized</td>
      <td>Pure CSS flex fallback</td>
      <td>Zero Glitch</td>
    </tr>
    <tr>
      <td>.kg-bookmark-card</td>
      <td>Stabilized</td>
      <td>Mobile column stack + glass blur</td>
      <td>Adaptive</td>
    </tr>
  </tbody>
</table>

<p>Paragraph after table: verifying vertical rhythm, line spacing, and complete element rendering across all viewports.</p>
"""

# Check if post exists
exists = c.execute("SELECT id FROM posts WHERE id=?", (test_post_id,)).fetchone()
now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

if exists:
    c.execute("""
        UPDATE posts 
        SET html=?, title=?, slug=?, status='published', updated_at=?
        WHERE id=?
    """, (html_content, title, slug, now, test_post_id))
    print("Updated test post!")
else:
    # Get user id
    user_id = c.execute("SELECT id FROM users LIMIT 1").fetchone()[0]
    c.execute("""
        INSERT INTO posts (
            id, uuid, title, slug, html, comment_id, plaintext, feature_image,
            featured, type, status, locale, visibility, email_recipient_filter,
            created_at, updated_at, published_at, published_by
        ) VALUES (
            ?, 'uuid-test-defense-001', ?, ?, ?, 'comment-test-defense', 'Test content',
            'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
            0, 'post', 'published', NULL, 'public', 'all',
            ?, ?, ?, ?
        )
    """, (test_post_id, title, slug, html_content, now, now, now, user_id))
    
    # Also link to primary author in posts_authors table if exists
    c.execute("INSERT OR REPLACE INTO posts_authors (id, post_id, author_id, sort_order) VALUES ('pa-test-defense-01', ?, ?, 0)", (test_post_id, user_id))
    print("Inserted test post!")

conn.commit()
conn.close()

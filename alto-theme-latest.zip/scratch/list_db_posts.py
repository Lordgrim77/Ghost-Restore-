import sqlite3

conn = sqlite3.connect(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\data\ghost-local.db')
c = conn.cursor()
rows = c.execute("SELECT id, slug, title, status FROM posts WHERE type='post'").fetchall()
for r in rows:
    print(r)
conn.close()


p = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\screen.css'
with open(p, 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace('img{height:auto}', 'img{max-width:100%;height:auto}')
text = text.replace('.gh-canvas>*{grid-column:main}', '.gh-canvas>*{grid-column:main;min-width:0}')

with open(p, 'w', encoding='utf-8') as f:
    f.write(text)

print("Successfully patched built screen.css!")


import re

# 1. Update member-avatars.js
p_avatars = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\member-avatars.js'
with open(p_avatars, 'r', encoding='utf-8') as f:
    av_code = f.read()

# Update sentinel
av_code = av_code.replace(
    """id: 'sentinel',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#00f2fe" stroke-width="2"/><path d="M24 10L36 16V26C36 33 24 38 24 38C24 38 12 33 12 26V16L24 10Z" fill="url(#gradSentinel)" stroke="#38bdf8" stroke-width="2"/><circle cx="24" cy="22" r="4" fill="#ffffff"/><path d="M19 28C19 25.5 21.2 24 24 24C26.8 24 29 25.5 29 28" stroke="#38bdf8" stroke-width="2" stroke-linecap="round"/><defs><linearGradient id="gradSentinel" x1="12" y1="10" x2="36" y2="38"><stop stop-color="#0284c7"/><stop offset="1" stop-color="#0369a1"/></linearGradient></defs></svg>'""",
    """id: 'sentinel',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#ffffff" stroke-width="2"/><path d="M24 10L36 16V26C36 33 24 38 24 38C24 38 12 33 12 26V16L24 10Z" fill="url(#gradSentinel)" stroke="#ffffff" stroke-width="2"/><circle cx="24" cy="22" r="4" fill="#ffffff"/><path d="M19 28C19 25.5 21.2 24 24 24C26.8 24 29 25.5 29 28" stroke="#e2e8f0" stroke-width="2" stroke-linecap="round"/><defs><linearGradient id="gradSentinel" x1="12" y1="10" x2="36" y2="38"><stop stop-color="#334155"/><stop offset="1" stop-color="#0f172a"/></linearGradient></defs></svg>'"""
)

# Update wolf
av_code = av_code.replace(
    """id: 'wolf',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#0a1224" stroke="#60a5fa" stroke-width="2"/><polygon points="17,14 21,22 14,24" fill="#3b82f6"/><polygon points="31,14 27,22 34,24" fill="#3b82f6"/><path d="M17 23L24 17L31 23L29 32L24 38L19 32L17 23Z" fill="#1d4ed8" stroke="#93c5fd" stroke-width="1.5"/><circle cx="21" cy="25" r="2" fill="#bfdbfe"/><circle cx="27" cy="25" r="2" fill="#bfdbfe"/></svg>'""",
    """id: 'wolf',
            svg: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="22" fill="#090d16" stroke="#cbd5e1" stroke-width="2"/><polygon points="17,14 21,22 14,24" fill="#475569"/><polygon points="31,14 27,22 34,24" fill="#475569"/><path d="M17 23L24 17L31 23L29 32L24 38L19 32L17 23Z" fill="#1e293b" stroke="#ffffff" stroke-width="1.5"/><circle cx="21" cy="25" r="2" fill="#ffffff"/><circle cx="27" cy="25" r="2" fill="#ffffff"/></svg>'"""
)

with open(p_avatars, 'w', encoding='utf-8') as f:
    f.write(av_code)
print("Updated member-avatars.js!")

# 2. Update account.hbs
p_account = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\account.hbs'
with open(p_account, 'r', encoding='utf-8') as f:
    acc_code = f.read()

acc_code = acc_code.replace('stroke="#00f2fe"', 'stroke="#ffffff"')
acc_code = acc_code.replace('fill="#0284c7" stroke="#38bdf8"', 'fill="#1e293b" stroke="#ffffff"')
acc_code = acc_code.replace('stroke="#38bdf8"', 'stroke="#e2e8f0"')

with open(p_account, 'w', encoding='utf-8') as f:
    f.write(acc_code)
print("Updated account.hbs!")

# 3. Update page-contact.hbs and page-support.hbs
for fname in ['page-contact.hbs', 'page-support.hbs']:
    p_page = os.path.join(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto', fname)
    with open(p_page, 'r', encoding='utf-8') as f:
        page_code = f.read()
    page_code = page_code.replace('stroke="#00f2fe"', 'stroke="#ffffff"')
    page_code = page_code.replace('fill="#0284c7" stroke="#38bdf8"', 'fill="#1e293b" stroke="#ffffff"')
    page_code = page_code.replace('stroke="#38bdf8"', 'stroke="#e2e8f0"')
    page_code = page_code.replace('#229ED9', '#ffffff')
    page_code = page_code.replace('#229ed9', '#ffffff')
    with open(p_page, 'w', encoding='utf-8') as f:
        f.write(page_code)
    print(f"Updated {fname}!")


import urllib.request
import re

url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/'
with urllib.request.urlopen(url) as res:
    html = res.read().decode('utf-8')

# Extract .gh-content
m = re.search(r'<div class="gh-content gh-canvas">(.*?)</div>\s*<div class="gh-canvas">', html, re.DOTALL)
if m:
    content = m.group(1)
    print("Found gh-content! Length:", len(content))
    print("Snippet:")
    print(content[:1500])
else:
    print("Could not find exact boundary. Let's find gh-content opening:")
    idx = html.find('gh-content')
    print(html[idx-100:idx+1500])


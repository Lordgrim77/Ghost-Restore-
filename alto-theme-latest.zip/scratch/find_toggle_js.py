with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_full.txt', 'r', encoding='utf-8') as f:
    text = f.read()

import re
m = re.search(r'kg-toggle.*?(?=function|\Z)', text)
if m:
    print(m.group(0)[:500])


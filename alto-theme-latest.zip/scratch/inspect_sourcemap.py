import json

with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js.map', 'r', encoding='utf-8') as f:
    sm = json.load(f)

sources = sm.get('sources', [])
contents = sm.get('sourcesContent', [])

for s, c in zip(sources, contents):
    print(f"=== SOURCE: {s} ({len(c) if c else 0} chars) ===")
    if c and len(c) < 2500:
        print(c)
    elif c:
        print(c[:1000])
        print("...\n[truncated]")


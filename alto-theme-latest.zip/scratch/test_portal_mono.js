const { spawn } = require('child_process');
const fs = require('fs');

async function testPortalMonochrome() {
  const url = 'http://localhost:2368/';
  console.log('--- STARTING PORTAL MONOCHROME TEST ---');

  const chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9261',
    '--window-size=1200,900',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  const list = await (await fetch('http://127.0.0.1:9261/json')).json();
  const page = list.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        ws.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id, method, params }));
  });

  ws.onopen = async () => {
    await send('Runtime.enable');
    await send('Page.enable');
    await new Promise(r => setTimeout(r, 1000));

    // Click Sign In button in top nav
    console.log('Opening Sign In Portal...');
    await send('Runtime.evaluate', {
      expression: `document.querySelector('.gm-head-signin-btn').click()`
    });

    await new Promise(r => setTimeout(r, 1500));

    // Capture screenshot of Sign In Modal (Dark Mode)
    let shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/portal-signin-monochrome-dark.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved portal-signin-monochrome-dark.png');

    // Switch to Light Mode
    console.log('Switching to Light Mode in Portal...');
    await send('Runtime.evaluate', {
      expression: `(() => {
        document.documentElement.classList.remove('dark-mode');
        document.documentElement.classList.add('light-mode');
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('user-theme', 'light');
        if (window.__gmRefreshPortalTheme) window.__gmRefreshPortalTheme();
      })()`
    });

    await new Promise(r => setTimeout(r, 1200));

    shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync('C:/Users/LordgrimxDJay/.gemini/antigravity/brain/74ba3f98-2a54-40b6-974b-e306fdd38b05/portal-signin-monochrome-light.png', Buffer.from(shot.data, 'base64'));
    console.log('Saved portal-signin-monochrome-light.png');

    console.log('Portal tests complete!');
    chrome.kill();
    process.exit(0);
  };
}

testPortalMonochrome().catch(err => {
  console.error(err);
  process.exit(1);
});


import re

p = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\glassmorphism.css'
with open(p, 'r', encoding='utf-8') as f:
    css = f.read()

# 1. Update mobile menu rules
mobile_menu_old = """  /* Navigation Menu: Hidden by default on mobile; smoothly drops down as a frosted glass drawer when tapped */
  #gh-head .gh-head-menu,
  .gh-head-menu {
    display: none !important;
    position: absolute !important;
    top: 58px !important;
    left: 0 !important;
    right: 0 !important;
    width: 100% !important;
    box-sizing: border-box !important;
    margin: 0 !important;
    padding: 16px 20px !important;
    background: #090b10 !important;
    border-bottom: 1px solid var(--gm-head-border) !important;
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.85) !important;
    z-index: 9998 !important;
    pointer-events: auto !important;
    transform: none !important;
  }

  html.light-mode #gh-head .gh-head-menu,
  html[data-theme="light"] #gh-head .gh-head-menu {
    background: #ffffff !important;
  }

  #gh-head.is-menu-open .gh-head-menu {
    display: flex !important;
    flex-direction: column !important;
    visibility: visible !important;
    opacity: 1 !important;
    animation: gmDropdownSlide 0.22s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
  }

  @keyframes gmDropdownSlide {
    from {
      opacity: 0;
      transform: translateY(-8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }"""

mobile_menu_new = """  /* Navigation Menu: Smooth slide & fade transition without harsh light-mode shadows */
  #gh-head .gh-head-menu,
  .gh-head-menu {
    display: flex !important;
    flex-direction: column !important;
    position: absolute !important;
    top: 58px !important;
    left: 0 !important;
    right: 0 !important;
    width: 100% !important;
    box-sizing: border-box !important;
    margin: 0 !important;
    padding: 0 20px !important;
    max-height: 0 !important;
    opacity: 0 !important;
    visibility: hidden !important;
    pointer-events: none !important;
    overflow: hidden !important;
    background: rgba(9, 11, 16, 0.98) !important;
    backdrop-filter: blur(24px) !important;
    -webkit-backdrop-filter: blur(24px) !important;
    border-bottom: 1px solid transparent !important;
    box-shadow: none !important;
    transform: translateY(-8px) scale(0.99) !important;
    transition: max-height 0.35s cubic-bezier(0.16, 1, 0.3, 1),
                opacity 0.28s cubic-bezier(0.16, 1, 0.3, 1),
                transform 0.35s cubic-bezier(0.16, 1, 0.3, 1),
                padding 0.35s cubic-bezier(0.16, 1, 0.3, 1),
                border-color 0.25s ease,
                box-shadow 0.25s ease,
                visibility 0.35s step-end !important;
    z-index: 9998 !important;
  }

  html.light-mode #gh-head .gh-head-menu,
  html[data-theme="light"] #gh-head .gh-head-menu {
    background: rgba(255, 255, 255, 0.98) !important;
    border-bottom: 1px solid transparent !important;
    box-shadow: none !important;
  }

  #gh-head.is-menu-open .gh-head-menu {
    max-height: 520px !important;
    opacity: 1 !important;
    visibility: visible !important;
    pointer-events: auto !important;
    overflow: hidden !important;
    padding: 16px 20px 24px !important;
    transform: translateY(0) scale(1) !important;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1) !important;
    box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.65) !important;
    transition: max-height 0.38s cubic-bezier(0.16, 1, 0.3, 1),
                opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1),
                transform 0.38s cubic-bezier(0.16, 1, 0.3, 1),
                padding 0.38s cubic-bezier(0.16, 1, 0.3, 1),
                border-color 0.3s ease,
                box-shadow 0.3s ease,
                visibility 0s step-start !important;
  }

  /* In light mode: delicate, subtle shadow that NEVER casts a large dark slab over articles */
  html.light-mode #gh-head.is-menu-open .gh-head-menu,
  html[data-theme="light"] #gh-head.is-menu-open .gh-head-menu {
    border-bottom: 1px solid rgba(0, 0, 0, 0.08) !important;
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.07), 0 4px 10px -3px rgba(0, 0, 0, 0.03) !important;
  }"""

if mobile_menu_old in css:
    css = css.replace(mobile_menu_old, mobile_menu_new)
    print("Replaced mobile menu animation & shadow rules!")
else:
    print("WARNING: mobile_menu_old exact match failed! Trying regex/flexible match...")

# 2. Replace all remaining blue/cyan occurrences with monochrome black/white:
replacements = [
    # Cyan accent to white in dark mode, black in light mode
    ('#38bdf8', '#ffffff'),
    ('#0284c7', '#000000'),
    ('#0ea5e9', '#ffffff'),
    ('#00f2fe', '#ffffff'),
    ('#229ed9', '#ffffff'),
    ('#229ED9', '#ffffff'),
    ('rgba(56, 189, 248, 0.5)', 'rgba(255, 255, 255, 0.4)'),
    ('rgba(56, 189, 248, 0.45)', 'rgba(255, 255, 255, 0.4)'),
    ('rgba(56, 189, 248, 0.4)', 'rgba(255, 255, 255, 0.35)'),
    ('rgba(56, 189, 248, 0.35)', 'rgba(255, 255, 255, 0.3)'),
    ('rgba(56, 189, 248, 0.3)', 'rgba(255, 255, 255, 0.25)'),
    ('rgba(56, 189, 248, 0.2)', 'rgba(255, 255, 255, 0.15)'),
    ('rgba(56, 189, 248, 0.15)', 'rgba(255, 255, 255, 0.1)'),
    ('rgba(56, 189, 248, 0.1)', 'rgba(255, 255, 255, 0.08)'),
    ('rgba(56, 189, 248, 0.08)', 'rgba(255, 255, 255, 0.06)'),
    ('rgba(34, 158, 217, 0.12)', 'rgba(255, 255, 255, 0.05)'),
    ('rgba(34, 158, 217, 0.15)', 'rgba(255, 255, 255, 0.08)'),
    ('rgba(34, 158, 217, 0.08)', 'rgba(0, 0, 0, 0.03)'),
    ('rgba(34, 158, 217, 0.3)', 'rgba(0, 0, 0, 0.12)'),
    ('rgba(34, 158, 217, 0.35)', 'rgba(255, 255, 255, 0.25)'),
    ('rgba(34, 158, 217, 0.5)', 'rgba(255, 255, 255, 0.35)'),
    ('rgba(34, 158, 217, 0.4)', 'rgba(255, 255, 255, 0.3)'),
    ('rgba(34, 158, 217, 0.2)', 'rgba(255, 255, 255, 0.15)'),
    ('rgba(2, 132, 199, 0.2)', 'rgba(255, 255, 255, 0.15)')
]

for src, dst in replacements:
    css = css.replace(src, dst)

with open(p, 'w', encoding='utf-8') as f:
    f.write(css)

print("Saved updated glassmorphism.css!")


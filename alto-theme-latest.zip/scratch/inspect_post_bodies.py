import sqlite3

conn = sqlite3.connect(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\data\ghost-local.db')
c = conn.cursor()
rows = c.execute("SELECT slug, html FROM posts WHERE type='post'").fetchall()
for slug, h in rows:
    print(f"=== POST: {slug} (length: {len(h) if h else 0}) ===")
    if h:
        print(h[:600])
        print("...\n")
conn.close()


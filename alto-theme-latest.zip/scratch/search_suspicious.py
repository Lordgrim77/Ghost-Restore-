import re

with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\glassmorphism.css', 'r', encoding='utf-8') as f:
    css = f.read()

# Let's search for suspicious properties in glassmorphism.css
suspicious_patterns = [
    r'overflow\s*:\s*hidden',
    r'contain\s*:',
    r'content-visibility\s*:',
    r'will-change\s*:',
    r'transform\s*:',
    r'clip-path\s*:',
    r'perspective\s*:',
    r'backface-visibility\s*:',
    r'display\s*:\s*none',
    r'visibility\s*:\s*hidden',
    r'opacity\s*:\s*0',
    r'height\s*:\s*0',
    r'max-height\s*:',
    r'float\s*:',
    r'clear\s*:'
]

# Break CSS into rules
# A rule is selector { ... } or @media ... { ... }
lines = css.split('\n')
for pattern in suspicious_patterns:
    print(f"\n==================== PATTERN: {pattern} ====================")
    matches = 0
    for i, line in enumerate(lines):
        if re.search(pattern, line, re.IGNORECASE):
            # Print context (e.g. 3 lines before and after)
            start = max(0, i - 4)
            end = min(len(lines), i + 4)
            block = '\n'.join([f"  {k+1}: {lines[k]}" for k in range(start, end)])
            print(f"--- Line {i+1} ---")
            print(block)
            matches += 1
            if matches >= 15:
                print(f"... and more ({pattern})")
                break


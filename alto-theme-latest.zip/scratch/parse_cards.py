with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_full.txt', 'r', encoding='utf-8') as f:
    text = f.read()

import re
# Look for gallery, embed, image, etc.
for match in re.finditer(r'kg-[\w-]+', text):
    print(match.group(0))


const { spawn } = require('child_process');

async function checkParents() {
  const url = 'http://localhost:2368/disney-workers-deputy-and-youth-coach-among-281-arrested-in-florida-human-trafficking-sting/';
  const chrome = spawn('C:/Program Files/Google/Chrome/Application/chrome.exe', [
    '--headless=new',
    '--remote-debugging-port=9254',
    '--window-size=1200,1600',
    url
  ]);

  await new Promise(r => setTimeout(r, 2500));
  const list = await (await fetch('http://127.0.0.1:9254/json')).json();
  const page = list.find(t => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);

  const send = (method, params = {}) => new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.id === id) {
        ws.removeEventListener('message', handler);
        resolve(data.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id, method, params }));
  });

  ws.onopen = async () => {
    await send('Runtime.enable');
    const res = await send('Runtime.evaluate', {
      expression: `(() => {
        const sel = ['html', 'body', '.site', '.site-content', '.content-area', '.site-main', '.single-post', '.gh-content', '.gh-canvas'];
        return sel.map(s => {
          const el = document.querySelector(s);
          if (!el) return { selector: s, missing: true };
          const comp = window.getComputedStyle(el);
          return {
            selector: s,
            overflow: comp.overflow,
            overflowX: comp.overflowX,
            overflowY: comp.overflowY,
            contain: comp.contain,
            contentVisibility: comp.contentVisibility,
            maxHeight: comp.maxHeight,
            minHeight: comp.minHeight,
            display: comp.display,
            position: comp.position,
            width: comp.width,
            transform: comp.transform
          };
        });
      })()`,
      returnByValue: true
    });

    console.log(JSON.stringify(res.result.value, null, 2));
    chrome.kill();
    process.exit(0);
  };
}

checkParents().catch(e => { console.error(e); process.exit(1); });


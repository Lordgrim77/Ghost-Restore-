with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\glassmorphism.css', 'r', encoding='utf-8') as f:
    text = f.read()

import re
rules = re.findall(r'([^{}]+)\{([^}]+)\}', text)

for sel, body in rules:
    if 'display: none' in body or 'visibility: hidden' in body or 'opacity: 0' in body:
        print("SELECTOR:")
        print(sel.strip())
        print("BODY:")
        print(body.strip()[:150])
        print("="*40)


import re

p = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\portal-theme.js'
with open(p, 'r', encoding='utf-8') as f:
    code = f.read()

# Let's inspect where cyan/blue is in portal-theme.js
# 1. ghostScript data-accent-color: change #38bdf8 to #ffffff
code = code.replace("'#38bdf8'", "'#ffffff'")
code = code.replace('"#38bdf8"', '"#ffffff"')
code = code.replace('#38bdf8', '#ffffff')
code = code.replace('#0284c7', '#000000')
code = code.replace('#0ea5e9', '#ffffff')
code = code.replace('#00f2fe', '#ffffff')

# 2. rgba(56, 189, 248, ...) replacements:
# In dark mode: white glows/borders: rgba(255, 255, 255, alpha)
# In light mode: black shadows/borders: rgba(0, 0, 0, alpha)
def replace_cyan_rgba(match):
    alpha = match.group(1).strip()
    return f'rgba(255, 255, 255, {alpha})'

code = re.sub(r'rgba\(\s*56\s*,\s*189\s*,\s*248\s*,\s*([^)]+)\)', replace_cyan_rgba, code)
code = re.sub(r'rgba\(\s*2\s*,\s*132\s*,\s*199\s*,\s*([^)]+)\)', 'rgba(0, 0, 0, \\1)', code)
code = re.sub(r'rgba\(\s*34\s*,\s*158\s*,\s*217\s*,\s*([^)]+)\)', replace_cyan_rgba, code)

# Look for comments or headers mentioning cyan/pink:
code = re.sub(r'Electric Cyan', 'Monochrome Pure White', code, flags=re.IGNORECASE)

with open(p, 'w', encoding='utf-8') as f:
    f.write(code)

print("Successfully updated portal-theme.js to pure Monochrome Black & White!")


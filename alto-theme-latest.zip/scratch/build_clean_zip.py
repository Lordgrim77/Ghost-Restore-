import os
import zipfile

src_dir = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto"
out_zip = r"C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\Ghost-Restore\alto-theme-latest.zip"

excluded_dirs = {'node_modules', 'scratch', '.git', '.github', 'dist'}
excluded_files = {'.DS_Store', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'AGENTS.md', 'CLAUDE.md'}

files_added = 0
with zipfile.ZipFile(out_zip, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(src_dir):
        # Exclude directories
        dirs[:] = [d for d in dirs if d not in excluded_dirs]
        for f in files:
            if f in excluded_files:
                continue
            full_path = os.path.join(root, f)
            rel_path = os.path.relpath(full_path, src_dir)
            # Use forward slashes exclusively
            zip_rel_path = rel_path.replace('\\', '/')
            zf.write(full_path, arcname=zip_rel_path)
            files_added += 1

print(f"Packed {files_added} files into {out_zip}")


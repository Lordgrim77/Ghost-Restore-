with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js', 'r', encoding='utf-8') as f:
    text = f.read()

import re
funcs = re.findall(r'function\s+([a-zA-Z0-9_$]+)\s*\(', text)
print("Named functions:", set(funcs))

# Look for querySelector or getElementById in main.min.js
selectors = re.findall(r'querySelector(?:All)?\([\'\"]([^\'\"]+)[\'\"]\)', text)
print("\nSelectors used in main.min.js:")
for s in set(selectors):
    print(" -", s)


with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('lightbox(".kg-image-card')
print(text[idx:idx+500])


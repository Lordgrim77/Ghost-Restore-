p = r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\assets\built\main.min.js'
with open(p, 'r', encoding='utf-8') as f:
    text = f.read()

target = 'e=t.getAttribute("height")||t.offsetHeight,i=t.getAttribute("width")||t.offsetWidth,e=("string"==typeof e?parseInt(e):e)/("string"==typeof i?parseInt(i):i)*100'
replacement = 'e=t.getAttribute("height")||t.offsetHeight||360,i=t.getAttribute("width")||t.offsetWidth||640,e=("string"==typeof e?parseInt(e):e)/("string"==typeof i?parseInt(i):i)*100,(!e||isNaN(e)||!isFinite(e)||e<5)?(e=56.25):0'

if target in text:
    text = text.replace(target, replacement)
    with open(p, 'w', encoding='utf-8') as f:
        f.write(text)
    print("Successfully patched main.min.js!")
else:
    print("Target NOT found in main.min.js!")


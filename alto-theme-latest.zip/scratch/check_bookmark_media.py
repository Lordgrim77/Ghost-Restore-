with open(r'C:\Users\LordgrimxDJay\.gemini\antigravity\scratch\ghost-blog\content\themes\alto\scratch\cards_css.txt', 'r', encoding='utf-8') as f:
    text = f.read()

import re
m = re.findall(r'@media[^{]+\{[^{}]*bookmark[^{}]*\{[^}]+\}[^}]*\}', text)
for r in m:
    print(r)
if not m:
    print("No media query found in cards.min.css for bookmark!")


/* eslint-disable no-shadow */

const logging = require('@tryghost/logging');
const fs = require('fs').promises;
const path = require('path');
const clsx = require('clsx');
/**
 * @param {string} url
 * @returns {boolean}
 */
function isUnsplashImage(url) {
  return /images\.unsplash\.com/.test(url);
}

/**
 * Parsing a link with `new URL()` percent-encodes replacement strings in its
 * path (`%%{uuid}%%` becomes `%%%7Buuid%7D%%`), which hides them from the
 * per-recipient replacements. The decoded string is HTML-escaped because the
 * result is written back into an `href` attribute.
 *
 * @param {URL} url
 * @returns {string}
 */
function restoreReplacementStrings(url) {
  return url.toString().replace(/%%%7B(.*?)%7D%%/gi, (encoded, replacement) => {
    try {
      return `%%{${escapeHtml(decodeURIComponent(replacement))}}%%`;
    } catch (e) {
      return encoded;
    }
  });
}
const { DateTime } = require('luxon');
const htmlToPlaintext = require('@tryghost/html-to-plaintext');
const { formatAddressForDelivery } = require('../../lib/mail/format-address-for-delivery');
const { getEmailDesign } = require('../../lib/email-rendering/email-design');
const { registerHelpers } = require('./helpers/register-helpers');
const crypto = require('crypto');
const { checkSegmentPostAccess, getPostAccessFilter } = require('../members/content-gating');
const { mobiledocToLexical } = require('@tryghost/kg-converters');
/** @import {TemplateDelegate} from 'handlebars' */

const DEFAULT_LOCALE = 'en-gb';
const CONTENT_IMAGES_PATH_WITHOUT_SIZE_REGEX = /\/content\/images\/(?!size\/)/;

/**
 * Wrapper function so that i18next-parser can find these strings.
 *
 * @template T
 * @param {T} x
 * @returns {T}
 */
const t = (x) => {
  return x;
};

const messages = {
  subscriptionStatus: {
    free: '',
    expired: t('Your subscription has expired.'),
    canceled: t(
      'Your subscription has been canceled and will expire on {date}. You can resume your subscription via your account settings.',
    ),
    active: t('Your subscription will renew on {date}.'),
    trial: t(
      'Your free trial ends on {date}, at which time you will be charged the regular price. You can always cancel before then.',
    ),
    complimentaryExpires: t('Your subscription will expire on {date}.'),
    complimentaryInfinite: '',
    giftExpires: t('Your subscription will expire on {date}.'),
  },
};

/**
 * @param {string} unsafe
 * @returns {string}
 */
function escapeHtml(unsafe) {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * @param {string} html
 * @returns {string}
 */
function fixOutlookChars(html) {
  return html
    .replace(/&apos;/g, '&#39;')
    .replace(/→/g, '&rarr;')
    .replace(/–/g, '&ndash;')
    .replace(/“/g, '&ldquo;')
    .replace(/”/g, '&rdquo;');
}

/**
 * @param {string} locale
 * @returns {boolean}
 */
function isValidLocale(locale) {
  try {
    // Attempt to create a DateTimeFormat with the locale
    new Intl.DateTimeFormat(locale);
    return true; // No error means it's a valid locale
  } catch (e) {
    return false; // RangeError means invalid locale
  }
}

/**
 * Builds a plain {visibility, tiers} shape from a Post model, for the shared
 * content-gating helpers (which operate on serialized post attributes).
 * @param {Post} post
 * @returns {{visibility: string, tiers: object[]|undefined}}
 */
function getPostGatingShape(post) {
  const tiersRelation = post.related && post.related('tiers');
  const tiers =
    tiersRelation && typeof tiersRelation.toJSON === 'function'
      ? tiersRelation.toJSON()
      : undefined;
  return {
    visibility: post.get('visibility'),
    tiers,
  };
}

/**
 * The NQL member filter selecting members WITHOUT access to a tier-restricted
 * post: members who hold none of the post's tiers. This is the exact complement
 * of the post's tier access filter (De Morgan over the OR of tiers). Free
 * members (no products) match this naturally.
 * @param {Post} post
 * @returns {string|null}
 */
function getNegatedTierFilter(post) {
  const tiers = getPostGatingShape(post).tiers || [];
  if (tiers.length === 0) {
    return null;
  }
  return tiers.map((tier) => `product:-'${tier.slug}'`).join('+');
}

/**
 * Returns 'status:free' / 'status:-free' identifying which free/paid audience a
 * segment renders for. Used ONLY for data-gh-segment card stripping, which is a
 * free/paid-only axis independent of tier access. Returns null for segments that
 * target a mixed/everyone audience (where no free/paid cards are present anyway).
 * @param {Segment} segment
 * @returns {string|null}
 */
function getSegmentStatus(segment) {
  if (!segment) {
    return null;
  }
  if (segment.includes('status:-free')) {
    return 'status:-free';
  }
  if (segment.includes('status:free')) {
    return 'status:free';
  }
  return null;
}

/**
 * Whether the members matched by a segment can read the post's gated content.
 * Delegates to the shared content-gating check so email and web gating stay in
 * sync. A null segment is an unsegmented render — the send pipeline only
 * produces one for posts without gated content, and API previews without a
 * memberSegment expect the full body — so it always has access.
 * @param {Post} post
 * @param {Segment} segment
 * @returns {boolean}
 */
function segmentHasPostAccess(post, segment) {
  const visibility = post.get('visibility');
  if (visibility !== 'paid' && visibility !== 'tiers') {
    return true;
  }
  if (!segment) {
    return true;
  }
  return checkSegmentPostAccess(getPostGatingShape(post), segment);
}

/**
 * @typedef {object} SegmentAudience
 * @prop {string|null} status - the free/paid audience axis ('status:free' /
 *   'status:-free', the data-gh-segment card vocabulary), null for mixed
 * @prop {boolean} hasPostAccess - whether this audience can read the post's
 *   gated content
 */

/**
 * @param {Readonly<Date>} date
 * @param {string} timezone
 * @param {string} [locale]
 * @returns {string}
 */
function formatDateLong(date, timezone, locale = DEFAULT_LOCALE) {
  return DateTime.fromJSDate(date).setZone(timezone).setLocale(locale).toLocaleString({
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

/**
 * @param {string} string
 * @returns {string}
 */
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Wrap `cheerio.load` with lazy loading.
 *
 * @param {Parameters<typeof cheerio.load>[0]} html
 * @return {ReturnType<typeof cheerio.load>}
 */
function cheerioLoad(html) {
  const cheerio = require('cheerio/slim');
  return cheerio.load(html);
}

/**
 * @typedef {string|null} Segment
 * @typedef {object} Post
 * @typedef {object} Newsletter
 */

/**
 * @typedef {object} MemberLike
 * @prop {string} id
 * @prop {string} uuid
 * @prop {string} email
 * @prop {string} name
 * @prop {'free'|'paid'|'comped'|'gift'} status
 * @prop {Date|null} createdAt This can be null if the member has been deleted for older email recipient rows
 * @prop {MemberLikeSubscription[]} subscriptions Required to get trial end / next renewal date / expire at date for paid member
 * @prop {MemberLikeTier[]} tiers Required to get the expiry date in case of a comped or gift member
 *
 * @typedef {object} MemberLikeSubscription
 * @prop {string} status
 * @prop {boolean} cancel_at_period_end
 * @prop {Date|null} trial_end_at
 * @prop {Date} current_period_end
 *
 * @typedef {object} MemberLikeTier
 * @prop {string} product_id
 * @prop {Date|null} expiry_at
 */

/**
 * @typedef {object} ReplacementDefinition
 * @prop {string} id
 * @prop {RegExp} token
 * @prop {(member: MemberLike) => string} getValue
 * @prop {boolean} [trusted] - Value is server-generated, so it is inserted into the
 *   html body as-is instead of being HTML-escaped. Defaults to false (escaped).
 */

/**
 * @typedef {object} EmailRenderOptions
 * @prop {boolean} clickTrackingEnabled
 */

/**
 * @typedef {object} EmailBody
 * @prop {string} html
 * @prop {string} plaintext
 * @prop {ReplacementDefinition[]} replacements
 */

class EmailRenderer {
  #settingsCache;
  #settingsHelpers;

  #renderers;

  #imageSize;
  #urlUtils;
  #getPostUrl;
  #getRequiredUrlRelations;
  #storageUtils;

  #linkReplacer;
  #linkTracking;
  #memberAttributionService;
  #outboundLinkTagger;
  #audienceFeedbackService;
  #emailAddressService;
  #labs;
  #models;
  #t;
  #dir;

  /** @type {undefined | Promise<TemplateDelegate>} */
  #compiledHandlebarsRendererPromise;

  /**
   * @param {object} dependencies
   * @param {object} dependencies.settingsCache
   * @param {{getNoReplyAddress(): string, getMembersSupportAddress(): string, getMembersValidationKey(): string, createUnsubscribeUrl(uuid: string, options: object): string}} dependencies.settingsHelpers
   * @param {object} dependencies.renderers
   * @param {{render(object, options): Promise<string>}} dependencies.renderers.lexical
   * @param {{getCachedImageSizeFromUrl(url: string): Promise<{url: string, width: number, height: number} | null>}} dependencies.imageSize
   * @param {{urlFor(type: string, optionsOrAbsolute, absolute): string, isSiteUrl(url, context): boolean}} dependencies.urlUtils
   * @param {{isLocalImage(url: string): boolean, isInternalImage(url: string): boolean}} dependencies.storageUtils
   * @param {(post: Post) => string} dependencies.getPostUrl
   * @param {() => string[]} [dependencies.getRequiredUrlRelations] Post relations the live routes need loaded to generate URLs (lazy routing); defaults to none
   * @param {object} dependencies.linkReplacer
   * @param {object} dependencies.linkTracking
   * @param {object} dependencies.memberAttributionService
   * @param {object} dependencies.audienceFeedbackService
   * @param {object} dependencies.emailAddressService
   * @param {object} dependencies.outboundLinkTagger
   * @param {object} dependencies.labs
   * @param {{Post: object}} dependencies.models
   * @param {Function} dependencies.t
   * @param {(locale: string) => 'rtl' | 'ltr'} dependencies.dir Returns 'rtl' or 'ltr' for a given locale (i18next's `i18n.dir`)
   */
  constructor({
    settingsCache,
    settingsHelpers,
    renderers,
    imageSize,
    urlUtils,
    storageUtils,
    getPostUrl,
    getRequiredUrlRelations = () => [],
    linkReplacer,
    linkTracking,
    memberAttributionService,
    audienceFeedbackService,
    emailAddressService,
    outboundLinkTagger,
    labs,
    models,
    t,
    dir,
  }) {
    this.#settingsCache = settingsCache;
    this.#settingsHelpers = settingsHelpers;
    this.#renderers = renderers;
    this.#imageSize = imageSize;
    this.#urlUtils = urlUtils;
    this.#storageUtils = storageUtils;
    this.#getPostUrl = getPostUrl;
    this.#getRequiredUrlRelations = getRequiredUrlRelations;
    this.#linkReplacer = linkReplacer;
    this.#linkTracking = linkTracking;
    this.#memberAttributionService = memberAttributionService;
    this.#audienceFeedbackService = audienceFeedbackService;
    this.#emailAddressService = emailAddressService;
    this.#outboundLinkTagger = outboundLinkTagger;
    this.#labs = labs;
    this.#models = models;
    this.#t = t;
    this.#dir = dir;
  }

  getSubject(post, isTestEmail = false) {
    const subject = post.related('posts_meta')?.get('email_subject') || post.get('title');
    return isTestEmail ? `[TEST] ${subject}` : subject;
  }

  #getRawFromAddress(post, newsletter) {
    // Pass the raw name through; formatAddressForDelivery() is the single
    // point that escapes it for the RFC5322 quoted-string From header. Escaping
    // here too would double-escape (e.g. a title containing a double quote).
    let senderName = this.#settingsCache.get('title') || '';
    if (newsletter.get('sender_name')) {
      senderName = newsletter.get('sender_name');
    }

    let fromAddress = this.#settingsHelpers.getNoReplyAddress();
    if (newsletter.get('sender_email')) {
      fromAddress = newsletter.get('sender_email');
    }

    // For local development, rewrite the fromAddress to a proper domain
    if (process.env.NODE_ENV !== 'production') {
      if (/@localhost$/.test(fromAddress) || /@ghost.local$/.test(fromAddress)) {
        const localAddress = 'localhost@example.com';
        logging.warn(`Rewriting bulk email from address ${fromAddress} to ${localAddress}`);
        fromAddress = localAddress;
      }
    }
    return {
      address: fromAddress,
      name: senderName || undefined,
    };
  }

  // Locale is user-input, so we need to ensure it's valid
  #getValidLocale() {
    let locale = this.#settingsCache.get('locale') || DEFAULT_LOCALE;

    // Remove any trailing whitespace
    locale = locale.trim();

    // If the locale is just "en", or is not valid, revert to default
    if (locale === 'en' || !isValidLocale(locale)) {
      locale = DEFAULT_LOCALE;
    }

    return locale;
  }

  /**
   * @param {Post} post
   * @param {Newsletter} newsletter
   * @param {boolean} [useFallbackAddress]
   * @returns {string|null}
   */
  getFromAddress(post, newsletter, useFallbackAddress = false) {
    // Clean from address to ensure DMARC alignment
    const addresses = this.#emailAddressService.getAddress(
      {
        from: this.#getRawFromAddress(post, newsletter),
      },
      { useFallbackAddress },
    );

    return formatAddressForDelivery(addresses.from);
  }

  /**
   * @param {Post} post
   * @param {Newsletter} newsletter
   * @param {boolean} [useFallbackAddress]
   * @returns {string|null}
   */
  getReplyToAddress(post, newsletter, useFallbackAddress = false) {
    const replyToAddress = newsletter.get('sender_reply_to');

    if (replyToAddress === 'support') {
      return this.#settingsHelpers.getMembersSupportAddress();
    }

    if (replyToAddress === 'newsletter' && !this.#emailAddressService.managedEmailEnabled) {
      return this.getFromAddress(post, newsletter, useFallbackAddress);
    }

    const addresses = this.#emailAddressService.getAddress(
      {
        from: this.#getRawFromAddress(post, newsletter),
        replyTo: replyToAddress === 'newsletter' ? undefined : { address: replyToAddress },
      },
      { useFallbackAddress },
    );

    if (addresses.replyTo) {
      return formatAddressForDelivery(addresses.replyTo);
    }
    return null;
  }

  /**
		Returns all the segments that we need to render the email for because they have different content.
        WARNING: The sum of all the returned segments should always include all the members. Those members are later limited if needed based on the recipient filter of the email.
        @param {Post} post
        @returns {Promise<Segment[]>}
	*/
  async getSegments(post) {
    const allowedSegments = ['status:free', 'status:-free'];
    const html = await this.renderPostBaseHtml(post);

    const hasPaywall = html.indexOf('<!--members-only-->') !== -1;

    const $ = cheerioLoad(html);
    const cardSegments = [
      ...new Set(
        $('[data-gh-segment]')
          .get()
          .map((el) => el.attribs['data-gh-segment']),
      ),
    ].filter((segment) => allowedSegments.includes(segment));
    const hasCards = cardSegments.length > 0;

    if (!hasPaywall && !hasCards) {
      // No difference in email content between members
      return [null];
    }

    // Tier-restricted posts split recipients by tier access (not just
    // free/paid) so members on a tier that can't read this post get the
    // public preview + paywall, exactly as they do on the web.
    if (post.get('visibility') === 'tiers' && hasPaywall) {
      const accessFilter = getPostAccessFilter(getPostGatingShape(post));
      const noAccessFilter = getNegatedTierFilter(post);

      if (accessFilter && noAccessFilter) {
        if (hasCards) {
          // free/paid cards in the preview need free vs paid rendering
          // within the no-access audience -> three render variants
          return [
            'status:free',
            `status:-free+(${accessFilter})`,
            `status:-free+(${noAccessFilter})`,
          ];
        }
        // free members hold no products, so they fall into no-access
        return [accessFilter, noAccessFilter];
      }
      // misconfigured tiers post (no tiers) -> fall through to free/paid
    }

    // We have different content between free and paid members
    return allowedSegments;
  }

  /**
   * Maps a preview audience (a member status, optionally narrowed to a
   * single tier) onto the segment the send pipeline renders for that
   * audience, so previews match what members receive. For a tier-restricted
   * post the paid audience maps to the tier access segment (the access
   * variant getSegments produces): paid members on the post's tiers get the
   * full content. A null status is an unsegmented render (the full body).
   * @param {Post} post
   * @param {'free'|'paid'|null} memberStatus
   * @param {string} [tierSlug] - narrow the paid audience to a single tier
   * @returns {Segment}
   */
  getSegmentForAudience(post, memberStatus, tierSlug) {
    if (memberStatus === 'free') {
      return 'status:free';
    }
    if (memberStatus !== 'paid') {
      return null;
    }
    if (tierSlug) {
      const escapedSlug = tierSlug.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      return `status:-free+product:'${escapedSlug}'`;
    }
    if (post.get('visibility') === 'tiers') {
      const accessFilter = getPostAccessFilter(getPostGatingShape(post));
      if (accessFilter) {
        return `status:-free+(${accessFilter})`;
      }
    }
    return 'status:-free';
  }

  /**
   * Interprets a member segment into the audience facts rendering needs.
   * Segments are persisted on email batches and arrive free-form via the
   * preview APIs, so audience semantics must be derivable from the string —
   * this is the only place that derives them; everything downstream reads the
   * descriptor instead of re-parsing the segment.
   * @param {Post} post
   * @param {Segment} segment
   * @returns {SegmentAudience}
   */
  describeSegment(post, segment) {
    return {
      status: getSegmentStatus(segment),
      hasPostAccess: segmentHasPostAccess(post, segment),
    };
  }

  async renderPostBaseHtml(post, newsletter) {
    const postUrl = this.#getPostUrl(post);

    // posts are migrated to lexical on save, but legacy content may still be stored as
    // mobiledoc - convert it to lexical so it can be rendered.
    const lexical = post.get('lexical') || mobiledocToLexical(post.get('mobiledoc'));

    const html = await this.#renderers.lexical.render(lexical, {
      target: 'email',
      postUrl,
      design: this.#getEmailDesign(newsletter),
    });
    return html;
  }

  /**
   *
   * @param {Post} post
   * @param {Newsletter} newsletter
   * @param {Segment} segment
   * @param {EmailRenderOptions} options
   * @returns {Promise<EmailBody>}
   */
  async renderBody(post, newsletter, segment, options) {
    const audience = this.describeSegment(post, segment);

    let html = await this.renderPostBaseHtml(post, newsletter);

    // Paywall and members only content handling
    const isPaidPost = post.get('visibility') === 'paid' || post.get('visibility') === 'tiers';
    const membersOnlyIndex = html.indexOf('<!--members-only-->');
    const hasMembersOnlyContent = membersOnlyIndex !== -1;
    let addPaywall = false;

    // Members without access to the gated content (free members, or members
    // on a tier that can't read this post) get the public preview + paywall,
    // exactly as on the web.
    if (isPaidPost && hasMembersOnlyContent && !audience.hasPostAccess) {
      // Add paywall
      addPaywall = true;

      // Remove the members-only content
      html = html.slice(0, membersOnlyIndex);
    }

    let $ = cheerioLoad(html);

    // Remove parts of the HTML not applicable to the current segment - We do this
    // before rendering the template as the preheader for the email may be generated
    // using the HTML and we don't want to include content that should not be
    // visible depending on the segment
    // data-gh-segment cards are a free/paid-only axis, independent of tier
    // access, so they match against the audience's status
    $('[data-gh-segment]')
      .get()
      .forEach((node) => {
        // TODO: replace with NQL interpretation
        if (node.attribs['data-gh-segment'] !== audience.status) {
          $(node).remove();
        } else {
          // Getting rid of the attribute for a cleaner html output
          $(node).removeAttr('data-gh-segment');
        }
      });

    html = $.html();

    const templateData = await this.getTemplateData({
      post,
      newsletter,
      html,
      addPaywall,
      audience,
    });
    html = await this.renderTemplate(templateData);

    // We pass the base option to the link replacer so relative links are replaced with absolute links, relative to this base url
    const base = templateData.post.url;

    // Link tracking
    if (options.clickTrackingEnabled) {
      html = await this.#linkReplacer.replace(
        html,
        async (url, originalPath) => {
          if (originalPath.startsWith('%%{') && originalPath.endsWith('}%%')) {
            // Don't add the base url to replacement strings
            return originalPath;
          }

          // Ignore empty hashtags (used as a hack for email addresses to prevent making them clickable)
          if (originalPath === '#') {
            return originalPath;
          }

          // Skip tracking for links that contain replacement patterns other than %%{uuid}%%
          // %%{uuid}%% is substituted at redirect time via the ?m= parameter, but other
          // patterns (e.g. %%{key}%%) require direct Mailgun substitution
          const urlStr = url.toString();
          const withoutUuid = urlStr.replace(/%%\{uuid\}%%/g, '');
          if (/%%\{[^}]+\}%%/.test(withoutUuid)) {
            return urlStr;
          }

          // Add newsletter source attribution
          const isSite = this.#urlUtils.isSiteUrl(url);

          if (isSite) {
            // Add newsletter name as ref to the URL
            url = this.#outboundLinkTagger.addToUrl(url, newsletter);

            // Only add post attribution to our own site (because external sites could/should not process this information)
            url = this.#memberAttributionService.addPostAttributionTracking(url, post);
          } else {
            // Add email source attribution without the newsletter name
            url = this.#outboundLinkTagger.addToUrl(url);
          }

          // Don't add tracking to the Powered by Ghost badge
          if (
            url.hostname === 'ghost.org' &&
            url.pathname === '/' &&
            url.searchParams.get('via') === 'pbg-newsletter'
          ) {
            return url.toString();
          }

          // Add link click tracking
          url = await this.#linkTracking.service.addTrackingToUrl(url, post, '--uuid--');

          // We need to convert to a string at this point, because we need invalid string characters in the URL
          const str = url.toString().replace(/--uuid--/g, '%%{uuid}%%');
          return str;
        },
        { base },
      );
    } else {
      // Replace all relative links to absolute ones
      html = await this.#linkReplacer.replace(
        html,
        (url, originalPath) => {
          if (originalPath.startsWith('%%{') && originalPath.endsWith('}%%')) {
            // Don't add the base url to replacement strings
            return originalPath;
          }

          // Ignore empty hashtags (used as a hack for email addresses to prevent making them clickable)
          if (originalPath === '#') {
            return originalPath;
          }
          return restoreReplacementStrings(url);
        },
        { base },
      );
    }

    // Record the original image width and height attributes before inlining the styles with juice
    // If any images have `width: auto` or `height: auto` set via CSS,
    // juice will explicitly set the width/height attributes to `auto` on the <img /> tag
    // This is not supported by Outlook, so we need to reset the width/height attributes to the original values
    // Other clients will ignore the width/height attributes and use the inlined CSS instead
    $ = cheerioLoad(html);
    const originalImageSizes = $('img')
      .get()
      .map((image) => {
        const src = image.attribs.src;
        const width = image.attribs.width;
        const height = image.attribs.height;
        return { src, width, height };
      });

    // Add a class to each figcaption so we can style them in the email
    $('figcaption').each((i, elem) => !!$(elem).addClass('kg-card-figcaption'));
    html = $.html();

    // Juice HTML (inline CSS)
    const juice = require('juice');
    // resolveCSSVariables crashes on nameless declarations in user-authored style attributes
    html = juice(html, {
      inlinePseudoElements: true,
      removeStyleTags: true,
      resolveCSSVariables: false,
    });

    // happens after inlining of CSS so we can change element types without worrying about styling
    $ = cheerioLoad(html);

    // Reset any `height="auto"` or `width="auto"` attributes to their original values before inlining CSS
    const imageTags = $('img').get();
    for (let i = 0; i < imageTags.length; i += 1) {
      // There shouldn't be any issues with consistency between these two lists, but just in case...
      if (imageTags[i].attribs.src === originalImageSizes[i].src) {
        // if the image width or height is set to 'auto', reset to its original value
        if (imageTags[i].attribs.width === 'auto' && originalImageSizes[i].width) {
          imageTags[i].attribs.width = originalImageSizes[i].width;
        }
        if (imageTags[i].attribs.height === 'auto' && originalImageSizes[i].height) {
          imageTags[i].attribs.height = originalImageSizes[i].height;
        }
      }
    }

    // force all links to open in new tab
    $('a').attr('target', '_blank');

    // convert figure and figcaption to div so that Outlook applies margins
    $('figure, figcaption').each((i, elem) => !!(elem.tagName = 'div'));

    // Remove duplicate black/white images (CSS based solution not working in Outlook)
    if (templateData.backgroundIsDark) {
      $('img.is-light-background').each((i, elem) => {
        $(elem).remove();
      });
    } else {
      $('img.is-dark-background').each((i, elem) => {
        $(elem).remove();
      });
    }

    // Convert DOM back to HTML
    html = $.html(); // () Fix for vscode syntax highlighter

    // Personalize the entire name row after CSS inlining so an absent name also
    // removes its label and markup, including in clients that discard stylesheets.
    const nameRow = $('.subscription-details .subscription-name');
    const nameHtml = nameRow.length ? $.html(nameRow) : '';
    const nameText = nameRow.text();
    const plaintextHtml = nameHtml
      ? html.replace(nameHtml, '<p>%%{subscription_name_text}%%</p>')
      : html;
    if (nameHtml) {
      html = html.replace(nameHtml, '%%{subscription_name_html}%%');
    }

    // Replacement strings
    const replacementDefinitions = this.buildReplacementDefinitions({
      html,
      newsletterUuid: newsletter.get('uuid'),
    });

    if (nameHtml) {
      const outlookNameHtml = fixOutlookChars(nameHtml);
      replacementDefinitions.push(
        {
          id: 'subscription_name_html',
          token: /%%\{subscription_name_html\}%%/g,
          getValue: (member) =>
            member.name?.trim()
              ? outlookNameHtml.replace('%%{name}%%', () => escapeHtml(member.name))
              : '',
          trusted: true, // Member name is already HTML-escaped
        },
        {
          id: 'subscription_name_text',
          token: /%%\{subscription_name_text\}%%/g,
          getValue: (member) =>
            member.name?.trim() ? nameText.replace('%%{name}%%', () => member.name) : '',
        },
      );
    }

    // TODO: normalizeReplacementStrings (replace unsupported replacement strings)

    // Convert HTML to plaintext
    const plaintext = htmlToPlaintext.email(plaintextHtml);

    // Fix any unsupported chars in Outlook
    html = fixOutlookChars(html);

    return {
      html,
      plaintext,
      replacements: replacementDefinitions,
    };
  }

  /**
   * Takes a member and newsletter uuid. Returns the url that should be used to unsubscribe
   * In case of no member uuid, generates the preview unsubscribe url - `?preview=1`
   *
   * @param {string} [uuid] member uuid
   * @param {Object} [options]
   * @param {string} [options.newsletterUuid] newsletter uuid
   * @param {boolean} [options.comments] Unsubscribe from comment emails
   * @returns {string}
   */
  createUnsubscribeUrl(uuid, options = {}) {
    return this.#settingsHelpers.createUnsubscribeUrl(uuid, options);
  }

  /**
   * @returns {string}
   */
  createManageAccountUrl() {
    const siteUrl = this.#urlUtils.urlFor('home', true);
    const url = new URL(siteUrl);
    url.hash = '#/portal/account';

    return url.href;
  }

  /**
   * Returns whether a paid member is trialing a subscription
   *
   * @param {Readonly<MemberLike>} member
   * @returns {boolean}
   */
  isMemberTrialing(member) {
    // Do we have an active subscription?
    if (member.status === 'paid') {
      const activeSubscription = member.subscriptions.find((subscription) => {
        return subscription.status === 'trialing';
      });

      if (!activeSubscription) {
        return false;
      }

      // Translate to a human readable string
      if (
        activeSubscription.trial_end_at &&
        activeSubscription.trial_end_at > new Date() &&
        activeSubscription.status === 'trialing'
      ) {
        return true;
      }
    }

    return false;
  }

  /**
   * @param {Readonly<MemberLike>} member
   * @returns {string}
   */
  getMemberStatusText(member) {
    const t = this.#t;
    const locale = this.#getValidLocale();

    if (member.status === 'free') {
      // Not really used, but as a backup
      return t(messages.subscriptionStatus.free);
    }

    if (member.status === 'gift') {
      const expires = member.tiers[0]?.expiry_at ?? null;
      if (expires) {
        const timezone = this.#settingsCache.get('timezone');
        const date = formatDateLong(expires, timezone, locale);
        return t(messages.subscriptionStatus.giftExpires, { date });
      }
      return '';
    }

    // Do we have an active subscription?
    if (member.status === 'paid') {
      let activeSubscription =
        member.subscriptions.find((subscription) => {
          return subscription.status === 'active';
        }) ??
        member.subscriptions.find((subscription) => {
          return ['active', 'trialing', 'unpaid', 'past_due'].includes(subscription.status);
        });

      if (!activeSubscription && !member.tiers.length) {
        // No subscription?
        return t(messages.subscriptionStatus.expired);
      }

      if (!activeSubscription) {
        if (!member.tiers[0]?.expiry_at) {
          return t(messages.subscriptionStatus.complimentaryInfinite);
        }
        // Create one manually that is expiring
        activeSubscription = {
          cancel_at_period_end: true,
          current_period_end: member.tiers[0].expiry_at,
          status: 'active',
          trial_end_at: null,
        };
      }
      const timezone = this.#settingsCache.get('timezone');
      // Translate to a human readable string
      if (
        activeSubscription.trial_end_at &&
        activeSubscription.trial_end_at > new Date() &&
        activeSubscription.status === 'trialing'
      ) {
        const date = formatDateLong(activeSubscription.trial_end_at, timezone, locale);
        return t(messages.subscriptionStatus.trial, { date });
      }

      const date = formatDateLong(activeSubscription.current_period_end, timezone, locale);
      if (activeSubscription.cancel_at_period_end) {
        return t(messages.subscriptionStatus.canceled, { date });
      }
      return t(messages.subscriptionStatus.active, { date });
    }

    const expires = member.tiers[0]?.expiry_at ?? null;

    if (expires) {
      const timezone = this.#settingsCache.get('timezone');
      const date = formatDateLong(expires, timezone, locale);
      return t(messages.subscriptionStatus.complimentaryExpires, { date });
    }

    return t(messages.subscriptionStatus.complimentaryInfinite);
  }

  /**
   * Note that we only look in HTML because plaintext and HTML are essentially the same content
   * @returns {ReplacementDefinition[]}
   */
  buildReplacementDefinitions({ html, newsletterUuid }) {
    const t = this.#t; // es-lint-disable-line no-shadow
    const locale = this.#getValidLocale();

    const baseDefinitions = [
      {
        id: 'unsubscribe_url',
        getValue: (member) => {
          return this.createUnsubscribeUrl(member.uuid, { newsletterUuid });
        },
        trusted: true, // Server-generated URL, must not be HTML-escaped
      },
      {
        id: 'manage_account_url',
        getValue: () => {
          return this.createManageAccountUrl();
        },
        trusted: true, // Server-generated URL, must not be HTML-escaped
      },
      {
        id: 'uuid',
        getValue: (member) => {
          return member.uuid;
        },
        trusted: true, // Server-generated identifier
      },
      {
        id: 'key',
        getValue: (member) => {
          return crypto
            .createHmac('sha256', this.#settingsHelpers.getMembersValidationKey())
            .update(member.uuid)
            .digest('hex');
        },
        trusted: true, // Server-generated hmac
      },
      {
        id: 'first_name',
        getValue: (member) => {
          return member.name?.split(' ')[0];
        },
      },
      {
        id: 'name',
        getValue: (member) => {
          return member.name;
        },
      },
      {
        id: 'email',
        getValue: (member) => {
          return member.email;
        },
      },
      {
        id: 'created_at',
        getValue: (member) => {
          const timezone = this.#settingsCache.get('timezone');
          return member.createdAt ? formatDateLong(member.createdAt, timezone, locale) : '';
        },
      },
      {
        id: 'status',
        getValue: (member) => {
          if (member.status === 'comped') {
            return t('complimentary');
          }
          if (this.isMemberTrialing(member)) {
            return t('trialing');
          }
          // other possible statuses: t('free'), t('paid') //
          return t(member.status);
        },
      },
      {
        //TODO i18n
        id: 'status_text',
        getValue: (member) => {
          return this.getMemberStatusText(member);
        },
      },
      // List unsubscribe header to unsubcribe in one-click
      {
        id: 'list_unsubscribe',
        getValue: (member) => {
          return this.createUnsubscribeUrl(member.uuid, { newsletterUuid });
        },
        required: true, // Used in email headers
        trusted: true, // Server-generated URL, must not be HTML-escaped
      },
      // Unique ID used for ad images to bypass ESP image proxies
      {
        id: 'uniqueid',
        getValue: () => {
          return crypto.randomUUID();
        },
        trusted: true, // Server-generated identifier
      },
    ];

    // Now loop through all the definenitions to see which ones are actually used + to add fallbacks if needed
    const EMAIL_REPLACEMENT_REGEX = /%%\{(.*?)\}%%/g;
    const REPLACEMENT_STRING_REGEX =
      /^(?<recipientProperty>\w+?)(?:,? *(?:"|&quot;)(?<fallback>.*?)(?:"|&quot;))?$/;

    // Stores the definitions that we are actually going to use
    const replacements = [];

    let result;
    while ((result = EMAIL_REPLACEMENT_REGEX.exec(html)) !== null) {
      const [replacementMatch, replacementStr] = result;

      // Did we already found this match and added it to the replacements array?
      if (replacements.find((r) => r.id === replacementStr)) {
        continue;
      }
      const match = replacementStr.match(REPLACEMENT_STRING_REGEX);

      if (match) {
        const { recipientProperty, fallback } = match.groups;
        const definition = baseDefinitions.find((d) => d.id === recipientProperty);

        if (definition) {
          replacements.push({
            id: replacementStr,
            originalId: recipientProperty,
            token: new RegExp(
              escapeRegExp(replacementMatch).replace(/(?:"|&quot;)/g, '(?:"|&quot;)'),
              'g',
            ),
            getValue: fallback
              ? (member) => definition.getValue(member) || fallback
              : definition.getValue,
            trusted: definition.trusted === true,
          });
        }
      }
    }

    // Add all required replacements
    for (const definition of baseDefinitions) {
      if (definition.required && !replacements.find((r) => r.id === definition.id)) {
        replacements.push({
          id: definition.id,
          originalId: definition.id,
          token: new RegExp(`%%\\{${definition.id}\\}%%`, 'g'),
          getValue: definition.getValue,
          trusted: definition.trusted === true,
        });
      }
    }

    // Now loop any replacements with possible invalid characters and replace them with a clean id
    let counter = 1;
    for (const replacement of replacements) {
      if (replacement.id.match(/[^a-zA-Z0-9_]/)) {
        counter += 1;
        replacement.id = replacement.originalId + '_' + counter;
      }
      delete replacement.originalId;
    }
    return replacements;
  }

  getLabs() {
    return this.#labs;
  }

  /** @returns {Promise<TemplateDelegate>} */
  async #compileHandlebarsRenderer() {
    const labs = this.getLabs();
    const handlebars = require('handlebars').create();

    registerHelpers(handlebars, labs, this.#t);

    const emailPartials = path.join(__dirname, '..', '..', 'lib', 'email-rendering', 'partials');
    const emailTemplates = path.join(__dirname, 'email-templates');

    const [
      baseStylesSource,
      cardStylesSource,
      contentStylesSource,
      emailWrapperSource,
      feedbackButtonPartial,
      htmlTemplateSource,
      latestPostsPartial,
      paywallPartial,
      stylesPartialSource,
    ] = await Promise.all([
      fs.readFile(path.join(emailPartials, 'base-styles.hbs'), 'utf8'),
      fs.readFile(path.join(emailPartials, 'card-styles.hbs'), 'utf8'),
      fs.readFile(path.join(emailPartials, 'content-styles.hbs'), 'utf8'),
      fs.readFile(path.join(emailPartials, 'email-wrapper.hbs'), 'utf8'),
      fs.readFile(path.join(emailTemplates, 'partials', 'feedback-button.hbs'), 'utf8'),
      fs.readFile(path.join(emailTemplates, 'template.hbs'), 'utf8'),
      fs.readFile(path.join(emailTemplates, 'partials', 'latest-posts.hbs'), 'utf8'),
      fs.readFile(path.join(emailTemplates, 'partials', 'paywall.hbs'), 'utf8'),
      fs.readFile(path.join(emailTemplates, 'partials', 'styles.hbs'), 'utf8'),
    ]);

    handlebars.registerPartial('baseStyles', baseStylesSource);
    handlebars.registerPartial('cardStyles', cardStylesSource);
    handlebars.registerPartial('contentStyles', contentStylesSource);
    handlebars.registerPartial('emailWrapper', emailWrapperSource);
    handlebars.registerPartial('feedbackButton', feedbackButtonPartial);
    handlebars.registerPartial('latestPosts', latestPostsPartial);
    handlebars.registerPartial('paywall', paywallPartial);
    handlebars.registerPartial('styles', stylesPartialSource);

    return handlebars.compile(htmlTemplateSource);
  }

  /** @returns {Promise<TemplateDelegate>} */
  #getCompiledHandlebarsRenderer() {
    if (!this.#compiledHandlebarsRendererPromise) {
      this.#compiledHandlebarsRendererPromise = this.#compileHandlebarsRenderer();
    }
    return this.#compiledHandlebarsRendererPromise;
  }

  /**
   * @param {unknown} data
   * @returns {Promise<string>}
   */
  async renderTemplate(data) {
    const renderTemplate = await this.#getCompiledHandlebarsRenderer();
    return renderTemplate(data);
  }

  /**
   * @param {Newsletter} newsletter
   * @returns {ReturnType<typeof getEmailDesign>}
   */
  #getEmailDesign(newsletter) {
    return getEmailDesign({
      accentColor: this.#settingsCache?.get('accent_color'),
      backgroundColor: newsletter?.get('background_color'),
      buttonColor: newsletter?.get('button_color'),
      buttonCorners: newsletter?.get('button_corners'),
      buttonStyle: newsletter?.get('button_style'),
      dividerColor: newsletter?.get('divider_color'),
      headerBackgroundColor: newsletter?.get('header_background_color'),
      imageCorners: newsletter?.get('image_corners'),
      linkColor: newsletter?.get('link_color'),
      linkStyle: newsletter?.get('link_style'),
      postTitleColor: newsletter?.get('post_title_color'),
      sectionTitleColor: newsletter?.get('section_title_color'),
      titleFontWeight: newsletter?.get('title_font_weight'),
    });
  }

  /**
   * Get email preheader text from post model
   * @param {Post} postModel
   * @param {SegmentAudience} audience
   * @param {string} html
   * @returns {string}
   */
  #getEmailPreheader(postModel, audience, html) {
    let plaintext = postModel.get('plaintext');
    const customExcerpt = postModel.get('custom_excerpt');
    if (customExcerpt) {
      return customExcerpt;
    } else {
      if (plaintext) {
        // The plaintext field on the model may contain gated content
        // the audience can't read, so regenerate from the provided
        // HTML (already gated) whenever this audience lacks access
        if (audience.status === 'status:free' || !audience.hasPostAccess) {
          plaintext = htmlToPlaintext.email(html);
        }
        return plaintext.substring(0, 500);
      } else {
        return `${postModel.get('title')} – `;
      }
    }
  }

  truncateText(text, maxLength) {
    if (text && text.length > maxLength) {
      return text.substring(0, maxLength - 1).trim() + '…';
    } else {
      return text ?? '';
    }
  }

  /**
   * @param {*} text
   * @param {number} maxLength
   * @param {number} maxLengthMobile should be smaller than maxLength
   * @returns {string}
   */
  truncateHtml(text, maxLength, maxLengthMobile) {
    if (!maxLengthMobile || maxLength <= maxLengthMobile) {
      return escapeHtml(this.truncateText(text, maxLength));
    }
    if (text && text.length > maxLengthMobile) {
      let ellipsis = '';
      let desktopEnd = text.length;

      if (text.length > maxLengthMobile && text.length <= maxLength) {
        ellipsis = '<span class="hide-desktop">…</span>';
      } else if (text.length > maxLength) {
        ellipsis = '…';
        desktopEnd = maxLength - 1;
      }

      return (
        escapeHtml(text.substring(0, maxLengthMobile - 1)) +
        '<span class="desktop-only">' +
        escapeHtml(text.substring(maxLengthMobile - 1, desktopEnd)) +
        '</span>' +
        ellipsis
      );
    } else {
      return escapeHtml(text ?? '');
    }
  }

  /**
   * @private
   * @param {object} options
   * @param {Post} options.post
   * @param {Newsletter} options.newsletter
   * @param {string} options.html
   * @param {boolean} options.addPaywall
   * @param {SegmentAudience} options.audience
   */
  async getTemplateData({ post, newsletter, html, addPaywall, audience }) {
    const emailDesign = this.#getEmailDesign(newsletter);

    const { href: headerImage, width: headerImageWidth } = await this.limitImageWidth(
      newsletter.get('header_image'),
    );
    const {
      href: postFeatureImage,
      width: postFeatureImageWidth,
      height: postFeatureImageHeight,
    } = await this.limitImageWidth(post.get('feature_image'));

    const timezone = this.#settingsCache.get('timezone');
    const locale = this.#getValidLocale();
    const publishedAt = (
      post.get('published_at') ? DateTime.fromJSDate(post.get('published_at')) : DateTime.local()
    )
      .setZone(timezone)
      .setLocale(locale)
      .toLocaleString({
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });

    let authors;
    const postAuthors = await post.getLazyRelation('authors');
    if (postAuthors?.models) {
      if (postAuthors.models.length <= 2) {
        authors = postAuthors.models.map((author) => author.get('name')).join(' & ');
      } else {
        authors = `${postAuthors.models[0].get('name')} & ${postAuthors.models.length - 1} others`;
      }
    }

    const postUrl = this.#getPostUrl(post);
    const hasEmailOnlyFlag = post.related('posts_meta')?.get('email_only') ?? false;
    const showShareButton = newsletter.get('show_share_button') && !hasEmailOnlyFlag;
    const shareUrl = new URL(postUrl);
    shareUrl.hash = '/share';

    // Signup URL is the post url with a hash added to it
    const signupUrl = new URL(postUrl);
    signupUrl.hash = `/portal/signup`;

    // Audience feedback — durable, id-based links resolved to the post's
    // current URL at click time so they survive slug changes
    const positiveLink = this.#audienceFeedbackService.buildEmailLink(post, 1);
    const negativeLink = this.#audienceFeedbackService.buildEmailLink(post, 0);

    const commentUrl = new URL(postUrl);
    commentUrl.hash = '#ghost-comments-root';

    const hasFeedbackButtons = newsletter.get('feedback_enabled');
    const showCommentCta =
      newsletter.get('show_comment_cta') &&
      this.#settingsCache.get('comments_enabled') !== 'off' &&
      !hasEmailOnlyFlag;
    const feedbackButtonCount =
      (hasFeedbackButtons ? 2 : 0) + (showCommentCta ? 1 : 0) + (showShareButton ? 1 : 0);
    const feedbackButtonCellWidth =
      feedbackButtonCount > 0
        ? `${(100 / feedbackButtonCount).toFixed(2).replace(/\.00$/, '')}%`
        : null;

    const latestPosts = [];
    let latestPostsHasImages = false;
    if (newsletter.get('show_latest_posts')) {
      // Fetch last 3 published posts
      const urlRelations = this.#getRequiredUrlRelations();
      const { data } = await this.#models.Post.findPage({
        filter: `status:published+id:-'${post.id}'`,
        order: 'published_at DESC',
        limit: 3,
        ...(urlRelations.length ? { withRelated: urlRelations } : {}),
      });

      for (const latestPost of data) {
        // Please also adjust email-latest-posts-image if you make changes to the image width (100 x 2 = 200 -> should be in email-latest-posts-image)
        const {
          href: featureImage,
          width: featureImageWidth,
          height: featureImageHeight,
        } = await this.limitImageWidth(latestPost.get('feature_image'), 100, 100);
        const {
          href: featureImageMobile,
          width: featureImageMobileWidth,
          height: featureImageMobileHeight,
        } = await this.limitImageWidth(latestPost.get('feature_image'), 600, 480);

        latestPosts.push({
          title: this.truncateHtml(
            latestPost.get('title'),
            featureImage ? 85 : 95,
            featureImageMobile ? 55 : 75,
          ),
          url: this.#getPostUrl(latestPost),
          featureImage: featureImage
            ? {
                src: featureImage,
                width: featureImageWidth,
                height: featureImageHeight,
              }
            : null,
          featureImageMobile: featureImageMobile
            ? {
                src: featureImageMobile,
                width: featureImageMobileWidth,
                height: featureImageMobileHeight,
              }
            : null,
          excerpt: this.truncateHtml(
            latestPost.get('custom_excerpt') || latestPost.get('plaintext'),
            featureImage ? 120 : 130,
            featureImageMobile ? 90 : 100,
          ),
        });

        if (featureImage) {
          latestPostsHasImages = true;
        }
      }
    }

    const bodyFont = newsletter.get('body_font_category');
    const titleFont = newsletter.get('title_font_category');
    const titleAlignment = newsletter.get('title_alignment');
    const showFeatureImage = newsletter.get('show_feature_image') && !!postFeatureImage;

    const direction = this.#dir(locale);

    const data = {
      emailTitle: post.get('title'),
      site: {
        title: this.#settingsCache.get('title'),
        url: this.#urlUtils.urlFor('home', true),
        iconUrl: this.#settingsCache.get('icon')
          ? this.#urlUtils.urlFor(
              'image',
              {
                image: this.#settingsCache.get('icon'),
              },
              true,
            )
          : null,
        logoUrl: this.#settingsCache.get('logo') || this.#settingsCache.get('icon')
          ? this.#urlUtils.urlFor(
              'image',
              {
                image: this.#settingsCache.get('logo') || this.#settingsCache.get('icon'),
              },
              true,
            )
          : null,
        locale,
        direction,
      },
      preheader: this.#getEmailPreheader(post, audience, html),
      preheaderSpacing: `${'&#8199;&#847; '.repeat(150)}${'&shy; '.repeat(200)} &nbsp;`,
      html,

      post: {
        title: post.get('title'),
        url: postUrl,
        shareUrl: showShareButton ? shareUrl.href : null,
        commentUrl: commentUrl.href,
        authors,
        publishedAt,
        customExcerpt: post.get('custom_excerpt'),
        feature_image: postFeatureImage,
        feature_image_width: postFeatureImageWidth,
        feature_image_height: postFeatureImageHeight,
        feature_image_alt: post.related('posts_meta')?.get('feature_image_alt'),
        feature_image_caption: post.related('posts_meta')?.get('feature_image_caption'),
      },

      newsletter: {
        name: newsletter.get('name'),
        showPostTitleSection: newsletter.get('show_post_title_section'),
        showExcerpt: newsletter.get('show_excerpt'),
        showCommentCta,
        showSubscriptionDetails: newsletter.get('show_subscription_details'),
      },

      hasHeaderContent: !!(
        headerImage ||
        this.#settingsCache.get('logo') ||
        (newsletter.get('show_header_icon') && this.#settingsCache.get('icon')) ||
        newsletter.get('show_header_title') ||
        newsletter.get('show_header_name') ||
        newsletter.get('show_post_title_section') ||
        showFeatureImage
      ),

      latestPosts,
      latestPostsHasImages,

      //CSS
      ...emailDesign,
      showBadge: newsletter.get('show_badge'),
      headerImage,
      headerImageWidth,
      showHeaderIcon: newsletter.get('show_header_icon') && this.#settingsCache.get('icon'),

      // TODO: consider moving these to newsletter property
      showHeaderTitle: newsletter.get('show_header_title'),
      showHeaderName: newsletter.get('show_header_name'),
      showFeatureImage: showFeatureImage,
      footerContent: newsletter.get('footer_content'),

      // useful data
      ctaBgColors: ['grey', 'blue', 'green', 'yellow', 'red', 'pink', 'purple'],

      classes: {
        container: clsx('container', {
          'title-serif': titleFont === 'serif',
        }),
        title: clsx('post-title', {
          'post-title-with-excerpt': post.get('custom_excerpt'),
          'post-title-no-excerpt': !post.get('custom_excerpt'),
          'post-title-serif': titleFont === 'serif',
          'post-title-left': titleAlignment === 'left',
        }),
        titleLink: clsx('post-title-link', {
          'post-title-link-left': titleAlignment === 'left',
        }),
        excerpt: clsx('post-excerpt', {
          'post-excerpt-with-feature-image': showFeatureImage,
          'post-excerpt-no-feature-image': !showFeatureImage,
          'post-excerpt-serif-serif': titleFont === 'serif' && bodyFont === 'serif',
          'post-excerpt-serif-sans': titleFont === 'serif' && bodyFont !== 'serif',
          'post-excerpt-left': titleAlignment === 'left',
        }),
        meta: clsx('post-meta', {
          'post-meta-left': titleAlignment === 'left',
          'post-meta-center': titleAlignment !== 'left',
        }),
        body: clsx({
          'post-content-sans-serif': bodyFont === 'sans_serif',
          'post-content': bodyFont !== 'sans_serif',
        }),
      },

      // Audience feedback
      feedbackButtons: hasFeedbackButtons
        ? {
            likeHref: positiveLink,
            dislikeHref: negativeLink,
          }
        : null,
      feedbackButtonCellWidth,

      // Paywall
      paywall: addPaywall
        ? {
            signupUrl: signupUrl.href,
          }
        : null,

      year: new Date().getFullYear().toString(),
    };

    return data;
  }

  /**
   * Sets and limits the dimensions of an image.
   *
   * @private
   * @param {undefined | null | string} href
   * @param {number} [visibleWidth]
   * @param {null | number} [visibleHeight]
   * @returns {Promise<{href: null | string, width: number, height: number | null}>}
   */
  async limitImageWidth(href, visibleWidth = 600, visibleHeight = null) {
    if (!href) {
      return {
        href: null,
        width: 0,
        height: null,
      };
    }
    if (isUnsplashImage(href)) {
      // Unsplash images have a minimum size so assuming 1200px is safe
      const unsplashUrl = new URL(href);
      unsplashUrl.searchParams.delete('w');
      unsplashUrl.searchParams.delete('h');

      unsplashUrl.searchParams.set('w', (visibleWidth * 2).toFixed(0));

      if (visibleHeight) {
        unsplashUrl.searchParams.set('h', (visibleHeight * 2).toFixed(0));
        unsplashUrl.searchParams.set('fit', 'crop');
      }

      return {
        href: unsplashUrl.href,
        width: visibleWidth,
        height: visibleHeight,
      };
    } else {
      try {
        const size = await this.#imageSize.getCachedImageSizeFromUrl(href);

        if (!size || !size.width) {
          return { href, width: 0, height: null };
        }

        if (size.width >= visibleWidth) {
          if (!visibleHeight) {
            // Keep aspect ratio
            size.height = Math.round(size.height * (visibleWidth / size.width));
          }

          // keep original image, just set a fixed width
          size.width = visibleWidth;
        }

        if (visibleHeight && size.height >= visibleHeight) {
          // keep original image, just set a fixed width
          size.height = visibleHeight;
        }

        if (this.#storageUtils.isInternalImage(href)) {
          const sizePath =
            'size/w' + visibleWidth * 2 + (visibleHeight ? 'h' + visibleHeight * 2 : '') + '/';
          // we can safely request a 1200px image - Ghost will serve the original if it's smaller
          return {
            href: href.replace(
              CONTENT_IMAGES_PATH_WITHOUT_SIZE_REGEX,
              '/content/images/' + sizePath,
            ),
            width: size.width,
            height: size.height,
          };
        }

        return {
          href,
          width: size.width,
          height: size.height,
        };
      } catch (err) {
        // log and proceed. Using original header image without fixed width isn't fatal.
        logging.error(err);
      }
    }

    return {
      href,
      width: 0,
      height: null,
    };
  }
}

module.exports = EmailRenderer;
